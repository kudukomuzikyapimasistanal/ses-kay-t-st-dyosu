// CDN bağımlılıklarını (Bootstrap, ikonlar, Google Fonts) yerele indirir ve
// app/studio.php içindeki bağlantıları yerel dosyalara çevirir (çevrimdışı çalışma).
const fs = require('fs');
const path = require('path');
const https = require('https');

const appDir = path.join(__dirname, '..', 'app');
const vendor = path.join(appDir, 'vendor');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36';

function get(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': UA } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return resolve(get(new URL(res.headers.location, url).href));
      }
      if (res.statusCode !== 200) return reject(new Error(url + ' -> HTTP ' + res.statusCode));
      const c = [];
      res.on('data', (d) => c.push(d));
      res.on('end', () => resolve(Buffer.concat(c)));
    }).on('error', reject);
  });
}
const save = (rel, buf) => {
  const f = path.join(vendor, rel);
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, buf);
};

// CSS içindeki url(...) dosyalarını indirip CSS'i yerel yollarla yeniden yazar.
async function localizeCss(cssUrl, outRel, fontSubdir) {
  let css = (await get(cssUrl)).toString('utf8');
  const urls = [...new Set([...css.matchAll(/url\(([^)]+)\)/g)].map((m) => m[1].replace(/["']/g, '')))];
  let i = 0;
  for (const u of urls) {
    if (u.startsWith('data:')) continue;
    const abs = new URL(u, cssUrl).href;
    const clean = abs.split('?')[0].split('#')[0];
    const name = (i++) + '_' + path.basename(clean);
    await save(path.join(fontSubdir, name), await get(abs));
    css = css.split(u).join(fontSubdir + '/' + name);
  }
  save(outRel, Buffer.from(css, 'utf8'));
}

(async () => {
  const studio = path.join(appDir, 'studio.php');
  let html = fs.readFileSync(studio, 'utf8');
  if (html.includes('vendor/bootstrap.min.css')) { console.log('Zaten yerele çevrilmiş.'); return; }

  console.log('Bootstrap CSS/JS...');
  save('bootstrap.min.css', await get('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css'));
  save('bootstrap.bundle.min.js', await get('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js'));

  console.log('Bootstrap Icons...');
  await localizeCss('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css', 'bootstrap-icons.css', 'icons');

  console.log('Google Fonts...');
  const gf = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;600&display=swap';
  await localizeCss(gf, 'fonts.css', 'fonts');

  const swaps = [
    ['https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', 'vendor/bootstrap.min.css'],
    ['https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css', 'vendor/bootstrap-icons.css'],
    [gf, 'vendor/fonts.css'],
    ['https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', 'vendor/bootstrap.bundle.min.js']
  ];
  for (const [a, b] of swaps) {
    if (!html.includes(a)) throw new Error('studio.php içinde bulunamadı: ' + a);
    html = html.split(a).join(b);
  }
  // Artık gereksiz preconnect satırları varsa zararsızdır; dokunmuyoruz.
  fs.writeFileSync(studio, html, 'utf8');
  console.log('Tamam: CDN bağımlılıkları yerele çevrildi.');
})().catch((e) => { console.error('HATA:', e.message); process.exit(1); });
