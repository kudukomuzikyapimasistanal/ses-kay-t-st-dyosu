// Windows için taşınabilir PHP'yi indirip ./php klasörüne açar.
const fs = require('fs');
const path = require('path');
const https = require('https');
const { execFileSync } = require('child_process');

const phpDir = path.join(__dirname, '..', 'php');
if (fs.existsSync(path.join(phpDir, 'php.exe'))) {
  console.log('php.exe zaten var, atlanıyor.');
  process.exit(0);
}

function getBuf(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return resolve(getBuf(new URL(res.headers.location, url).href));
      }
      if (res.statusCode !== 200) return reject(new Error(url + ' -> HTTP ' + res.statusCode));
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    }).on('error', reject);
  });
}

(async () => {
  const base = 'https://windows.php.net/downloads/releases/';
  console.log('PHP sürüm listesi alınıyor...');
  const rel = JSON.parse((await getBuf(base + 'releases.json')).toString('utf8'));

  // 8.x sürümlerinden en yenisini seç, NTS x64 zip'i bul
  const keys = Object.keys(rel).filter((k) => /^8\./.test(k)).sort((a, b) => parseFloat(b) - parseFloat(a));
  let zipName = null;
  for (const k of keys) {
    const build = Object.keys(rel[k]).find((b) => /^nts-.*x64$/.test(b));
    if (build && rel[k][build].zip) { zipName = rel[k][build].zip.path; break; }
  }
  if (!zipName) throw new Error('Uygun PHP zip bulunamadı. Elle indirip ./php içine açın.');

  console.log('İndiriliyor:', zipName);
  const zipPath = path.join(__dirname, '..', 'php-download.zip');
  fs.writeFileSync(zipPath, await getBuf(base + zipName));

  fs.mkdirSync(phpDir, { recursive: true });
  console.log('Açılıyor...');
  execFileSync('powershell', ['-NoProfile', '-Command',
    `Expand-Archive -Force -Path '${zipPath}' -DestinationPath '${phpDir}'`], { stdio: 'inherit' });
  fs.unlinkSync(zipPath);
  console.log('PHP hazır:', phpDir);
})().catch((e) => { console.error('HATA:', e.message); process.exit(1); });
