<?php
// Masaüstü sürümü: ana sitenin index.php'sinin yerine geçen küçük yönlendirici.
if (($_GET['action'] ?? '') === 'get_profile_picture') {
    header('Content-Type: image/svg+xml');
    header('Cache-Control: no-store');
    echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#222"/><circle cx="32" cy="24" r="12" fill="#888"/><path d="M8 62c2-16 14-22 24-22s22 6 24 22z" fill="#888"/></svg>';
    exit;
}
header('Location: studio.php');
