<?php
/**
 * ============================================================
 *  KUDUKO MÜZİK YAPIM — SES KAYIT STÜDYOSU (BANDLAB TARZI)
 * ============================================================
 *  Tarayıcı içinde çalışan çok kanallı (multitrack) kayıt stüdyosu:
 *   - 16 kanal, kanal türleri (Vokal / Enstrüman / Davul / Gitar / Bas)
 *   - Transport: çal / durdur / kaydet, metronom, tempo, ölçü, ton
 *   - Mikrofon/enstrüman kaydı (MediaRecorder + Web Audio)
 *   - Sanal enstrümanlar (piyano, davul makinesi step sequencer)
 *   - Loop kütüphanesi (dahili ritim/i̇loop üreteci)
 *   - Mixer: ses seviyesi, pan, solo, mute, efekt zinciri
 *   - Efektler: AutoPitch, Reverb, Delay, EQ, Kompresör
 *   - Mastering hazır ayarları
 *   - WAV mixdown dışa aktarma
 *   - Proje kaydetme / yükleme (sunucu tarafı, studio_projects)
 *   - Klavye kısayolları, dalga formu, ızgara, yakınlaştırma
 * ============================================================
 */

// --- MASAÜSTÜ SÜRÜMÜ: veri klasörü Electron tarafından verilir ---
define('STUDIO_DATA_DIR', rtrim(getenv('STUDIO_DATA_DIR') ?: __DIR__, '/\\'));
if (!is_dir(STUDIO_DATA_DIR)) { @mkdir(STUDIO_DATA_DIR, 0777, true); }

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', STUDIO_DATA_DIR . '/php_errors.log');
date_default_timezone_set('Europe/Istanbul');

session_start();

// Masaüstü sürümü: giriş yok, her zaman tek bir yerel kullanıcı (id=1)
$_SESSION['user_id'] = 1;

header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// ============================================================
// VERİTABANI
// ============================================================
define('STUDIO_DB_FILE', STUDIO_DATA_DIR . '/music.db');
define('STUDIO_ASSET_DIR', STUDIO_DATA_DIR . '/studio_uploads');
define('STUDIO_MAX_ASSET_BYTES', 60 * 1024 * 1024); // 60MB / ses dosyası

function studio_db() {
    static $db = null;
    if ($db !== null) return $db;
    try {
        $db = new PDO('sqlite:' . STUDIO_DB_FILE, null, null, [PDO::ATTR_TIMEOUT => 30]);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $db->exec("PRAGMA journal_mode=WAL;");
        $db->exec("PRAGMA synchronous=NORMAL;");
        $db->exec("PRAGMA busy_timeout=8000;");
        $db->exec("PRAGMA foreign_keys=ON;");
    } catch (PDOException $e) {
        error_log('Studio DB hatası: ' . $e->getMessage());
        return null;
    }
    return $db;
}

function studio_init_db($db) {
    if (!$db) return;

    // Masaüstü sürümü: ana sitedeki tabloların yerel karşılıkları
    $db->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            artist TEXT NOT NULL DEFAULT 'Yerel Kullanıcı',
            verified INTEGER NOT NULL DEFAULT 0
        );
    ");
    $db->exec("INSERT OR IGNORE INTO users (id, artist, verified) VALUES (1, 'Yerel Kullanıcı', 0);");
    $db->exec("
        CREATE TABLE IF NOT EXISTS music (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, file TEXT, title TEXT, artist TEXT, album TEXT,
            genre TEXT, year INTEGER, duration INTEGER, bitrate INTEGER,
            image TEXT, last_modified INTEGER
        );
    ");

    $db->exec("
        CREATE TABLE IF NOT EXISTS studio_projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL DEFAULT 'Yeni Proje',
            bpm INTEGER NOT NULL DEFAULT 120,
            time_sig TEXT NOT NULL DEFAULT '4/4',
            musical_key TEXT NOT NULL DEFAULT 'C',
            master_gain REAL NOT NULL DEFAULT 0.85,
            master_preset TEXT NOT NULL DEFAULT 'none',
            track_count INTEGER NOT NULL DEFAULT 0,
            project_data TEXT NOT NULL DEFAULT '{}',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
    ");

    $db->exec("
        CREATE TABLE IF NOT EXISTS studio_assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            project_id INTEGER,
            file_path TEXT NOT NULL,
            mime_type TEXT,
            file_size INTEGER DEFAULT 0,
            duration REAL DEFAULT 0,
            original_name TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
    ");

    $db->exec("CREATE INDEX IF NOT EXISTS studio_projects_user_idx ON studio_projects(user_id, updated_at);");
    $db->exec("CREATE INDEX IF NOT EXISTS studio_assets_project_idx ON studio_assets(project_id);");

    if (!is_dir(STUDIO_ASSET_DIR)) {
        @mkdir(STUDIO_ASSET_DIR, 0777, true);
    }
}

function studio_json($data, $code = 200) {
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function studio_uid() {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
}

function studio_post_json() {
    $raw = file_get_contents('php://input');
    if ($raw === '' || $raw === false) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// ============================================================
// YARDIMCI: sessiz WAV üreteci (loop/örnek üretimi için)
// ============================================================
function studio_wav_bytes($samples, $sampleRate = 44100) {
    $numSamples = count($samples);
    $dataSize = $numSamples * 2;
    $header = "RIFF" . pack('V', 36 + $dataSize) . "WAVE";
    $header .= "fmt " . pack('V', 16) . pack('v', 1) . pack('v', 1);
    $header .= pack('V', $sampleRate) . pack('V', $sampleRate * 2) . pack('v', 2) . pack('v', 16);
    $header .= "data" . pack('V', $dataSize);
    $pcm = '';
    foreach ($samples as $s) {
        $v = (int)max(-32768, min(32767, round($s * 32767)));
        $pcm .= pack('v', $v & 0xFFFF);
    }
    return $header . $pcm;
}

// ============================================================
// AJAX / API KATMANI
// ============================================================
$studioAction = isset($_GET['action']) ? (string)$_GET['action'] : '';
if ($studioAction !== '') {
    $db = studio_db();
    if (!$db) studio_json(['status' => 'error', 'message' => 'Veritabanı bağlantısı kurulamadı.'], 500);
    studio_init_db($db);
    $uid = studio_uid();

    switch ($studioAction) {

        // ----------------------------------------------------
        // Oturum bilgisi
        // ----------------------------------------------------
        case 'session':
            if ($uid) {
                $stmt = $db->prepare("SELECT id, artist, verified FROM users WHERE id = ?");
                $stmt->execute([$uid]);
                $u = $stmt->fetch();
                if ($u) {
                    studio_json(['status' => 'loggedin', 'user' => $u]);
                }
            }
            studio_json(['status' => 'loggedout']);
            break;

        // ----------------------------------------------------
        // Proje listesi
        // ----------------------------------------------------
        case 'list_projects':
            if (!$uid) studio_json(['status' => 'error', 'message' => 'Giriş yapmalısınız.'], 403);
            $stmt = $db->prepare("SELECT id, title, bpm, time_sig, track_count, updated_at
                                  FROM studio_projects WHERE user_id = ? ORDER BY updated_at DESC LIMIT 100");
            $stmt->execute([$uid]);
            studio_json(['status' => 'success', 'projects' => $stmt->fetchAll()]);
            break;

        // ----------------------------------------------------
        // Proje yükle
        // ----------------------------------------------------
        case 'load_project':
            if (!$uid) studio_json(['status' => 'error', 'message' => 'Giriş yapmalısınız.'], 403);
            $pid = (int)($_GET['id'] ?? 0);
            if (!$pid) studio_json(['status' => 'error', 'message' => 'Geçersiz proje ID.'], 400);
            $stmt = $db->prepare("SELECT * FROM studio_projects WHERE id = ? AND user_id = ?");
            $stmt->execute([$pid, $uid]);
            $project = $stmt->fetch();
            if (!$project) studio_json(['status' => 'error', 'message' => 'Proje bulunamadı.'], 404);

            // Ses varlıklarının URL'lerini ekle
            $aStmt = $db->prepare("SELECT id, mime_type, duration, original_name FROM studio_assets WHERE project_id = ?");
            $aStmt->execute([$pid]);
            $assets = [];
            foreach ($aStmt->fetchAll() as $a) {
                $a['url'] = 'studio.php?action=get_asset&id=' . $a['id'];
                $assets[] = $a;
            }
            $project['assets'] = $assets;
            $project['project_data'] = json_decode($project['project_data'] ?: '{}', true) ?: new stdClass();
            studio_json(['status' => 'success', 'project' => $project]);
            break;

        // ----------------------------------------------------
        // Proje kaydet / güncelle
        // ----------------------------------------------------
        case 'save_project':
            if (!$uid) studio_json(['status' => 'error', 'message' => 'Giriş yapmalısınız.'], 403);
            $data = studio_post_json();
            $pid = (int)($data['id'] ?? 0);
            $title = trim((string)($data['title'] ?? 'Yeni Proje'));
            if ($title === '') $title = 'Yeni Proje';
            $title = mb_substr($title, 0, 120);

            $bpm = (int)($data['bpm'] ?? 120);
            if ($bpm < 30 || $bpm > 300) $bpm = 120;

            $timeSig = (string)($data['time_sig'] ?? '4/4');
            if (!in_array($timeSig, ['2/4', '3/4', '4/4', '6/8', '5/4', '7/8'], true)) $timeSig = '4/4';

            $key = (string)($data['key'] ?? 'C');
            $allowedKeys = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B', 'Am', 'Bm', 'Cm', 'Dm', 'Em', 'Fm', 'Gm'];
            if (!in_array($key, $allowedKeys, true)) $key = 'C';

            $masterGain = (float)($data['master_gain'] ?? 0.85);
            $masterGain = max(0.0, min(1.5, $masterGain));

            $masterPreset = (string)($data['master_preset'] ?? 'none');
            $trackCount = (int)($data['track_count'] ?? 0);

            $projectData = $data['project_data'] ?? [];
            $projectJson = is_string($projectData) ? $projectData : json_encode($projectData, JSON_UNESCAPED_UNICODE);
            if (strlen($projectJson) > 4 * 1024 * 1024) {
                studio_json(['status' => 'error', 'message' => 'Proje verisi çok büyük.'], 413);
            }

            if ($pid > 0) {
                $own = $db->prepare("SELECT id FROM studio_projects WHERE id = ? AND user_id = ?");
                $own->execute([$pid, $uid]);
                if (!$own->fetch()) studio_json(['status' => 'error', 'message' => 'Proje bulunamadı.'], 404);

                $stmt = $db->prepare("UPDATE studio_projects
                    SET title = ?, bpm = ?, time_sig = ?, musical_key = ?, master_gain = ?,
                        master_preset = ?, track_count = ?, project_data = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ? AND user_id = ?");
                $stmt->execute([$title, $bpm, $timeSig, $key, $masterGain, $masterPreset, $trackCount, $projectJson, $pid, $uid]);
            } else {
                $stmt = $db->prepare("INSERT INTO studio_projects
                    (user_id, title, bpm, time_sig, musical_key, master_gain, master_preset, track_count, project_data)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$uid, $title, $bpm, $timeSig, $key, $masterGain, $masterPreset, $trackCount, $projectJson]);
                $pid = (int)$db->lastInsertId();
            }

            studio_json(['status' => 'success', 'message' => 'Proje kaydedildi.', 'id' => $pid]);
            break;

        // ----------------------------------------------------
        // Proje sil
        // ----------------------------------------------------
        case 'delete_project':
            if (!$uid) studio_json(['status' => 'error', 'message' => 'Giriş yapmalısınız.'], 403);
            $data = studio_post_json();
            $pid = (int)($data['id'] ?? 0);
            if (!$pid) studio_json(['status' => 'error', 'message' => 'Geçersiz proje ID.'], 400);

            $stmt = $db->prepare("SELECT id FROM studio_projects WHERE id = ? AND user_id = ?");
            $stmt->execute([$pid, $uid]);
            if (!$stmt->fetch()) studio_json(['status' => 'error', 'message' => 'Proje bulunamadı.'], 404);

            // Varlık dosyalarını diskten sil
            $fStmt = $db->prepare("SELECT file_path FROM studio_assets WHERE project_id = ?");
            $fStmt->execute([$pid]);
            foreach ($fStmt->fetchAll(PDO::FETCH_COLUMN) as $fp) {
                if ($fp && strpos(realpath($fp) ?: '', realpath(STUDIO_ASSET_DIR) ?: '_') === 0) {
                    @unlink($fp);
                }
            }
            $db->prepare("DELETE FROM studio_assets WHERE project_id = ?")->execute([$pid]);
            $db->prepare("DELETE FROM studio_projects WHERE id = ? AND user_id = ?")->execute([$pid, $uid]);
            studio_json(['status' => 'success', 'message' => 'Proje silindi.']);
            break;

        // ----------------------------------------------------
        // Ses varlığı yükle (kayıt / içe aktarma)
        // ----------------------------------------------------
        case 'upload_asset':
            if (!$uid) studio_json(['status' => 'error', 'message' => 'Giriş yapmalısınız.'], 403);

            if (!isset($_FILES['audio']) || $_FILES['audio']['error'] !== UPLOAD_ERR_OK) {
                $code = $_FILES['audio']['error'] ?? -1;
                studio_json(['status' => 'error', 'message' => 'Ses dosyası yüklenemedi (kod: ' . $code . ').'], 400);
            }

            $file = $_FILES['audio'];
            // PHP yükleme limitlerini de kontrol et
            if ((int)$file['size'] <= 0) {
                studio_json(['status' => 'error', 'message' => 'Boş dosya.'], 400);
            }
            if ((int)$file['size'] > STUDIO_MAX_ASSET_BYTES) {
                studio_json(['status' => 'error', 'message' => 'Dosya çok büyük (maks. 60MB).'], 413);
            }

            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['webm', 'ogg', 'oga', 'mp3', 'wav', 'm4a', 'mp4', 'aac', 'opus', 'flac'];
            if (!in_array($ext, $allowed, true)) {
                studio_json(['status' => 'error', 'message' => 'Desteklenmeyen dosya türü: .' . $ext], 400);
            }

            if (!is_dir(STUDIO_ASSET_DIR)) @mkdir(STUDIO_ASSET_DIR, 0777, true);
            if (!is_dir(STUDIO_ASSET_DIR) || !is_writable(STUDIO_ASSET_DIR)) {
                studio_json(['status' => 'error', 'message' => 'studio_uploads klasörü yazılabilir değil.'], 500);
            }

            $safe = 'sa_' . $uid . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(5)) . '.' . $ext;
            $target = STUDIO_ASSET_DIR . '/' . $safe;

            if (!move_uploaded_file($file['tmp_name'], $target)) {
                studio_json(['status' => 'error', 'message' => 'Dosya taşınamadı.'], 500);
            }
            @chmod($target, 0644);

            $mime = $file['type'] ?: 'audio/webm';
            $duration = isset($_POST['duration']) ? (float)$_POST['duration'] : 0;
            $projectId = isset($_POST['project_id']) ? (int)$_POST['project_id'] : null;
            $originalName = mb_substr((string)$file['name'], 0, 200);

            $stmt = $db->prepare("INSERT INTO studio_assets
                (user_id, project_id, file_path, mime_type, file_size, duration, original_name)
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$uid, $projectId ?: null, $target, $mime, (int)$file['size'], $duration, $originalName]);
            $assetId = (int)$db->lastInsertId();

            studio_json([
                'status' => 'success',
                'message' => 'Ses kaydedildi.',
                'asset' => [
                    'id' => $assetId,
                    'url' => 'studio.php?action=get_asset&id=' . $assetId,
                    'duration' => $duration,
                    'mime_type' => $mime,
                    'name' => $originalName
                ]
            ]);
            break;

        // ----------------------------------------------------
        // Ses varlığını dinlet (range destekli akış)
        // ----------------------------------------------------
        case 'get_asset':
            $aid = (int)($_GET['id'] ?? 0);
            if (!$aid) { http_response_code(400); exit; }

            $stmt = $db->prepare("SELECT file_path, mime_type FROM studio_assets WHERE id = ?");
            $stmt->execute([$aid]);
            $asset = $stmt->fetch();

            if (!$asset || !$asset['file_path'] || !file_exists($asset['file_path'])) {
                http_response_code(404); exit;
            }

            session_write_close();
            while (ob_get_level() > 0) { @ob_end_clean(); }

            $path = $asset['file_path'];
            $size = filesize($path);
            $mime = $asset['mime_type'] ?: 'audio/webm';

            header('Content-Type: ' . $mime);
            header('Accept-Ranges: bytes');
            header('Cache-Control: private, max-age=3600');

            $start = 0; $end = $size - 1;
            if (isset($_SERVER['HTTP_RANGE'])) {
                $range = str_replace('bytes=', '', $_SERVER['HTTP_RANGE']);
                $parts = explode('-', $range, 2);
                $start = (int)$parts[0];
                if (isset($parts[1]) && $parts[1] !== '') $end = (int)$parts[1];
                if ($start > $end || $start >= $size) {
                    header('HTTP/1.1 416 Range Not Satisfiable');
                    header("Content-Range: bytes */$size");
                    exit;
                }
                $len = $end - $start + 1;
                header('HTTP/1.1 206 Partial Content');
                header("Content-Range: bytes $start-$end/$size");
            } else {
                $len = $size;
                header('HTTP/1.1 200 OK');
            }
            header('Content-Length: ' . $len);

            $fp = @fopen($path, 'rb');
            if ($fp) {
                fseek($fp, $start);
                $left = $len;
                while ($left > 0 && !feof($fp)) {
                    if (connection_aborted()) break;
                    $chunk = fread($fp, min(8192, $left));
                    if ($chunk === false) break;
                    echo $chunk;
                    @flush();
                    $left -= strlen($chunk);
                }
                fclose($fp);
            }
            exit;
            break;

        // ----------------------------------------------------
        // Mixdown'u kütüphaneye (music) kaydet
        // ----------------------------------------------------
        case 'upload_mixdown':
            if (!$uid) studio_json(['status' => 'error', 'message' => 'Giriş yapmalısınız.'], 403);

            if (!isset($_FILES['mixdown']) || $_FILES['mixdown']['error'] !== UPLOAD_ERR_OK) {
                studio_json(['status' => 'error', 'message' => 'Mixdown yüklenemedi.'], 400);
            }

            $file = $_FILES['mixdown'];
            if ((int)$file['size'] > STUDIO_MAX_ASSET_BYTES) {
                studio_json(['status' => 'error', 'message' => 'Mixdown çok büyük (maks. 60MB).'], 413);
            }

            $title = trim((string)($_POST['title'] ?? 'Stüdyo Kaydı'));
            if ($title === '') $title = 'Stüdyo Kaydı';
            $title = mb_substr($title, 0, 120);
            $genre = mb_substr(trim((string)($_POST['genre'] ?? 'Stüdyo')), 0, 60);
            if ($genre === '') $genre = 'Stüdyo';

            $uploadDir = STUDIO_DATA_DIR . '/uploads';
            if (!is_dir($uploadDir)) @mkdir($uploadDir, 0777, true);
            if (!is_dir($uploadDir) || !is_writable($uploadDir)) {
                studio_json(['status' => 'error', 'message' => 'uploads klasörü yazılabilir değil.'], 500);
            }

            $safeName = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $title);
            $target = $uploadDir . '/' . time() . '_' . $safeName . '.wav';
            $counter = 1;
            while (file_exists($target)) {
                $target = $uploadDir . '/' . time() . '_' . $safeName . '_' . $counter . '.wav';
                $counter++;
            }

            if (!move_uploaded_file($file['tmp_name'], $target)) {
                studio_json(['status' => 'error', 'message' => 'Dosya kaydedilemedi.'], 500);
            }

            $duration = isset($_POST['duration']) ? (int)round((float)$_POST['duration']) : 0;
            if ($duration < 0) $duration = 0;

            // Sanatçı adını al
            $nStmt = $db->prepare("SELECT artist FROM users WHERE id = ?");
            $nStmt->execute([$uid]);
            $artistName = $nStmt->fetchColumn() ?: 'Bilinmeyen Sanatçı';

            try {
                $stmt = $db->prepare("INSERT INTO music
                    (user_id, file, title, artist, album, genre, year, duration, bitrate, image, last_modified)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?)");
                $stmt->execute([
                    $uid, $target, $title, $artistName, 'Stüdyo',
                    $genre, (int)date('Y'), $duration, 1411200, time()
                ]);
                $songId = (int)$db->lastInsertId();
            } catch (PDOException $e) {
                @unlink($target);
                error_log('Studio mixdown DB hatası: ' . $e->getMessage());
                studio_json(['status' => 'error', 'message' => 'Veritabanına kaydedilemedi.'], 500);
            }

            studio_json([
                'status' => 'success',
                'message' => 'Mixdown kütüphanenize eklendi!',
                'song_id' => $songId
            ]);
            break;

        // ----------------------------------------------------
        // Dahili loop/örnek kütüphanesi
        // Sunucu tarafında WAV olarak üretilir; tarayıcıda
        // AudioBuffer'a çözülerek kanallara sürüklenebilir.
        // ----------------------------------------------------
        case 'get_loops':
            $loops = [];
            foreach (studio_loop_catalog() as $loop) {
                $loops[] = [
                    'id'          => $loop['id'],
                    'name'        => $loop['name'],
                    'category'    => $loop['category'],
                    'instrument'  => $loop['instrument'],
                    'bpm'         => $loop['bpm'],
                    'bars'        => $loop['bars'],
                    'key'         => $loop['key'],
                    'color'       => $loop['color'],
                    'url'         => 'studio.php?action=get_loop&id=' . $loop['id'],
                ];
            }
            studio_json(['status' => 'success', 'loops' => $loops]);
            break;

        case 'get_loop':
            $id = preg_replace('/[^a-z0-9_]/i', '', (string)($_GET['id'] ?? ''));
            if ($id === '') { http_response_code(400); exit; }

            $catalog = studio_loop_catalog();
            if (!isset($catalog[$id])) { http_response_code(404); exit; }

            // Disk önbelleği
            $cacheDir = STUDIO_ASSET_DIR . '/loops_cache';
            if (!is_dir($cacheDir)) @mkdir($cacheDir, 0777, true);
            $cacheFile = $cacheDir . '/' . $id . '.wav';

            if (!file_exists($cacheFile)) {
                $samples = studio_render_loop($catalog[$id]);
                $bytes = studio_wav_bytes($samples, 44100);
                @file_put_contents($cacheFile, $bytes);
            }

            if (!file_exists($cacheFile)) { http_response_code(500); exit; }

            session_write_close();
            while (ob_get_level() > 0) { @ob_end_clean(); }

            header('Content-Type: audio/wav');
            header('Content-Length: ' . filesize($cacheFile));
            header('Cache-Control: public, max-age=604800');
            header('Accept-Ranges: bytes');
            readfile($cacheFile);
            exit;

        default:
            studio_json(['status' => 'error', 'message' => 'Bilinmeyen eylem: ' . $studioAction], 404);
    }
    exit;
}

// ============================================================
// LOOP KÜTÜPHANESİ — TANIMLAR + SENTEZ
// ============================================================

/**
 * Loop kataloğu. Her loop, çalındığında matematiksel olarak
 * üretilen bir ritim veya melodi tanımıdır.
 */
function studio_loop_catalog() {
    return [
        // --- Davul / Ritim ---
        'drm_boom_bap' => [
            'id' => 'drm_boom_bap', 'name' => 'Boom Bap Beat', 'category' => 'Davul',
            'instrument' => 'drums', 'bpm' => 90, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'boom_bap',
        ],
        'drm_trap' => [
            'id' => 'drm_trap', 'name' => 'Trap Hi-Hats', 'category' => 'Davul',
            'instrument' => 'drums', 'bpm' => 140, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'trap',
        ],
        'drm_four_floor' => [
            'id' => 'drm_four_floor', 'name' => 'Four On The Floor', 'category' => 'Davul',
            'instrument' => 'drums', 'bpm' => 124, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'four_floor',
        ],
        'drm_rock' => [
            'id' => 'drm_rock', 'name' => 'Rock Groove', 'category' => 'Davul',
            'instrument' => 'drums', 'bpm' => 120, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'rock',
        ],
        'drm_perc' => [
            'id' => 'drm_perc', 'name' => 'Percussion Shaker', 'category' => 'Davul',
            'instrument' => 'drums', 'bpm' => 110, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'perc',
        ],
        // --- Bas ---
        'bas_sub_pulse' => [
            'id' => 'bas_sub_pulse', 'name' => 'Sub Bass Pulse', 'category' => 'Bas',
            'instrument' => 'bass', 'bpm' => 124, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'sub_pulse',
        ],
        'bas_funk' => [
            'id' => 'bas_funk', 'name' => 'Funk Bass Line', 'category' => 'Bas',
            'instrument' => 'bass', 'bpm' => 100, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'funk',
        ],
        'bas_rock' => [
            'id' => 'bas_rock', 'name' => 'Rock Bass Drive', 'category' => 'Bas',
            'instrument' => 'bass', 'bpm' => 128, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'rock_bass',
        ],
        // --- Gitar ---
        'gtr_power' => [
            'id' => 'gtr_power', 'name' => 'Power Chord Riff', 'category' => 'Gitar',
            'instrument' => 'guitar', 'bpm' => 130, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'power',
        ],
        'gtr_clean_arp' => [
            'id' => 'gtr_clean_arp', 'name' => 'Clean Arpeggio', 'category' => 'Gitar',
            'instrument' => 'guitar', 'bpm' => 96, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'clean_arp',
        ],
        // --- Piyano / Tuşlu ---
        'key_piano_chord' => [
            'id' => 'key_piano_chord', 'name' => 'Piano Chords', 'category' => 'Tuşlu',
            'instrument' => 'piano', 'bpm' => 90, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'piano_chord',
        ],
        'key_piano_melody' => [
            'id' => 'key_piano_melody', 'name' => 'Piano Melody', 'category' => 'Tuşlu',
            'instrument' => 'piano', 'bpm' => 100, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'piano_melody',
        ],
        'key_synth_pad' => [
            'id' => 'key_synth_pad', 'name' => 'Synth Pad', 'category' => 'Tuşlu',
            'instrument' => 'synth', 'bpm' => 84, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'synth_pad',
        ],
        'key_pluck' => [
            'id' => 'key_pluck', 'name' => 'Pluck Sequence', 'category' => 'Tuşlu',
            'instrument' => 'synth', 'bpm' => 118, 'bars' => 2, 'key' => 'C', 'color' => '#ffffff',
            'style' => 'pluck',
        ],
    ];
}

/** Nota adını frekansa çevir (A4 = 440Hz). */
function studio_note_freq($semitonesFromA4) {
    return 440.0 * pow(2, $semitonesFromA4 / 12.0);
}

/** ADSR + osilatör ile tek nota sentezle. */
function studio_synth_note(&$buf, $startSample, $freq, $durSamples, $amp, $waveType, $sampleRate = 44100, $decay = 0.6) {
    $total = count($buf);
    for ($i = 0; $i < $durSamples; $i++) {
        $idx = $startSample + $i;
        if ($idx < 0 || $idx >= $total) continue;

        $t = $i / $sampleRate;
        $pos = $i / $durSamples; // 0..1

        // ADSR benzeri zarf
        $attack = 0.01;
        if ($t < $attack) {
            $env = $t / $attack;
        } else {
            $env = exp(-($t - $attack) * (2.2 / max(0.05, $decay)));
        }
        // Sonda yumuşak kapanış
        if ($pos > 0.85) {
            $env *= (1 - (($pos - 0.85) / 0.15));
        }

        $phase = 2 * M_PI * $freq * $t;
        switch ($waveType) {
            case 'sine':
                $s = sin($phase);
                break;
            case 'square':
                $s = (sin($phase) >= 0) ? 1.0 : -1.0;
                $s *= 0.55;
                break;
            case 'saw':
                $s = 2.0 * (($freq * $t) - floor($freq * $t + 0.5));
                $s *= 0.7;
                break;
            case 'triangle':
                $s = 2.0 * abs(2.0 * (($freq * $t) - floor($freq * $t + 0.5))) - 1.0;
                break;
            case 'noise':
                $s = (mt_rand() / mt_getrandmax()) * 2 - 1;
                break;
            default:
                $s = sin($phase);
        }

        // Hafif harmonik zenginleştirme (daha dolu ses)
        if ($waveType === 'sine') {
            $s += 0.25 * sin($phase * 2) + 0.12 * sin($phase * 3);
            $s *= 0.7;
        }

        $buf[$idx] += $s * $env * $amp;
    }
}

/** Davul vuruşu sentezle (kick / snare / hat / clap). */
function studio_drum_hit(&$buf, $startSample, $type, $amp, $sampleRate = 44100) {
    $total = count($buf);
    switch ($type) {
        case 'kick':
            $dur = (int)($sampleRate * 0.32);
            for ($i = 0; $i < $dur; $i++) {
                $idx = $startSample + $i;
                if ($idx < 0 || $idx >= $total) continue;
                $t = $i / $sampleRate;
                $freq = 120 * exp(-$t * 22) + 45;
                $env = exp(-$t * 9);
                $buf[$idx] += sin(2 * M_PI * $freq * $t) * $env * $amp;
            }
            break;

        case 'snare':
            $dur = (int)($sampleRate * 0.24);
            for ($i = 0; $i < $dur; $i++) {
                $idx = $startSample + $i;
                if ($idx < 0 || $idx >= $total) continue;
                $t = $i / $sampleRate;
                $env = exp(-$t * 18);
                $noise = (mt_rand() / mt_getrandmax()) * 2 - 1;
                $tone = sin(2 * M_PI * 190 * $t) * 0.5;
                $buf[$idx] += ($noise * 0.8 + $tone) * $env * $amp;
            }
            break;

        case 'hat_closed':
            $dur = (int)($sampleRate * 0.06);
            for ($i = 0; $i < $dur; $i++) {
                $idx = $startSample + $i;
                if ($idx < 0 || $idx >= $total) continue;
                $t = $i / $sampleRate;
                $env = exp(-$t * 70);
                $noise = (mt_rand() / mt_getrandmax()) * 2 - 1;
                $buf[$idx] += $noise * $env * $amp * 0.7;
            }
            break;

        case 'hat_open':
            $dur = (int)($sampleRate * 0.30);
            for ($i = 0; $i < $dur; $i++) {
                $idx = $startSample + $i;
                if ($idx < 0 || $idx >= $total) continue;
                $t = $i / $sampleRate;
                $env = exp(-$t * 11);
                $noise = (mt_rand() / mt_getrandmax()) * 2 - 1;
                $buf[$idx] += $noise * $env * $amp * 0.6;
            }
            break;

        case 'clap':
            $dur = (int)($sampleRate * 0.20);
            for ($i = 0; $i < $dur; $i++) {
                $idx = $startSample + $i;
                if ($idx < 0 || $idx >= $total) continue;
                $t = $i / $sampleRate;
                // 3 hızlı vuruş
                $env = exp(-$t * 25) + 0.6 * exp(-abs($t - 0.012) * 90) + 0.4 * exp(-abs($t - 0.024) * 90);
                $noise = (mt_rand() / mt_getrandmax()) * 2 - 1;
                $buf[$idx] += $noise * $env * $amp * 0.55;
            }
            break;

        case 'tom':
            $dur = (int)($sampleRate * 0.30);
            for ($i = 0; $i < $dur; $i++) {
                $idx = $startSample + $i;
                if ($idx < 0 || $idx >= $total) continue;
                $t = $i / $sampleRate;
                $freq = 180 * exp(-$t * 12) + 85;
                $env = exp(-$t * 12);
                $buf[$idx] += sin(2 * M_PI * $freq * $t) * $env * $amp * 0.85;
            }
            break;

        case 'ride':
            $dur = (int)($sampleRate * 0.5);
            for ($i = 0; $i < $dur; $i++) {
                $idx = $startSample + $i;
                if ($idx < 0 || $idx >= $total) continue;
                $t = $i / $sampleRate;
                $env = exp(-$t * 5);
                $noise = (mt_rand() / mt_getrandmax()) * 2 - 1;
                $tone = sin(2 * M_PI * 3200 * $t) * 0.3;
                $buf[$idx] += ($noise * 0.6 + $tone) * $env * $amp * 0.5;
            }
            break;
    }
}

/** Loop tanımından WAV örnek dizisi üretir. */
function studio_render_loop($loop) {
    $sr = 44100;
    $bpm = max(40, (int)$loop['bpm']);
    $bars = max(1, (int)$loop['bars']);
    $beatDur = 60.0 / $bpm;           // saniye / vuruş
    $totalSamples = (int)round($beatDur * 4 * $bars * $sr);
    $buf = array_fill(0, $totalSamples, 0.0);

    $sixteenth = $beatDur / 4;         // 16'lık nota süresi
    $sSamples = (int)round($sixteenth * $sr);
    $stepCount = $bars * 16;

    // Bir barın 16'lık adım sayısı. Davul/bas/gitar bloklarının tümü
    // "ikinci bar" varyasyonunu bu değerle hesaplar; bu yüzden fonksiyon
    // kapsamında (blokların dışında) tanımlanmalıdır.
    $half = (int)($stepCount / 2);

    // Frekans referansı: C4 (A4 = 440 Hz referansına göre 3 yarım ton uzaklık)
    $sC = 3;

    $style = $loop['style'];
    $inst = $loop['instrument'];

    // ============ DAVUL LOO'LARI ============
    if ($inst === 'drums') {
        // Her stil için adım desenleri
        $kicks = $snares = $hats = $opens = $claps = $toms = $rides = [];

        switch ($style) {
            case 'boom_bap':
                $kicks  = [0, 6, 10];
                $snares = [4, 12];
                $hats   = [0,2,4,6,8,10,12,14];
                break;
            case 'trap':
                $kicks  = [0, 3, 8, 11];
                $snares = [4, 12];
                $hats   = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
                $opens  = [7, 15];
                break;
            case 'four_floor':
                $kicks  = [0, 4, 8, 12];
                $claps  = [4, 12];
                $hats   = [2, 6, 10, 14];
                $opens  = [6, 14];
                break;
            case 'rock':
                $kicks  = [0, 8, 10];
                $snares = [4, 12];
                $hats   = [0,2,4,6,8,10,12,14];
                $toms   = [14];
                break;
            case 'perc':
                $hats   = [0,2,3,5,6,8,9,11,12,14,15];
                $rides  = [0,4,8,12];
                $kicks  = [0, 8];
                break;
        }

        // 2. bar için varyasyon (tekrarı canlandır)
        $kicksFill = array_merge($kicks, array_map(fn($s) => $s + $half, $kicks));
        $snaresFill = array_merge($snares, array_map(fn($s) => $s + $half, $snares));
        $hatsFill = array_merge($hats, array_map(fn($s) => $s + $half, $hats));
        $opensFill = array_merge($opens, array_map(fn($s) => $s + $half, $opens));
        $clapsFill = array_merge($claps, array_map(fn($s) => $s + $half, $claps));
        $tomsFill = array_merge($toms, array_map(fn($s) => $s + $half, $toms));
        $ridesFill = array_merge($rides, array_map(fn($s) => $s + $half, $rides));

        foreach ($kicksFill  as $s) studio_drum_hit($buf, $s * $sSamples, 'kick', 0.95, $sr);
        foreach ($snaresFill as $s) studio_drum_hit($buf, $s * $sSamples, 'snare', 0.62, $sr);
        foreach ($hatsFill   as $s) studio_drum_hit($buf, $s * $sSamples, 'hat_closed', 0.34, $sr);
        foreach ($opensFill  as $s) studio_drum_hit($buf, $s * $sSamples, 'hat_open', 0.30, $sr);
        foreach ($clapsFill  as $s) studio_drum_hit($buf, $s * $sSamples, 'clap', 0.60, $sr);
        foreach ($tomsFill   as $s) studio_drum_hit($buf, $s * $sSamples, 'tom', 0.55, $sr);
        foreach ($ridesFill  as $s) studio_drum_hit($buf, $s * $sSamples, 'ride', 0.26, $sr);

        return $buf;
    }

    // ============ BAS ============
    if ($inst === 'bass') {
        switch ($style) {
            case 'sub_pulse':
                $notes = [[0, $sC - 12, 2], [4, $sC - 12, 2], [8, $sC - 12, 2], [12, $sC - 10, 2]];
                $wave = 'sine'; $amp = 0.85; $decay = 0.9;
                break;
            case 'funk':
                $notes = [
                    [0, $sC - 12, 1], [2, $sC - 7, 1], [3, $sC - 5, 1], [4, $sC - 12, 1],
                    [6, $sC - 12, 1], [8, $sC - 10, 1], [10, $sC - 8, 1], [12, $sC - 12, 1],
                    [13, $sC - 5, 1], [14, $sC - 7, 1]
                ];
                $wave = 'saw'; $amp = 0.6; $decay = 0.35;
                break;
            case 'rock_bass':
                $notes = [[0, $sC - 12, 2], [4, $sC - 12, 1], [6, $sC - 12, 1], [8, $sC - 5, 2], [12, $sC - 7, 2]];
                $wave = 'square'; $amp = 0.55; $decay = 0.5;
                break;
            default:
                $notes = [[0, $sC - 12, 4], [8, $sC - 10, 4]];
                $wave = 'sine'; $amp = 0.8; $decay = 0.8;
        }

        // 2 bar boyunca tekrar
        $bars2 = ($bars > 1);
        foreach ($notes as $n) {
            $start = $n[0] * $sSamples;
            $dur = (int)($n[2] * $sSamples);
            $freq = studio_note_freq($n[1]);
            studio_synth_note($buf, $start, $freq, $dur, $amp, $wave, $sr, $decay);
            if ($bars2) {
                studio_synth_note($buf, $start + $half * $sSamples, $freq, $dur, $amp, $wave, $sr, $decay);
            }
        }
        return $buf;
    }

    // ============ GİTAR ============
    if ($inst === 'guitar') {
        if ($style === 'power') {
            // Güç akoru: kök + beşli (distorsiyonlu saw)
            $chordsRiffs = [
                [0, 4], [8, 4], [12, 2]
            ];
            foreach ($chordsRiffs as $r) {
                $start = $r[0] * $sSamples;
                $dur = (int)($r[1] * $sSamples);
                for ($bar = 0; $bar < $bars; $bar++) {
                    $off = $start + $bar * $half * $sSamples;
                    studio_synth_note($buf, $off, studio_note_freq($sC - 12), $dur, 0.42, 'saw', $sr, 0.4);
                    studio_synth_note($buf, $off, studio_note_freq($sC - 5), $dur, 0.34, 'saw', $sr, 0.4);
                }
            }
        } else { // clean_arp
            $arp = [0, 4, 7, 12, 16, 12, 7, 4];
            $step = 2;
            for ($i = 0; $i < count($arp) * $bars; $i++) {
                $n = $arp[$i % count($arp)];
                $start = ($i * $step) * $sSamples;
                $dur = (int)(2.0 * $sSamples);
                studio_synth_note($buf, $start, studio_note_freq($sC + $n), $dur, 0.4, 'triangle', $sr, 0.7);
            }
        }
        return $buf;
    }

    // ============ PİYANO ============
    if ($inst === 'piano') {
        if ($style === 'piano_chord') {
            // I - VI - IV - V akor yürüyüşü (bar başına bir akor)
            $progressions = [
                [0, 4, 7],    // C
                [9, 12, 16],  // Am
                [5, 9, 12],   // F
                [7, 11, 14],  // G
            ];
            $chordsPerBar = 2;
            for ($bar = 0; $bar < $bars; $bar++) {
                for ($c = 0; $c < $chordsPerBar; $c++) {
                    $chord = $progressions[($bar * $chordsPerBar + $c) % count($progressions)];
                    $start = (int)(($bar * 16 + $c * 8) * $sSamples);
                    $dur = (int)(7.0 * $sSamples);
                    foreach ($chord as $n) {
                        studio_synth_note($buf, $start, studio_note_freq($sC + $n), $dur, 0.30, 'sine', $sr, 0.9);
                        studio_synth_note($buf, $start, studio_note_freq($sC + $n + 12), $dur, 0.12, 'sine', $sr, 0.9);
                    }
                }
            }
        } else { // piano_melody
            $melody = [
                [0, 0, 2], [2, 4, 2], [4, 7, 2], [6, 4, 2],
                [8, 5, 2], [10, 7, 2], [12, 9, 4],
                [16, 7, 2], [18, 5, 2], [20, 4, 2], [22, 2, 2],
                [24, 0, 2], [26, 4, 2], [28, 7, 4],
            ];
            foreach ($melody as $m) {
                $start = $m[0] * $sSamples;
                $dur = (int)($m[2] * $sSamples);
                studio_synth_note($buf, $start, studio_note_freq($sC + $m[1]), $dur, 0.42, 'sine', $sr, 0.8);
                studio_synth_note($buf, $start, studio_note_freq($sC + $m[1] - 12), $dur, 0.18, 'sine', $sr, 0.8);
            }
        }
        return $buf;
    }

    // ============ SENTEZLEYİCİ ============
    if ($inst === 'synth') {
        if ($style === 'synth_pad') {
            // Uzun, yumuşak akor yastığı
            $chords = [[0, 7, 12, 16], [5, 9, 12, 17], [-3, 4, 9, 12], [2, 7, 11, 14]];
            for ($bar = 0; $bar < $bars; $bar++) {
                $chord = $chords[$bar % count($chords)];
                $start = $bar * 16 * $sSamples;
                $dur = (int)(16.0 * $sSamples);
                foreach ($chord as $n) {
                    studio_synth_note($buf, $start, studio_note_freq($sC + $n), $dur, 0.22, 'saw', $sr, 2.2);
                    studio_synth_note($buf, $start, studio_note_freq($sC + $n - 0.08), $dur, 0.12, 'sine', $sr, 2.2);
                }
            }
        } else { // pluck
            $pattern = [0, 7, 12, 7, 5, 9, 12, 9];
            for ($bar = 0; $bar < $bars; $bar++) {
                for ($i = 0; $i < 16; $i++) {
                    if ($i % 2 !== 0) continue;
                    $n = $pattern[($i / 2) % count($pattern)];
                    $start = ($bar * 16 + $i) * $sSamples;
                    $dur = (int)(1.6 * $sSamples);
                    studio_pluck($buf, $start, studio_note_freq($sC + $n + 12), $dur, $sr);
                }
            }
        }
        return $buf;
    }

    return $buf;
}

/** Pluck sesi (kısa, parlak, Karplus-Strong benzeri). */
function studio_pluck(&$buf, $startSample, $freq, $durSamples, $sampleRate = 44100) {
    $total = count($buf);
    $delayLen = max(2, (int)round($sampleRate / max(20, $freq)));
    $line = [];
    for ($i = 0; $i < $delayLen; $i++) {
        $line[$i] = (mt_rand() / mt_getrandmax()) * 2 - 1;
    }
    $idx = 0;
    for ($i = 0; $i < $durSamples; $i++) {
        $pos = $startSample + $i;
        if ($pos >= $total) break;
        $cur = $line[$idx];
        $next = $line[($idx + 1) % $delayLen];
        $avg = 0.5 * ($cur + $next) * 0.996;
        $line[$idx] = $avg;
        $idx = ($idx + 1) % $delayLen;
        if ($pos >= 0) {
            $env = exp(-($i / $sampleRate) * 4.5);
            $buf[$pos] += $cur * $env * 0.55;
        }
    }
}

// ============================================================
// HTML SAYFASI
// ============================================================
$studioUser = null;
$db = studio_db();
if ($db) {
    studio_init_db($db);
    $uid = studio_uid();
    if ($uid) {
        $stmt = $db->prepare("SELECT id, artist, verified FROM users WHERE id = ?");
        $stmt->execute([$uid]);
        $u = $stmt->fetch();
        if ($u) $studioUser = $u;
    }
}

// Dosya yükleme limitleri (istemciye bildirmek için)
$iniUpload = ini_get('upload_max_filesize');
$iniPost   = ini_get('post_max_size');
$uploadLimitText = 'Yükleme limiti: ' . $iniUpload . ' / POST: ' . $iniPost;
?><!DOCTYPE html>
<html lang="tr" data-bs-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#000000">
<meta name="description" content="Kuduko Müzik Yapım Ses Kayıt Stüdyosu — tarayıcıda çok kanallı kayıt, sanal enstrümanlar, efektler ve mastering.">
<title>Ses Kayıt Stüdyosu — Kuduko Müzik Yapım</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<link rel="icon" type="image/jpeg" href="?pwa=icon">
<style>
/* ==========================================================
   DEĞİŞKENLER
   ========================================================== */
:root{
  --bg:#000000;
  --bg-2:#000000;
  --panel:#000000;
  --panel-2:#0a0a0a;
  --panel-3:#141414;
  --line:rgba(255,255,255,.16);
  --line-2:rgba(255,255,255,.30);
  --tx:#ffffff;
  --tx-2:#ffffff;
  --tx-3:rgba(255,255,255,.62);
  --accent:#ffffff;
  --accent-2:#ffffff;
  --ok:#ffffff;
  --warn:#ffffff;
  --info:#ffffff;
  --rec:#ffffff;
  --radius:14px;
  --radius-sm:9px;
  --shadow:0 18px 44px rgba(0,0,0,.7);
  --lane-h:76px;
  --ruler-h:30px;
  --track-head-w:280px;
}
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{
  background:#000000;
  color:var(--tx);
  font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  overflow:hidden;
  -webkit-font-smoothing:antialiased;
}
::-webkit-scrollbar{width:9px;height:9px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:rgba(148,163,184,.22);border-radius:99px}
::-webkit-scrollbar-thumb:hover{background:rgba(148,163,184,.4)}
button{font-family:inherit}
.mono{font-family:'JetBrains Mono',monospace}
.hidden{display:none !important}

/* ==========================================================
   ÜST BAR (TOPBAR)
   ========================================================== */
.studio-app{display:flex;flex-direction:column;height:100vh;overflow:hidden}

.topbar{
  display:flex;align-items:center;gap:.6rem;
  padding:.5rem .85rem;
  background:#000000;
  border-bottom:1px solid var(--line);
  backdrop-filter:blur(14px);
  flex-shrink:0;
  z-index:60;
  flex-wrap:nowrap;
  min-height:56px;
}
.brand{
  display:flex;align-items:center;gap:.55rem;
  font-weight:800;letter-spacing:-.02em;
  white-space:nowrap;
  padding-right:.7rem;
  border-right:1px solid var(--line);
  margin-right:.2rem;
}
.brand-badge{
  width:34px;height:34px;border-radius:10px;
  background:#000000;
  border:1px solid rgba(255,255,255,.35);
  display:flex;align-items:center;justify-content:center;
  font-size:1.05rem;
  box-shadow:0 8px 22px rgba(0,0,0,.6);
  flex-shrink:0;
}
.brand-text small{display:block;font-size:.62rem;color:#ffffff;font-weight:600;letter-spacing:.06em;text-transform:uppercase}
.brand-text span{font-size:.95rem}

.proj-title-input{
  background:rgba(0,0,0,.3);border:1px solid var(--line);color:var(--tx);
  border-radius:9px;padding:.42rem .7rem;font-size:.85rem;font-weight:600;
  min-width:150px;max-width:230px;outline:none;transition:.18s;
}
.proj-title-input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(255,255,255,.16)}

/* Transport */
.transport{
  display:flex;align-items:center;gap:.3rem;
  background:rgba(0,0,0,.32);
  border:1px solid var(--line);
  border-radius:12px;padding:.28rem;
}
.tbtn{
  width:38px;height:38px;border-radius:10px;
  border:1px solid transparent;background:transparent;color:var(--tx-2);
  display:flex;align-items:center;justify-content:center;
  cursor:pointer;font-size:1.05rem;transition:.16s;flex-shrink:0;
}
.tbtn:hover{background:rgba(148,163,184,.12);color:var(--tx)}
.tbtn:active{transform:scale(.94)}
.tbtn.play{background:#ffffff;color:#000000;box-shadow:0 6px 18px rgba(0,0,0,.5)}
.tbtn.play:hover{filter:brightness(1.1)}
.tbtn.rec{color:var(--rec)}
.tbtn.rec:hover{background:rgba(255,255,255,.16)}
.tbtn.rec.armed{background:var(--rec);color:#fff;animation:recPulse 1.5s infinite}
.tbtn.on{background:rgba(255,255,255,.18);color:#ffffff;border-color:rgba(255,255,255,.4)}
.tbtn:disabled{opacity:.35;cursor:not-allowed}
@keyframes recPulse{0%,100%{box-shadow:0 0 0 0 rgba(255,255,255,.55)}50%{box-shadow:0 0 0 8px rgba(255,255,255,0)}}

.time-display{
  font-family:'JetBrains Mono',monospace;font-size:1.15rem;font-weight:600;
  background:#05070c;border:1px solid var(--line);border-radius:10px;
  padding:.3rem .7rem;letter-spacing:.03em;
  color:#ffffff;text-shadow:0 0 14px rgba(255,255,255,.35);
  white-space:nowrap;
}
.time-display.rec{color:#ffffff;text-shadow:0 0 14px rgba(255,255,255,.5)}

/* Parametre grupları */
.params{display:flex;align-items:center;gap:.55rem;flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none}
.params::-webkit-scrollbar{display:none}
.param{
  display:flex;flex-direction:column;gap:2px;
  background:rgba(0,0,0,.28);border:1px solid var(--line);
  border-radius:10px;padding:.26rem .55rem;min-width:74px;flex-shrink:0;
}
.param label{font-size:.58rem;color:var(--tx-3);font-weight:700;letter-spacing:.07em;text-transform:uppercase;margin:0}
.param select,.param input{
  background:transparent;border:none;color:var(--tx);font-weight:700;font-size:.85rem;
  outline:none;padding:0;width:100%;cursor:pointer;font-family:inherit;
}
.param select option{background:var(--panel);color:var(--tx)}
.param input[type=number]{-moz-appearance:textfield}
.param input::-webkit-outer-spin-button,.param input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}

.spacer{flex:1}
.top-actions{display:flex;align-items:center;gap:.4rem;flex-shrink:0}
.ibtn{
  height:36px;padding:0 .7rem;border-radius:10px;
  border:1px solid var(--line);background:rgba(255,255,255,.03);color:var(--tx-2);
  display:inline-flex;align-items:center;gap:.4rem;cursor:pointer;
  font-size:.8rem;font-weight:600;white-space:nowrap;transition:.16s;
}
.ibtn:hover{background:rgba(148,163,184,.12);color:var(--tx);border-color:var(--line-2)}
.ibtn.primary{background:#ffffff;border-color:transparent;color:#000000;box-shadow:0 6px 18px rgba(0,0,0,.5)}
.ibtn.primary:hover{filter:brightness(1.08)}
.ibtn.ghost{background:transparent}
.ibtn.danger:hover{background:rgba(255,255,255,.16);color:#ffffff;border-color:rgba(255,255,255,.4)}

.user-chip{
  display:flex;align-items:center;gap:.45rem;
  background:rgba(255,255,255,.04);border:1px solid var(--line);
  border-radius:99px;padding:.2rem .6rem .2rem .25rem;flex-shrink:0;
}
.user-chip img{width:26px;height:26px;border-radius:50%;object-fit:cover;background:var(--panel-3)}
.user-chip span{font-size:.78rem;font-weight:600;max-width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ==========================================================
   ANA GÖVDE
   ========================================================== */
.main{
  display:flex;flex:1;min-height:0;overflow:hidden;
}

/* Sol dikey araç şeridi */
.toolrail{
  width:62px;flex-shrink:0;
  background:#000000;
  border-right:1px solid var(--line);
  display:flex;flex-direction:column;align-items:center;
  gap:.3rem;padding:.6rem 0;overflow-y:auto;
}
.toolrail::-webkit-scrollbar{width:0}
.rail-btn{
  width:44px;height:44px;border-radius:12px;
  border:1px solid transparent;background:transparent;color:var(--tx-3);
  display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;
  cursor:pointer;transition:.16s;font-size:1rem;flex-shrink:0;position:relative;
}
.rail-btn small{font-size:.52rem;font-weight:700;letter-spacing:.02em}
.rail-btn:hover{background:rgba(148,163,184,.12);color:var(--tx)}
.rail-btn.active{background:rgba(255,255,255,.16);color:#ffffff;border-color:rgba(255,255,255,.35)}
.rail-sep{width:34px;height:1px;background:var(--line);margin:.3rem 0;flex-shrink:0}

/* Merkez sütun */
.center{display:flex;flex-direction:column;flex:1;min-width:0;overflow:hidden}

/* ==========================================================
   ZAMAN ÇİZELGESİ (TIMELINE)
   ========================================================== */
.timeline-wrap{
  flex:1;min-height:0;display:flex;flex-direction:column;
  background:rgba(0,0,0,.5);
  overflow:hidden;
}
.tl-scroll{
  flex:1;overflow:auto;position:relative;
}
.tl-inner{position:relative;min-width:100%}

/* Cetvel satırı */
.ruler-row{display:flex;position:sticky;top:0;z-index:30;height:var(--ruler-h)}
.ruler-corner{
  width:var(--track-head-w);min-width:var(--track-head-w);
  background:linear-gradient(180deg,var(--panel-2),var(--panel));
  border-right:1px solid var(--line);border-bottom:1px solid var(--line);
  position:sticky;left:0;z-index:32;
  display:flex;align-items:center;justify-content:space-between;
  padding:0 .5rem;font-size:.65rem;color:var(--tx-3);font-weight:700;
  letter-spacing:.05em;
}
.ruler-corner .zoom-btns{display:flex;gap:2px}
.zoom-btns button{
  width:22px;height:20px;border-radius:5px;border:1px solid var(--line);
  background:rgba(0,0,0,.3);color:var(--tx-2);font-size:.7rem;cursor:pointer;
  display:flex;align-items:center;justify-content:center;padding:0;line-height:1;
}
.zoom-btns button:hover{background:rgba(148,163,184,.16);color:#fff}

.ruler{
  position:relative;height:var(--ruler-h);
  background:linear-gradient(180deg,var(--panel-2),var(--panel));
  border-bottom:1px solid var(--line);
  flex:1;
}
.ruler-tick{position:absolute;top:0;bottom:0;width:0;border-left:1px solid rgba(148,163,184,.13)}
.ruler-tick.major{border-left-color:rgba(148,163,184,.34)}
.ruler-label{
  position:absolute;top:5px;font-size:.6rem;color:var(--tx-3);
  font-family:'JetBrains Mono',monospace;transform:translateX(4px);
  pointer-events:none;white-space:nowrap;font-weight:600;
}

/* Şarkı işaretçisi */
.playhead{
  position:absolute;top:0;bottom:0;width:2px;
  background:linear-gradient(180deg,#ffffff,#ffffff 60%,transparent);
  pointer-events:none;z-index:26;
  box-shadow:0 0 12px rgba(255,255,255,.7);
}
.playhead::before{
  content:'';position:absolute;top:0;left:-6px;
  border-left:7px solid transparent;border-right:7px solid transparent;
  border-top:9px solid #ffffff;
}

/* Loop çalma bölgesi */
.loop-region{
  position:absolute;top:0;height:var(--ruler-h);
  background:rgba(255,255,255,.2);
  border-left:2px solid #ffffff;border-right:2px solid #ffffff;
  pointer-events:none;z-index:25;display:none;
}

/* Kanal satırları */
.tracks-area{position:relative}
.track-row{
  display:flex;height:var(--lane-h);
  border-bottom:1px solid rgba(148,163,184,.07);
  position:relative;
}
.track-row.selected{background:rgba(255,255,255,.05)}

/* Kanal başlığı (sol sabit sütun) */
.track-head{
  width:var(--track-head-w);min-width:var(--track-head-w);
  position:sticky;left:0;z-index:20;
  background:#0a0a0a;
  border-right:1px solid var(--line);
  display:flex;flex-direction:column;justify-content:center;
  gap:4px;padding:.35rem .5rem .35rem .6rem;
}
.track-row.selected .track-head{border-right-color:var(--accent)}

.th-top{display:flex;align-items:center;gap:.4rem;min-width:0}
.th-color{width:4px;height:26px;border-radius:99px;flex-shrink:0}
.th-meta{flex:1;min-width:0}
.th-name{
  font-size:.78rem;font-weight:700;white-space:nowrap;overflow:hidden;
  text-overflow:ellipsis;line-height:1.2;
}
.track-name-input{
  width:100%;background:transparent;border:none;color:var(--tx);
  font-size:.78rem;font-weight:700;outline:none;padding:0;
}
.track-name-input:focus{background:rgba(0,0,0,.4);border-radius:4px;padding:0 .2rem}
.th-type{font-size:.6rem;color:var(--tx-3);font-weight:600;letter-spacing:.03em}

.th-btns{display:flex;gap:3px;flex-shrink:0}
.mini-btn{
  width:26px;height:24px;border-radius:6px;border:1px solid var(--line);
  background:rgba(0,0,0,.28);color:var(--tx-3);cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  font-size:.68rem;font-weight:800;transition:.14s;padding:0;line-height:1;
}
.mini-btn:hover{background:rgba(148,163,184,.16);color:#fff}
.mini-btn.m.on{background:#ffffff;color:#000000;border-color:#ffffff}
.mini-btn.s.on{background:#ffffff;color:#000000;border-color:#ffffff}
.mini-btn.r.armed{background:var(--rec);color:#fff;border-color:var(--rec);animation:recPulse 1.5s infinite}

.th-sliders{display:flex;align-items:center;gap:.35rem}
.th-slider{flex:1;min-width:0}
.th-slider input[type=range]{width:100%;height:14px;margin:0}
.th-slider label{display:flex;justify-content:space-between;font-size:.55rem;color:var(--tx-3);font-weight:700;letter-spacing:.04em}

/* Özel range */
input[type=range]{
  -webkit-appearance:none;appearance:none;background:transparent;cursor:pointer;height:16px;
}
input[type=range]::-webkit-slider-runnable-track{
  height:4px;border-radius:99px;
  background:linear-gradient(90deg,var(--accent) var(--pct,50%),rgba(148,163,184,.2) var(--pct,50%));
}
input[type=range]::-webkit-slider-thumb{
  -webkit-appearance:none;width:12px;height:12px;border-radius:50%;
  background:#fff;margin-top:-4px;box-shadow:0 0 6px rgba(0,0,0,.6);transition:.14s;
}
input[type=range]:hover::-webkit-slider-thumb{background:#ffffff;transform:scale(1.18)}
input[type=range]::-moz-range-track{height:4px;border-radius:99px;background:rgba(148,163,184,.2)}
input[type=range]::-moz-range-progress{height:4px;border-radius:99px;background:var(--accent)}
input[type=range]::-moz-range-thumb{width:12px;height:12px;border:none;border-radius:50%;background:#fff}

/* Kanal yolu (clip alanı) */
.track-lane{
  position:relative;flex:1;min-width:0;
  background-image:
    linear-gradient(90deg,rgba(148,163,184,.055) 1px,transparent 1px);
  background-repeat:repeat-x;
}
.track-row.selected .track-lane{background-color:rgba(255,255,255,.03)}
.lane-hit{position:absolute;inset:0}

/* Bölge (region) kutuları */
.region{
  position:absolute;top:6px;bottom:6px;
  border-radius:7px;overflow:hidden;cursor:grab;
  border:1px solid rgba(255,255,255,.22);
  box-shadow:0 3px 12px rgba(0,0,0,.42);
  transition:box-shadow .14s;
  min-width:10px;
}
.region:hover{box-shadow:0 0 0 2px rgba(255,255,255,.4),0 4px 16px rgba(0,0,0,.5)}
.region.dragging{opacity:.65;cursor:grabbing;z-index:40}
.region.recording{border-color:var(--rec);box-shadow:0 0 0 2px rgba(255,255,255,.5)}
.region-head{
  display:flex;align-items:center;gap:.25rem;padding:2px 5px;
  font-size:.6rem;font-weight:700;white-space:nowrap;overflow:hidden;
  background:rgba(0,0,0,.3);
}
.region-head .rname{overflow:hidden;text-overflow:ellipsis}
.region-head .rtool{margin-left:auto;cursor:pointer;opacity:.55;flex-shrink:0}
.region-head .rtool:hover{opacity:1;color:#ffffff}
.region canvas{display:block;width:100%;height:calc(100% - 17px)}

/* Bölge yeniden boyutlandırma tutamaçları (sağ/sol kenar) */
.region-resize{
  position:absolute;top:0;bottom:0;width:8px;cursor:ew-resize;z-index:5;
  background:transparent;transition:background .14s;
}
.region-resize:hover{background:rgba(255,255,255,.32)}
.region-resize.rl{left:0}
.region-resize.rr{right:0}
.region.resizing{opacity:.75;box-shadow:0 0 0 2px rgba(255,255,255,.55)}

/* Boş kanal ipucu */
.lane-hint{
  position:absolute;left:12px;top:50%;transform:translateY(-50%);
  font-size:.66rem;color:rgba(255,255,255,.5);pointer-events:none;
  display:flex;align-items:center;gap:.35rem;white-space:nowrap;
}

/* Izgara çizgileri */
.grid-line{position:absolute;top:0;bottom:0;width:0;border-left:1px solid rgba(148,163,184,.055);pointer-events:none}
.grid-line.bar{border-left-color:rgba(148,163,184,.17)}

/* ==========================================================
   ALT PANEL (MIXER / ENSTRÜMAN / LOOPS / EFEKT)
   ========================================================== */
.bottom-dock{
  height:300px;flex-shrink:0;
  background:#000000;
  border-top:1px solid var(--line);
  display:flex;flex-direction:column;
  transition:height .22s ease;
  overflow:hidden;
}
.bottom-dock.collapsed{height:44px}
.dock-head{
  height:44px;flex-shrink:0;display:flex;align-items:center;gap:.4rem;
  padding:0 .7rem;border-bottom:1px solid var(--line);
  background:rgba(0,0,0,.24);
}
.dock-tab{
  height:30px;padding:0 .8rem;border-radius:8px;border:1px solid transparent;
  background:transparent;color:var(--tx-3);font-size:.76rem;font-weight:700;
  cursor:pointer;display:inline-flex;align-items:center;gap:.35rem;transition:.16s;
  white-space:nowrap;
}
.dock-tab:hover{color:var(--tx);background:rgba(148,163,184,.1)}
.dock-tab.active{background:rgba(255,255,255,.16);color:#ffffff;border-color:rgba(255,255,255,.32)}
.dock-body{flex:1;overflow:auto;padding:.7rem;min-height:0}
.dock-pane{display:none}
.dock-pane.active{display:block}

/* Mixer */
.mixer-strip-wrap{display:flex;gap:.55rem;overflow-x:auto;padding-bottom:.4rem;align-items:stretch}
.mixer-strip{
  width:86px;flex-shrink:0;
  background:#0a0a0a;
  border:1px solid var(--line);border-radius:12px;
  padding:.5rem .4rem;display:flex;flex-direction:column;gap:.4rem;align-items:center;
}
.mixer-strip.master{width:100px;border-color:rgba(255,255,255,.4);background:#141414}
.ms-name{font-size:.62rem;font-weight:800;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%}
.ms-fader{
  -webkit-appearance:none;appearance:none;writing-mode:vertical-lr;direction:rtl;
  width:20px;height:112px;background:transparent;cursor:pointer;
}
.ms-fader::-webkit-slider-runnable-track{width:4px;background:rgba(148,163,184,.2);border-radius:99px}
.ms-fader::-webkit-slider-thumb{
  -webkit-appearance:none;width:18px;height:11px;border-radius:3px;
  background:linear-gradient(180deg,#e6edff,#9fb0cc);margin-left:-7px;box-shadow:0 2px 6px rgba(0,0,0,.6);
}
.ms-fader::-moz-range-track{width:4px;background:rgba(148,163,184,.2);border-radius:99px}
.ms-fader::-moz-range-thumb{width:18px;height:11px;border-radius:3px;border:none;background:linear-gradient(180deg,#e6edff,#9fb0cc)}
.ms-db{font-size:.56rem;font-family:'JetBrains Mono',monospace;color:var(--tx-3)}
.ms-meter{width:100%;height:5px;background:rgba(0,0,0,.4);border-radius:99px;overflow:hidden}
.ms-meter i{display:block;height:100%;width:0%;background:#ffffff;transition:width .08s linear}
.ms-row{display:flex;gap:3px}
.ms-row .mini-btn{width:24px;height:22px;font-size:.62rem}

/* Loop kütüphanesi */
.loop-toolbar{display:flex;gap:.4rem;align-items:center;margin-bottom:.6rem;flex-wrap:wrap}
.chip{
  height:27px;padding:0 .65rem;border-radius:99px;border:1px solid var(--line);
  background:rgba(255,255,255,.03);color:var(--tx-2);font-size:.7rem;font-weight:700;
  cursor:pointer;display:inline-flex;align-items:center;gap:.3rem;transition:.15s;
}
.chip:hover{background:rgba(148,163,184,.14);color:#fff}
.chip.active{background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;border-color:transparent}

.loops-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(212px,1fr));gap:.55rem}
.loop-card{
  background:#0a0a0a;
  border:1px solid var(--line);border-radius:11px;padding:.55rem .65rem;
  display:flex;align-items:center;gap:.55rem;cursor:pointer;transition:.16s;position:relative;
  overflow:hidden;
}
.loop-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--lc,#ffffff)}
.loop-card:hover{border-color:var(--line-2);transform:translateY(-2px);box-shadow:0 10px 24px rgba(0,0,0,.4)}
.loop-card.playing{border-color:var(--ok);box-shadow:0 0 0 2px rgba(255,255,255,.3)}
.lc-play{
  width:32px;height:32px;border-radius:9px;flex-shrink:0;
  background:rgba(0,0,0,.35);border:1px solid var(--line);
  color:var(--tx);display:flex;align-items:center;justify-content:center;
  font-size:.85rem;cursor:pointer;
}
.loop-card.playing .lc-play{background:var(--ok);color:#04180c;border-color:transparent}
.lc-info{flex:1;min-width:0}
.lc-name{font-size:.76rem;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lc-meta{font-size:.6rem;color:var(--tx-3);font-weight:600}
.lc-add{
  width:28px;height:28px;border-radius:8px;flex-shrink:0;
  background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.3);
  color:#ffffff;display:flex;align-items:center;justify-content:center;
  font-size:.8rem;cursor:pointer;
}
.lc-add:hover{background:var(--accent);color:#fff}

/* Enstrüman panelleri */
.inst-wrap{display:flex;gap:.7rem;flex-wrap:wrap}
.panel-box{
  background:#0a0a0a;
  border:1px solid var(--line);border-radius:13px;padding:.75rem .85rem;
}
.panel-box h6{
  font-size:.72rem;font-weight:800;letter-spacing:.05em;text-transform:uppercase;
  color:var(--tx-3);margin-bottom:.6rem;display:flex;align-items:center;gap:.4rem;
}

/* Piyano */
.piano{display:flex;position:relative;height:110px;user-select:none}
.pkey{
  position:relative;width:34px;
  background:linear-gradient(180deg,#f3f6ff,#c8d2e4);
  border:1px solid #97a3b8;border-radius:0 0 4px 4px;
  cursor:pointer;flex-shrink:0;
}
.pkey:active,.pkey.on{background:linear-gradient(180deg,#ffffff,#cccccc)}
.pkey.black{
  position:absolute;width:22px;height:65%;margin-left:-11px;z-index:3;
  background:linear-gradient(180deg,#2a3040,#0a0d15);border-color:#000;
  border-radius:0 0 3px 3px;
}
.pkey.black:active,.pkey.black.on{background:linear-gradient(180deg,#ff5f7a,#b91c2c)}

/* Davul makinesi */
.dm-seq{display:flex;flex-direction:column;gap:3px;overflow-x:auto;padding-bottom:.3rem}
.dm-row{display:flex;align-items:center;gap:3px;min-width:max-content}
.dm-lbl{width:82px;flex-shrink:0;font-size:.63rem;font-weight:700;color:var(--tx-2);text-align:right;padding-right:.4rem}
.dm-step{
  width:25px;height:25px;border-radius:6px;flex-shrink:0;cursor:pointer;
  background:rgba(0,0,0,.34);border:1px solid var(--line);transition:.1s;
  position:relative;
}
.dm-step:nth-child(4n+2){background:rgba(0,0,0,.5)}
.dm-step:hover{border-color:var(--line-2)}
.dm-step.on{background:linear-gradient(135deg,var(--sc,#ffffff),rgba(255,255,255,.16));border-color:transparent;box-shadow:0 0 10px rgba(255,255,255,.55)}
.dm-step.beat{outline:1px solid rgba(148,163,184,.3)}
.dm-step.playing::after{
  content:'';position:absolute;inset:-4px auto -4px -1px;width:2px;background:#fff;
}

/* Efekt panelleri */
.fx-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(268px,1fr));gap:.7rem}
.fx-card{
  background:#0a0a0a;
  border:1px solid var(--line);border-radius:13px;padding:.8rem .9rem;
}
.fx-card-head{display:flex;align-items:center;gap:.5rem;margin-bottom:.65rem}
.fx-icon{
  width:32px;height:32px;border-radius:9px;display:flex;align-items:center;justify-content:center;
  font-size:.95rem;flex-shrink:0;background:rgba(255,255,255,.14);color:#ffffff;
}
.fx-title{flex:1;min-width:0}
.fx-title b{display:block;font-size:.8rem;font-weight:700}
.fx-title small{font-size:.62rem;color:var(--tx-3)}
.switch{position:relative;width:40px;height:22px;flex-shrink:0}
.switch input{opacity:0;width:0;height:0;position:absolute}
.switch span{
  position:absolute;inset:0;background:rgba(148,163,184,.24);border-radius:99px;
  cursor:pointer;transition:.2s;
}
.switch span::before{
  content:'';position:absolute;height:16px;width:16px;left:3px;top:3px;
  background:#fff;border-radius:50%;transition:.2s;
}
.switch input:checked + span{background:linear-gradient(135deg,var(--accent),var(--accent-2))}
.switch input:checked + span::before{transform:translateX(18px)}

.knob-row{display:flex;flex-direction:column;gap:.5rem}
.knob{display:flex;flex-direction:column;gap:2px}
.knob label{display:flex;justify-content:space-between;font-size:.64rem;font-weight:700;color:var(--tx-2)}
.knob label span{color:var(--tx-3);font-family:'JetBrains Mono',monospace;font-size:.6rem}

/* Terzi/ayraç */
.sep-v{width:1px;align-self:stretch;background:var(--line);margin:0 .15rem}

/* ==========================================================
   MODAL
   ========================================================== */
.modal-content{
  background:#0a0a0a;
  border:1px solid var(--line-2);border-radius:18px;color:var(--tx);
  box-shadow:var(--shadow);
}
.modal-header,.modal-footer{border-color:var(--line)}
.modal-title{font-weight:800;font-size:1rem}
.form-control,.form-select{
  background:rgba(0,0,0,.34);border:1px solid var(--line);color:var(--tx);
  border-radius:10px;font-size:.84rem;
}
.form-control:focus,.form-select:focus{
  background:rgba(0,0,0,.34);border-color:var(--accent);color:var(--tx);
  box-shadow:0 0 0 3px rgba(255,255,255,.16);
}
.form-control::placeholder{color:var(--tx-3)}
.form-select option{background:var(--panel);color:var(--tx)}
.form-label{font-size:.72rem;font-weight:700;color:var(--tx-2);letter-spacing:.03em;margin-bottom:.25rem}

.proj-item{
  display:flex;align-items:center;gap:.6rem;padding:.6rem .7rem;
  border:1px solid var(--line);border-radius:11px;margin-bottom:.5rem;
  background:rgba(0,0,0,.24);transition:.15s;
}
.proj-item:hover{border-color:var(--line-2);background:rgba(148,163,184,.06)}
.proj-item .pi-info{flex:1;min-width:0}
.proj-item .pi-info b{display:block;font-size:.82rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.proj-item .pi-info small{font-size:.64rem;color:var(--tx-3)}

/* Bildirim */
.toast-host{position:fixed;bottom:1rem;right:1rem;z-index:1090;display:flex;flex-direction:column;gap:.45rem;pointer-events:none}
.tst{
  pointer-events:auto;min-width:250px;max-width:340px;
  background:#0a0a0a;
  border:1px solid var(--line-2);border-left:4px solid var(--accent);
  border-radius:11px;padding:.65rem .85rem;font-size:.8rem;font-weight:600;
  box-shadow:var(--shadow);animation:tstIn .25s ease;
  display:flex;align-items:flex-start;gap:.5rem;
}
.tst.ok{border-left-color:var(--ok)}
.tst.err{border-left-color:var(--accent)}
.tst.info{border-left-color:var(--info)}
.tst i{font-size:.95rem;margin-top:1px}
.tst.ok i{color:var(--ok)} .tst.err i{color:var(--accent)} .tst.info i{color:var(--info)}
@keyframes tstIn{from{opacity:0;transform:translateX(30px)}to{opacity:1;transform:none}}

/* Kayıt göstergesi / durum çubuğu */
.statusbar{
  height:26px;flex-shrink:0;display:flex;align-items:center;gap:.7rem;
  padding:0 .7rem;background:#05070c;border-top:1px solid var(--line);
  font-size:.66rem;color:var(--tx-3);font-weight:600;
  font-family:'JetBrains Mono',monospace;overflow-x:auto;white-space:nowrap;
}
.statusbar .st{display:flex;align-items:center;gap:.3rem}
.statusbar .dot{width:7px;height:7px;border-radius:50%;background:var(--tx-3)}
.statusbar .dot.ok{background:var(--ok);box-shadow:0 0 8px var(--ok)}
.statusbar .dot.rec{background:var(--rec);box-shadow:0 0 8px var(--rec);animation:recPulse 1.4s infinite}
.statusbar .dot.warn{background:var(--warn)}

/* Sürükle-bırak vurgusu */
.drop-target{outline:2px dashed var(--ok);outline-offset:-3px;background:rgba(255,255,255,.07)}

/* Yükleniyor */
.loading-wrap{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:2.5rem;gap:.7rem;color:var(--tx-3);font-size:.8rem}

/* Yardım kısayol tablosu */
kbd{
  background:rgba(0,0,0,.5);border:1px solid var(--line-2);border-bottom-width:2px;
  border-radius:5px;padding:1px 6px;font-family:'JetBrains Mono',monospace;
  font-size:.72rem;color:var(--tx);
}

/* ==========================================================
   DUYARLI (RESPONSIVE)
   ========================================================== */
@media (max-width:1180px){
  :root{--track-head-w:230px}
  .brand-text small{display:none}
}
@media (max-width:900px){
  html{font-size:14px}
  :root{--track-head-w:150px;--lane-h:58px}

  .topbar{flex-wrap:wrap;min-height:auto;padding:.4rem .55rem;gap:.4rem}
  .brand{border-right:none;padding-right:0;margin-right:0}
  .brand-badge{width:28px;height:28px;border-radius:8px;font-size:.85rem}
  .brand-text{display:none}

  .proj-title-input{flex:1;min-width:0;max-width:none;font-size:.78rem;padding:.35rem .55rem}

  .transport{gap:.15rem;padding:.2rem}
  .tbtn{width:30px;height:30px;font-size:.85rem;border-radius:8px}

  .time-display{font-size:.72rem;padding:.22rem .4rem;border-radius:8px}

  .top-actions{gap:.28rem}
  .ibtn{height:28px;padding:0 .45rem;border-radius:8px;font-size:.72rem}
  .ibtn span{display:none}
  .user-chip{padding:.15rem .4rem .15rem .15rem}
  .user-chip img{width:20px;height:20px}
  .user-chip span{display:none}

  /* Parametreler: kompakt 4 sütunlu ızgara, tam genişlik yeni satır */
  .params{
    order:10;width:100%;
    display:grid;grid-template-columns:repeat(4,1fr);
    gap:.35rem;overflow:visible;flex-wrap:unset;
  }
  .param{min-width:0;width:100%;padding:.2rem .4rem;border-radius:8px;align-items:flex-start}
  .param label{font-size:.52rem}
  .param select,.param input{font-size:.76rem}

  /* Sol araç şeridi */
  .toolrail{width:42px;padding:.4rem 0;gap:.15rem}
  .rail-btn{width:32px;height:32px;border-radius:9px;font-size:.8rem}
  .rail-btn small{display:none}
  .rail-sep{width:24px;margin:.2rem 0}

  /* Alt panel (mikser / loop / enstrüman) */
  .bottom-dock{height:225px}
  .dock-head{height:38px;padding:0 .5rem;gap:.2rem}
  .dock-tab{height:26px;padding:0 .55rem;font-size:.68rem;border-radius:7px}
  .dock-body{padding:.5rem}

  /* Mikser şeritleri */
  .mixer-strip-wrap{gap:.4rem}
  .mixer-strip{width:66px;padding:.4rem .3rem;border-radius:10px;gap:.3rem}
  .mixer-strip.master{width:76px}
  .ms-name{font-size:.56rem}
  .ms-fader{height:82px}
  .ms-db{font-size:.52rem}
  .ms-row .mini-btn{width:20px;height:19px;font-size:.55rem}
}
@media (max-width:600px){
  html{font-size:13px}
  :root{--track-head-w:118px;--lane-h:50px}

  .params{grid-template-columns:repeat(2,1fr)}
  .dock-body{padding:.4rem}
  .loops-grid{grid-template-columns:1fr 1fr}
  .mixer-strip{width:60px}
  .mixer-strip.master{width:68px}
  .ms-fader{height:66px}
  .piano{height:78px}
  .pkey{width:24px}
  .pkey.black{width:16px;margin-left:-8px}

  .proj-title-input{font-size:.74rem;padding:.3rem .5rem}
  .tbtn{width:28px;height:28px}
  .rail-btn{width:30px;height:30px}
}
@media (max-width:380px){
  .tbtn{width:26px;height:26px;font-size:.78rem}
  .transport{gap:.1rem}
  .time-display{font-size:.66rem;padding:.18rem .32rem}
  .ibtn{padding:0 .35rem}
}
</style>
</head>
<body>
<div class="studio-app">

  <!-- ============================================================
       ÜST BAR
       ============================================================ -->
  <div class="topbar">
    <div class="brand">
      <div class="brand-badge">🎙️</div>
      <div class="brand-text">
        <small>Kuduko Müzik Yapım</small>
        <span>Ses Kayıt Stüdyosu</span>
      </div>
    </div>

    <input type="text" class="proj-title-input" id="projectTitle" value="Yeni Proje" maxlength="120" placeholder="Proje adı" title="Proje adı">

    <!-- Transport -->
    <div class="transport">
      <button class="tbtn" id="btnRewind" title="Başa dön (Home)"><i class="bi bi-skip-backward-fill"></i></button>
      <button class="tbtn" id="btnPlay" title="Çal / Durdur (Space)"><i class="bi bi-play-fill"></i></button>
      <button class="tbtn rec" id="btnRec" title="Kayıt (R)"><i class="bi bi-record-circle"></i></button>
      <button class="tbtn" id="btnStop" title="Durdur ve başa dön"><i class="bi bi-stop-fill"></i></button>
      <button class="tbtn" id="btnMetronome" title="Metronom (M)"><i class="bi bi-music-note"></i></button>
      <button class="tbtn" id="btnLoop" title="Döngü (L)"><i class="bi bi-arrow-repeat"></i></button>
    </div>

    <div class="time-display" id="timeDisplay">1.1.1<span style="opacity:.45"> · </span>00:00.0</div>

    <!-- Proje parametreleri -->
    <div class="params">
      <div class="param">
        <label for="bpmInput">Tempo</label>
        <input type="number" id="bpmInput" value="120" min="30" max="300" title="Dakikadaki vuruş (BPM)">
      </div>
      <div class="param">
        <label for="timeSig">Ölçü</label>
        <select id="timeSig" title="Ölçü birimi">
          <option value="2/4">2/4</option>
          <option value="3/4">3/4</option>
          <option value="4/4" selected>4/4</option>
          <option value="5/4">5/4</option>
          <option value="6/8">6/8</option>
          <option value="7/8">7/8</option>
        </select>
      </div>
      <div class="param">
        <label for="keySelect">Ton</label>
        <select id="keySelect" title="Müzikal ton">
          <option value="C">C Majör</option>
          <option value="G">G Majör</option>
          <option value="D">D Majör</option>
          <option value="A">A Majör</option>
          <option value="E">E Majör</option>
          <option value="F">F Majör</option>
          <option value="Am">A Minör</option>
          <option value="Em">E Minör</option>
          <option value="Dm">D Minör</option>
          <option value="Bm">B Minör</option>
        </select>
      </div>
      <div class="param">
        <label for="snapSelect">Izgara</label>
        <select id="snapSelect" title="Izgara yakalama">
          <option value="1">1 Vuruş</option>
          <option value="0.5">1/2</option>
          <option value="0.25" selected>1/4</option>
          <option value="0.125">1/8</option>
          <option value="0">Kapalı</option>
        </select>
      </div>
    </div>

    <div class="spacer"></div>

    <!-- Sağ taraf eylemleri -->
    <div class="top-actions">
      <button class="ibtn" id="btnProjects" title="Projelerim"><i class="bi bi-folder2-open"></i><span>Projeler</span></button>
      <button class="ibtn primary" id="btnSave" title="Kaydet (Ctrl+S)"><i class="bi bi-cloud-check-fill"></i><span>Kaydet</span></button>
      <button class="ibtn" id="btnExport" title="Mixdown (WAV) indir"><i class="bi bi-download"></i><span>Mixdown</span></button>
      <div class="sep-v"></div>
      <button class="ibtn ghost" id="btnHelp" title="Klavye kısayolları"><i class="bi bi-question-lg"></i></button>
      <button class="ibtn ghost" id="btnBack" title="Müzik platformuna dön"><i class="bi bi-box-arrow-up-right"></i></button>
      <div class="user-chip" id="userChip">
        <img src="index.php?action=get_profile_picture&amp;id=0" alt="Profil" id="userChipPic"
             onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 16 16%22 fill=%22%236f7f9c%22%3E%3Ccircle cx=%228%22 cy=%228%22 r=%228%22/%3E%3C/svg%3E'">
        <span id="userChipName">Misafir</span>
      </div>
    </div>
  </div>

  <!-- ============================================================
       ANA GÖVDE
       ============================================================ -->
  <div class="main">

    <!-- Sol araç şeridi -->
    <div class="toolrail">
      <button class="rail-btn active" data-tool="pointer" title="Seçim aracı"><i class="bi bi-cursor-fill"></i><small>Seç</small></button>
      <button class="rail-btn" data-tool="cut" title="Bölme aracı"><i class="bi bi-scissors"></i><small>Böl</small></button>
      <button class="rail-btn" data-tool="erase" title="Silme aracı"><i class="bi bi-eraser"></i><small>Sil</small></button>
      <div class="rail-sep"></div>
      <button class="rail-btn" id="railAddTrack" title="Yeni kanal ekle"><i class="bi bi-plus-lg"></i><small>Kanal</small></button>
      <button class="rail-btn" id="railLoops" title="Loop kütüphanesi"><i class="bi bi-grid-3x3-gap-fill"></i><small>Loop</small></button>
      <button class="rail-btn" id="railInstr" title="Sanal enstrümanlar"><i class="bi bi-piano-keys"></i><small>Enst.</small></button>
      <div class="rail-sep"></div>
      <button class="rail-btn" id="railMixer" title="Mikser"><i class="bi bi-sliders"></i><small>Miks</small></button>
      <button class="rail-btn" id="railFx" title="Efektler"><i class="bi bi-magic"></i><small>FX</small></button>
      <button class="rail-btn" id="railSplit" title="Vokal / Enstrüman ayır"><i class="bi bi-scissors"></i><small>Ayır</small></button>
      <button class="rail-btn" id="railMaster" title="Mastering"><i class="bi bi-stars"></i><small>Mastr.</small></button>
      <div class="rail-sep"></div>
      <button class="rail-btn" id="railImport" title="Ses dosyası içe aktar"><i class="bi bi-file-earmark-arrow-up"></i><small>İçe</small></button>
      <button class="rail-btn" id="railZoomFit" title="Tümünü sığdır"><i class="bi bi-arrows-angle-expand"></i><small>Sığdır</small></button>
    </div>

    <!-- Merkez -->
    <div class="center">
      <div class="timeline-wrap">
        <div class="tl-scroll" id="tlScroll">
          <div class="tl-inner" id="tlInner">

            <!-- Cetvel -->
            <div class="ruler-row">
              <div class="ruler-corner">
                <span id="trackCountLabel">0 KANAL</span>
                <div class="zoom-btns">
                  <button id="zoomOut" title="Uzaklaştır">−</button>
                  <button id="zoomIn" title="Yakınlaştır">+</button>
                </div>
              </div>
              <div class="ruler" id="ruler">
                <div class="loop-region" id="loopRegion"></div>
              </div>
            </div>

            <!-- Kanallar + şarkı işaretçisi -->
            <div class="tracks-area" id="tracksArea">
              <div class="playhead" id="playhead" style="left:var(--track-head-w)"></div>
            </div>

          </div>
        </div>
      </div>

      <!-- Alt panel -->
      <div class="bottom-dock" id="bottomDock">
        <div class="dock-head">
          <button class="dock-tab active" data-dock="mixer"><i class="bi bi-sliders"></i> Mikser</button>
          <button class="dock-tab" data-dock="loops"><i class="bi bi-grid-3x3-gap-fill"></i> Loop Kütüphanesi</button>
          <button class="dock-tab" data-dock="instruments"><i class="bi bi-piano-keys"></i> Enstrümanlar</button>
          <button class="dock-tab" data-dock="fx"><i class="bi bi-magic"></i> Efektler</button>
          <button class="dock-tab" data-dock="split"><i class="bi bi-scissors"></i> Ses Ayırıcı</button>
          <button class="dock-tab" data-dock="master"><i class="bi bi-stars"></i> Mastering</button>
          <div class="spacer"></div>
          <button class="dock-tab" id="dockToggle" title="Paneli daralt"><i class="bi bi-chevron-down"></i></button>
        </div>

        <div class="dock-body">
          <!-- MİKSER -->
          <div class="dock-pane active" id="pane-mixer">
            <div class="mixer-strip-wrap" id="mixerStrips"></div>
          </div>

          <!-- LOOP KÜTÜPHANESİ -->
          <div class="dock-pane" id="pane-loops">
            <div class="loop-toolbar">
              <button class="chip active" data-loopcat="all"><i class="bi bi-collection"></i> Tümü</button>
              <button class="chip" data-loopcat="Davul">🥁 Davul</button>
              <button class="chip" data-loopcat="Bas">🎸 Bas</button>
              <button class="chip" data-loopcat="Gitar">🎶 Gitar</button>
              <button class="chip" data-loopcat="Tuşlu">🎹 Tuşlu</button>
              <div class="sep-v"></div>
              <input class="form-control" id="loopSearch" placeholder="Loop ara..." style="max-width:190px;height:29px;font-size:.76rem">
              <span class="ms-auto" style="font-size:.66rem;color:var(--tx-3)">
                <i class="bi bi-info-circle"></i> Loop'a tıkla → dinle · <b>+</b> ile kanala ekle
              </span>
            </div>
            <div class="loops-grid" id="loopsGrid">
              <div class="loading-wrap"><div class="spinner-border spinner-border-sm text-danger"></div><span>Loop kütüphanesi yükleniyor...</span></div>
            </div>
          </div>

          <!-- ENSTRÜMANLAR -->
          <div class="dock-pane" id="pane-instruments">
            <div class="inst-wrap">

              <!-- Piyano -->
              <div class="panel-box" style="flex:1;min-width:300px">
                <h6><i class="bi bi-piano-keys"></i> Piyano / Klavye</h6>
                <div class="piano" id="pianoKeys"></div>
                <div style="display:flex;gap:.5rem;align-items:center;margin-top:.6rem;flex-wrap:wrap">
                  <div class="knob" style="min-width:120px">
                    <label>Oktav <span id="octaveLbl">C4</span></label>
                    <input type="range" id="octaveRange" min="1" max="6" step="1" value="3">
                  </div>
                  <div class="knob" style="min-width:120px">
                    <label>Dalga <span id="pianoWaveLbl">SİNÜS</span></label>
                    <select class="form-select form-select-sm" id="pianoWave" style="font-size:.72rem;height:28px">
                      <option value="sine" selected>Sinüs</option>
                      <option value="triangle">Üçgen</option>
                      <option value="square">Kare</option>
                      <option value="saw">Testere</option>
                    </select>
                  </div>
                  <button class="ibtn" id="pianoToTrack" title="Çaldığınız notaları seçili kanala bölge olarak yaz">
                    <i class="bi bi-plus-square"></i><span>Kanala Yaz</span>
                  </button>
                  <button class="ibtn danger" id="pianoClear" title="Yazılan notaları temizle"><i class="bi bi-trash3"></i></button>
                </div>
                <div style="font-size:.64rem;color:var(--tx-3);margin-top:.4rem">
                  <i class="bi bi-keyboard"></i> Bilgisayar klavyesi: <kbd>A</kbd><kbd>W</kbd><kbd>S</kbd><kbd>E</kbd><kbd>D</kbd><kbd>F</kbd><kbd>T</kbd><kbd>G</kbd><kbd>Y</kbd><kbd>H</kbd><kbd>U</kbd><kbd>J</kbd><kbd>K</kbd>
                </div>
              </div>

              <!-- Davul makinesi -->
              <div class="panel-box" style="flex:1;min-width:340px">
                <h6><i class="bi bi-grid-3x3-gap-fill"></i> Davul Makinesi (Step Sequencer)</h6>
                <div class="dm-seq" id="drumSeq"></div>
                <div style="display:flex;gap:.5rem;align-items:center;margin-top:.65rem;flex-wrap:wrap">
                  <div class="knob" style="min-width:130px">
                    <label>Desen <span id="dmPatternLbl">BOOM BAP</span></label>
                    <select class="form-select form-select-sm" id="dmPattern" style="font-size:.72rem;height:28px">
                      <option value="boom_bap" selected>Boom Bap</option>
                      <option value="trap">Trap</option>
                      <option value="four_floor">Four On The Floor</option>
                      <option value="rock">Rock</option>
                      <option value="perc">Percussion</option>
                      <option value="empty">Boş</option>
                    </select>
                  </div>
                  <button class="ibtn" id="dmClear"><i class="bi bi-eraser"></i><span>Temizle</span></button>
                  <button class="ibtn" id="dmRandom"><i class="bi bi-shuffle"></i><span>Rastgele</span></button>
                  <button class="ibtn" id="dmToTrack" title="Davul desenini seçili kanala bölge olarak yaz"><i class="bi bi-plus-square"></i><span>Kanala Yaz</span></button>
                </div>
              </div>

            </div>
          </div>

          <!-- EFEKTLER -->
          <div class="dock-pane" id="pane-fx">
            <div class="fx-grid" id="fxGrid"></div>
          </div>

          <!-- MASTERING -->
          <div class="dock-pane" id="pane-master">
            <div class="fx-grid">
              <div class="fx-card">
                <div class="fx-card-head">
                  <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-stars"></i></div>
                  <div class="fx-title">
                    <b>Mastering Zinciri</b>
                    <small>Yayına hazır son ses işleme</small>
                  </div>
                </div>
                <div class="knob-row">
                  <div class="knob">
                    <label>Hazır Ayar <span id="masterPresetLbl">YOK</span></label>
                    <select class="form-select form-select-sm" id="masterPreset" style="font-size:.75rem">
                      <option value="none" selected>Yok (Bypass)</option>
                      <option value="balanced">Dengeli</option>
                      <option value="loud">Yüksek Ses (Loud)</option>
                      <option value="warm">Sıcak Analog</option>
                      <option value="bright">Parlak / Net</option>
                      <option value="bass">Bas Ağırlıklı</option>
                      <option value="night">Gece Modu (DRC)</option>
                    </select>
                  </div>
                  <div class="knob">
                    <label>Master Ses <span id="masterGainLbl">85%</span></label>
                    <input type="range" id="masterGain" min="0" max="150" value="85">
                  </div>
                  <div class="knob">
                    <label>Stereo Genişlik <span id="masterWidthLbl">100%</span></label>
                    <input type="range" id="masterWidth" min="0" max="200" value="100">
                  </div>
                </div>
              </div>

              <div class="fx-card">
                <div class="fx-card-head">
                  <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-graph-up"></i></div>
                  <div class="fx-title">
                    <b>Master Analiz</b>
                    <small>Anlık seviye ve tepe değerler</small>
                  </div>
                </div>
                <div style="display:flex;gap:.6rem">
                  <div style="flex:1">
                    <div style="font-size:.62rem;color:var(--tx-3);font-weight:700;margin-bottom:3px">SOL</div>
                    <div class="ms-meter" style="height:10px"><i id="meterL" style="width:0%"></i></div>
                    <div style="font-size:.6rem;color:var(--tx-3);font-weight:700;margin:7px 0 3px">SAĞ</div>
                    <div class="ms-meter" style="height:10px"><i id="meterR" style="width:0%"></i></div>
                  </div>
                </div>
                <div style="display:flex;justify-content:space-between;margin-top:.55rem;font-size:.62rem;font-family:'JetBrains Mono',monospace;color:var(--tx-3)">
                  <span>Tepe: <b id="peakVal">-∞</b> dB</span>
                  <span>RMS: <b id="rmsVal">-∞</b> dB</span>
                </div>
              </div>

              <div class="fx-card">
                <div class="fx-card-head">
                  <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-info-circle"></i></div>
                  <div class="fx-title">
                    <b>Proje Bilgisi</b>
                    <small>Stüdyo özeti</small>
                  </div>
                </div>
                <div style="font-size:.72rem;display:flex;flex-direction:column;gap:.3rem;color:var(--tx-2)">
                  <div style="display:flex;justify-content:space-between"><span>Kanal sayısı</span><b id="infoTracks">0</b></div>
                  <div style="display:flex;justify-content:space-between"><span>Bölge sayısı</span><b id="infoRegions">0</b></div>
                  <div style="display:flex;justify-content:space-between"><span>Toplam süre</span><b id="infoDuration">00:00</b></div>
                  <div style="display:flex;justify-content:space-between"><span>Örnekleme</span><b>44.1 kHz</b></div>
                  <div style="display:flex;justify-content:space-between"><span>Kayıt durumu</span><b id="infoRecState">Hazır</b></div>
                </div>
                <div style="margin-top:.7rem;font-size:.62rem;color:var(--tx-3)">
                  <i class="bi bi-hdd-stack"></i> <?php echo htmlspecialchars($uploadLimitText, ENT_QUOTES, 'UTF-8'); ?>
                </div>
              </div>
            </div>
          </div>

          <!-- SES AYIRICI (VOKAL / ENSTRÜMAN) -->
          <div class="dock-pane" id="pane-split">
            <div class="fx-grid">
              <div class="fx-card">
                <div class="fx-card-head">
                  <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-mic-fill"></i></div>
                  <div class="fx-title">
                    <b>Vokal / Enstrüman Ayırıcı</b>
                    <small>Şarkıdaki sesi ve müziği ayrı kanallara böl</small>
                  </div>
                </div>
                <div class="knob-row">
                  <div class="knob">
                    <label>Kaynak Ses <span id="splitSrcLbl">SEÇİLMEDİ</span></label>
                    <select class="form-select form-select-sm" id="splitSource" style="font-size:.75rem">
                      <option value="">Seçili kanal / kayıt yok</option>
                    </select>
                  </div>
                  <div class="knob">
                    <label>Ayırma Kalitesi <span id="splitQualityLbl">DENGELİ</span></label>
                    <select class="form-select form-select-sm" id="splitQuality" style="font-size:.75rem">
                      <option value="fast">Hızlı (taslak)</option>
                      <option value="balanced" selected>Dengeli</option>
                      <option value="best">Yüksek kalite (yavaş)</option>
                    </select>
                  </div>
                </div>
                <div class="knob-row" style="margin-top:.6rem">
                  <div class="knob">
                    <label>Vokal Hassasiyeti <span id="splitVocalLbl">65%</span></label>
                    <input type="range" id="splitVocal" min="0" max="100" value="65">
                  </div>
                  <div class="knob">
                    <label>Müzik Temizliği <span id="splitInstLbl">70%</span></label>
                    <input type="range" id="splitInst" min="0" max="100" value="70">
                  </div>
                </div>
                <div class="d-flex flex-wrap gap-2" style="margin-top:.7rem">
                  <button class="ibtn primary" id="splitRunBtn"><i class="bi bi-scissors"></i><span>Ayır ve Kanallara Ekle</span></button>
                  <button class="ibtn" id="splitPreviewVocal"><i class="bi bi-play-fill"></i><span>Vokal Dinle</span></button>
                  <button class="ibtn" id="splitPreviewInst"><i class="bi bi-play-fill"></i><span>Müzik Dinle</span></button>
                  <button class="ibtn danger" id="splitStopBtn"><i class="bi bi-stop-fill"></i><span>Durdur</span></button>
                </div>
                <div style="margin-top:.75rem">
                  <div style="display:flex;justify-content:space-between;font-size:.66rem;color:var(--tx-3);font-weight:700;margin-bottom:.25rem">
                    <span id="splitStage">Hazır</span><span id="splitPct">0%</span>
                  </div>
                  <div class="ms-meter" style="height:9px"><i id="splitBar" style="width:0%"></i></div>
                </div>
                <div style="margin-top:.6rem;font-size:.64rem;color:var(--tx-3);line-height:1.55">
                  <i class="bi bi-info-circle"></i>
                  Ayırma işlemi <b>tarayıcınızda</b> yapılır: merkez (mid) ve yan (side) sinyalleri
                  ayrıştırılarak vokal ile müzik katmanları çıkarılır. Sonuçlar
                  <b>“Vokal”</b> ve <b>“Enstrümantal”</b> adlı iki yeni kanala yazılır.
                </div>
              </div>

              <div class="fx-card">
                <div class="fx-card-head">
                  <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-info-circle"></i></div>
                  <div class="fx-title">
                    <b>Nasıl Çalışır?</b>
                    <small>En iyi sonuç için ipuçları</small>
                  </div>
                </div>
                <ul style="font-size:.72rem;color:var(--tx-2);padding-left:1.1rem;line-height:1.8;margin:0">
                  <li>Şarkıyı <b>içe aktarın</b> (İçe butonu) veya stüdyoda <b>kaydedin</b>.</li>
                  <li>İçe aktarılan kanalı seçin; kaynak listede görünür.</li>
                  <li>Vokal hassasiyeti merkez sesi ne kadar ayıracağını belirler.</li>
                  <li>Müzik temizliği enstrümantal katmanda vokali bastırır.</li>
                  <li>Ayırma bittiğinde iki yeni kanal otomatik oluşturulur.</li>
                </ul>
                <div class="panel-box" style="background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.22);margin-top:.7rem">
                  <div style="font-size:.7rem;color:var(--tx-2)">
                    <i class="bi bi-lightbulb text-info"></i>
                    Bu yöntem <b>stereo kayıtlarda</b> en iyi sonucu verir. Tek kanallı (mono)
                    kayıtlarda vokal ayrımı daha zayıf olur.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Durum çubuğu -->
      <div class="statusbar">
        <span class="st"><i class="bi bi-circle-fill dot ok"></i> <span id="statEngine">Ses motoru hazır</span></span>
        <span class="st"><i class="bi bi-mic-fill"></i> <span id="statMic">Mikrofon: izin bekleniyor</span></span>
        <span class="st"><i class="bi bi-layers-fill"></i> <span id="statTracks">0 kanal</span></span>
        <span class="st"><i class="bi bi-clock-history"></i> <span id="statSaved">Kaydedilmedi</span></span>
        <span class="st ms-auto"><i class="bi bi-command"></i> Space: Çal · R: Kayıt · M: Metronom · L: Loop · Ctrl+S: Kaydet</span>
      </div>
    </div>
  </div>
</div>

<!-- Gizli dosya girişleri -->
<input type="file" id="importAudioInput" accept="audio/*" multiple hidden>

<!-- ============================================================
     PROJELER MODALI
     ============================================================ -->
<div class="modal fade" id="projectsModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-folder2-open text-danger me-2"></i>Projelerim</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>
      <div class="modal-body">
        <button class="btn btn-danger w-100 mb-3" id="newProjectBtn">
          <i class="bi bi-plus-lg"></i> Yeni Proje Oluştur
        </button>
        <div id="projectsList">
          <div class="loading-wrap"><div class="spinner-border spinner-border-sm text-danger"></div><span>Yükleniyor...</span></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ============================================================
     YARDIM / KISAYOLLAR MODALI
     ============================================================ -->
<div class="modal fade" id="helpModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-question-circle-fill text-danger me-2"></i>Ses Kayıt Stüdyosu — Kısayollar ve İpuçları</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>
      <div class="modal-body" style="font-size:.84rem;line-height:1.8">
        <div class="row g-4">
          <div class="col-md-6">
            <h6 class="fw-bold text-danger mb-3"><i class="bi bi-keyboard"></i> Klavye Kısayolları</h6>
            <div class="d-flex flex-column gap-2">
              <div class="d-flex justify-content-between"><span>Çal / Durdur</span><kbd>Space</kbd></div>
              <div class="d-flex justify-content-between"><span>Kayıt başlat/durdur</span><kbd>R</kbd></div>
              <div class="d-flex justify-content-between"><span>Metronom aç/kapa</span><kbd>M</kbd></div>
              <div class="d-flex justify-content-between"><span>Döngü aç/kapa</span><kbd>L</kbd></div>
              <div class="d-flex justify-content-between"><span>Başa dön</span><kbd>Home</kbd></div>
              <div class="d-flex justify-content-between"><span>Projeyi kaydet</span><kbd>Ctrl</kbd>+<kbd>S</kbd></div>
              <div class="d-flex justify-content-between"><span>Yeni kanal ekle</span><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>N</kbd></div>
              <div class="d-flex justify-content-between"><span>Kanala kayıt hazırla</span><kbd>Shift</kbd>+<kbd>R</kbd></div>
              <div class="d-flex justify-content-between"><span>Yakınlaştır / Uzaklaştır</span><kbd>Ctrl</kbd>+<kbd>+</kbd> / <kbd>−</kbd></div>
              <div class="d-flex justify-content-between"><span>Seçili bölgeyi sil</span><kbd>Delete</kbd></div>
            </div>
            <h6 class="fw-bold text-danger mb-2 mt-4"><i class="bi bi-music-note-list"></i> Piyano Klavyesi</h6>
            <p style="color:var(--tx-2);font-size:.78rem" class="mb-0">
              Bilgisayar klavyenizin <kbd>A</kbd> <kbd>W</kbd> <kbd>S</kbd> <kbd>E</kbd> <kbd>D</kbd> <kbd>F</kbd> <kbd>T</kbd> <kbd>G</kbd> <kbd>Y</kbd> <kbd>H</kbd> <kbd>U</kbd> <kbd>J</kbd> <kbd>K</kbd>
              tuşlarıyla piyano çalabilirsiniz. Beyaz ve siyah tuşlar sırayla eşlenir.
            </p>
          </div>
          <div class="col-md-6">
            <h6 class="fw-bold text-danger mb-3"><i class="bi bi-lightbulb"></i> Nasıl Kullanılır?</h6>
            <ol style="padding-left:1.1rem;color:var(--tx-2);font-size:.8rem" class="d-flex flex-column gap-2">
              <li><b class="text-white">Kanal ekleyin:</b> Sol taraftaki <i class="bi bi-plus-lg"></i> <b>Kanal</b> butonuna basın veya kanal türünü seçin.</li>
              <li><b class="text-white">Kayıt hazırlayın:</b> Kanal başlığındaki <span style="color:var(--rec)">R</span> butonuna basıp kırmızı yanmasını sağlayın, sonra üstteki <i class="bi bi-record-circle"></i> kayıt butonuna basın.</li>
              <li><b class="text-white">Loop ekleyin:</b> <b>Loop Kütüphanesi</b> sekmesinden beğendiğiniz loop'u dinleyin, <b>+</b> butonuyla projeye ekleyin.</li>
              <li><b class="text-white">Enstrüman çalın:</b> <b>Enstrümanlar</b> sekmesinde piyano veya davul makinesiyle desen oluşturun, <b>Kanala Yaz</b> ile kaydedin.</li>
              <li><b class="text-white">Efekt uygulayın:</b> <b>Efektler</b> sekmesinden AutoPitch, Reverb, Delay, EQ ve Kompresör ekleyin.</li>
              <li><b class="text-white">Mastering:</b> <b>Mastering</b> sekmesinden hazır ayar seçin ve ses seviyesini dengeleyin.</li>
              <li><b class="text-white">Dışa aktarın:</b> <b>Mixdown</b> butonuyla projeyi gerçek zamanlı karıştırıp WAV olarak indirin.</li>
            </ol>
            <div class="panel-box mt-3" style="background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.22)">
              <div style="font-size:.76rem;color:var(--tx-2)">
                <i class="bi bi-shield-check text-success"></i>
                <b>İpucu:</b> Mikrofon izni vermeden de stüdyoyu kullanabilirsiniz — loop kütüphanesi ve sanal enstrümanlar mikrofon gerektirmez.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ============================================================
     MASTERING / KANAL EFEKT MODALI
     ============================================================ -->
<div class="modal fade" id="fxModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-magic text-danger me-2"></i>Kanal Efekt Zinciri — <span id="fxModalTrackName" class="text-white">Kanal</span></h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>
      <div class="modal-body" id="fxModalBody"></div>
    </div>
  </div>
</div>

<!-- ============================================================
     DIŞA AKTARMA (MIXDOWN) MODALI
     ============================================================ -->
<div class="modal fade" id="exportModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-download text-danger me-2"></i>Mixdown — Dışa Aktarma</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>
      <div class="modal-body">
        <div class="panel-box mb-3" style="background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.22)">
          <div style="font-size:.77rem;color:var(--tx-2)">
            <i class="bi bi-info-circle text-info"></i>
            Mixdown, projenizi <b>gerçek zamanlı</b> olarak baştan sona çalar ve tüm kanalları tek bir WAV dosyasında birleştirir.
            <br>Proje süresi uzunsa işlem o kadar sürer.
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label" for="exportTitle">Şarkı Başlığı</label>
          <input type="text" class="form-control" id="exportTitle" maxlength="120" placeholder="Mixdown adı">
        </div>
        <div class="mb-3">
          <label class="form-label" for="exportDuration">Dışa Aktarılacak Süre (saniye)</label>
          <input type="number" class="form-control" id="exportDuration" min="1" max="600" value="30">
          <div style="font-size:.66rem;color:var(--tx-3);margin-top:.25rem">
            Maksimum 600 saniye (10 dakika).
          </div>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="exportAddLibrary" checked>
          <label class="form-check-label" for="exportAddLibrary" style="font-size:.8rem">
            Mixdown'ı müzik kütüphaneme de ekle
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
        <button class="btn btn-danger" id="doExportBtn"><i class="bi bi-play-fill"></i> Mixdown Başlat</button>
      </div>
    </div>
  </div>
</div>

<!-- Bildirim alanı -->
<div class="toast-host" id="toastHost"></div>
<div id="studioStateProbe" style="display:none"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
'use strict';
/* ============================================================
   KUDUKO SES KAYIT STÜDYOSU — İSTEMCİ MOTORU
   ============================================================ */

// ---------- Yardımcılar ----------
const $  = (id) => document.getElementById(id);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

function showToast(msg, type = 'info', ms = 3600) {
  const host = $('toastHost');
  const icons = { ok: 'bi-check-circle-fill', err: 'bi-exclamation-triangle-fill', info: 'bi-info-circle-fill' };
  const el = document.createElement('div');
  el.className = 'tst ' + (type === 'ok' ? 'ok' : type === 'err' ? 'err' : 'info');
  el.innerHTML = `<i class="bi ${icons[type] || icons.info}"></i><div>${msg}</div>`;
  host.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .25s, transform .25s';
    el.style.opacity = '0';
    el.style.transform = 'translateX(30px)';
    setTimeout(() => el.remove(), 260);
  }, ms);
}

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function fmtClock(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  const t = Math.floor((sec % 1) * 10);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${t}`;
}
function fmtDur(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

// Sayısal girişlere tersine çevrilebilir doğrulama
function clampInt(el, min, max, fallback) {
  let v = parseInt(el.value, 10);
  if (isNaN(v)) v = fallback;
  v = clamp(v, min, max);
  el.value = v;
  return v;
}

/* ============================================================
   GLOBAL DURUM
   ============================================================ */
const TRACK_COLORS = ['#ffffff','#e6e6e6','#cccccc','#b3b3b3','#999999','#808080','#e0e0e0','#d0d0d0','#bfbfbf','#adadad','#9e9e9e','#8f8f8f'];

const TRACK_TYPES = [
  { id: 'vocal',      label: 'Vokal / Mikrofon', icon: 'bi-mic-fill',        color: '#ffffff', instrument: 'vocal' },
  { id: 'instrument', label: 'Enstrüman',        icon: 'bi-music-note-beamed', color: '#ffffff', instrument: 'piano' },
  { id: 'drums',      label: 'Davul',            icon: 'bi-grid-3x3-gap-fill', color: '#ffffff', instrument: 'drums' },
  { id: 'guitar',     label: 'Gitar',            icon: 'bi-guitar',           color: '#ffffff', instrument: 'guitar' },
  { id: 'bass',       label: 'Bas',              icon: 'bi-soundwave',        color: '#ffffff', instrument: 'bass' },
  { id: 'keys',       label: 'Tuşlu / Synth',    icon: 'bi-piano-keys',       color: '#ffffff', instrument: 'synth' },
  { id: 'audio',      label: 'Ses Dosyası',      icon: 'bi-file-earmark-music', color: '#ffffff', instrument: 'audio' }
];

const state = {
  projectId: null,
  title: 'Yeni Proje',
  bpm: 120,
  timeSig: '4/4',
  key: 'C',
  snap: 0.25,
  tracks: [],
  selectedTrackId: null,
  selectedRegionId: null,

  isPlaying: false,
  isRecording: false,
  startCtxTime: 0,      // audio ctx zamanı (çalma başladığında)
  startBeat: 0,         // çalma başladığı andaki vuruş
  playheadBeat: 0,
  soloActive: false,

  loopEnabled: false,
  loopStart: 0,
  loopEnd: 0,

  metronome: false,
  pxPerBeat: 48,
  masterGain: 0.85,
  masterPreset: 'none',
  masterWidth: 1.0,

  user: null,
  loops: [],
  activeLoopCat: 'all',
  playingLoopId: null,

  pitch: [],            // piyano ile yazılan notalar: {beat, note, dur}
  drumPattern: [],      // davul deseni: rows[step]=0/1
  recordingStartBeat: 0,
  saved: true,
};

let uidSeq = 1;
const newId = (p) => p + '_' + (uidSeq++) + '_' + Date.now().toString(36);

/* ============================================================
   SES MOTORU
   ============================================================ */
const AE = {
  ctx: null,
  master: null,
  masterGain: null,
  splitter: null,
  merger: null,
  analyserL: null,
  analyserR: null,
  limiter: null,
  ready: false,

  async init() {
    if (this.ready) { await this.resume(); return true; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { showToast('Tarayıcınız Web Audio desteklemiyor.', 'err'); return false; }

    this.ctx = new AC({ latencyHint: 'interactive' });

    // Analiz için stereo kanallara ayır
    this.splitter = this.ctx.createChannelSplitter(2);
    this.merger = this.ctx.createChannelMerger(2);

    this.analyserL = this.ctx.createAnalyser();
    this.analyserR = this.ctx.createAnalyser();
    this.analyserL.fftSize = 1024;
    this.analyserR.fftSize = 1024;
    this.analyserL.smoothingTimeConstant = 0.75;
    this.analyserR.smoothingTimeConstant = 0.75;

    // Master limiter (mastering çıkışı)
    this.limiter = this.ctx.createDynamicsCompressor();
    this.limiter.threshold.value = -1.5;
    this.limiter.knee.value = 0;
    this.limiter.ratio.value = 20;
    this.limiter.attack.value = 0.002;
    this.limiter.release.value = 0.12;

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = state.masterGain;

    // Zincir: masterGain -> splitter -> (analyserL/R) -> merger -> limiter -> out
    this.masterGain.connect(this.splitter);
    this.splitter.connect(this.analyserL, 0);
    this.splitter.connect(this.analyserR, 1);
    this.splitter.connect(this.merger, 0, 0);
    this.splitter.connect(this.merger, 1, 1);
    this.merger.connect(this.limiter);
    this.limiter.connect(this.ctx.destination);

    this.master = this.masterGain;
    this.ready = true;
    await this.resume();
    updateStatus('statEngine', 'Ses motoru hazır');
    return true;
  },

  async resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      try { await this.ctx.resume(); } catch (e) { /* kullanıcı etkileşimi bekleniyor */ }
    }
  }
};

/* ============================================================
   KANAL (TRACK) OLUŞTURMA
   ============================================================ */
function makeTrack(opts = {}) {
  const type = TRACK_TYPES.find(t => t.id === (opts.type || 'vocal')) || TRACK_TYPES[0];
  const idx = state.tracks.length;
  return {
    id: newId('trk'),
    name: opts.name || `${type.label} ${idx + 1}`,
    type: type.id,
    typeLabel: type.label,
    icon: type.icon,
    instrument: opts.instrument || type.instrument,
    color: opts.color || TRACK_COLORS[idx % TRACK_COLORS.length],

    volume: 0.85,
    pan: 0,
    muted: false,
    soloed: false,
    armed: false,
    regions: [],

    fx: {
      autopitch:  { on: false, amount: 65, speed: 45, key: 'auto' },
      reverb:     { on: false, mix: 22, size: 45 },
      delay:      { on: false, mix: 20, time: 0.32, feedback: 30 },
      eq:         { on: false, low: 0, mid: 0, high: 0 },
      compressor: { on: false, threshold: -20, ratio: 4 }
    }
  };
}

function addTrack(opts = {}, silent = false) {
  if (state.tracks.length >= 32) { showToast('En fazla 32 kanal ekleyebilirsiniz.', 'err'); return null; }
  const tr = makeTrack(opts);
  state.tracks.push(tr);
  if (state.selectedTrackId === null) state.selectedTrackId = tr.id;
  if (!silent) {
    renderTracks();
    renderMixer();
    updateInfoBar();
    markUnsaved();
    showToast(`<b>${esc(tr.name)}</b> kanalı eklendi.`, 'ok', 2200);
  }
  return tr;
}

function getTrack(id) { return state.tracks.find(t => t.id === id) || null; }
function selectedTrack() { return getTrack(state.selectedTrackId); }

function removeTrack(id) {
  const i = state.tracks.findIndex(t => t.id === id);
  if (i < 0) return;
  const tr = state.tracks[i];
  // Bölgelerin blob URL'lerini serbest bırak
  tr.regions.forEach(r => { if (r.blobUrl) URL.revokeObjectURL(r.blobUrl); });
  state.tracks.splice(i, 1);
  if (state.selectedTrackId === id) state.selectedTrackId = state.tracks[0] ? state.tracks[0].id : null;
  renderTracks(); renderMixer(); updateInfoBar(); markUnsaved();
  showToast(`<b>${esc(tr.name)}</b> kanalı silindi.`, 'info', 2200);
}

/* Bölge (region) */
function addRegion(trackId, opts) {
  const tr = getTrack(trackId);
  if (!tr) return null;
  const region = {
    id: newId('rgn'),
    name: opts.name || 'Kayıt',
    startBeat: Math.max(0, opts.startBeat || 0),
    lengthBeats: Math.max(0.25, opts.lengthBeats || 4),
    color: opts.color || tr.color,
    blobUrl: opts.blobUrl || null,
    buffer: opts.buffer || null,
    sourceKind: opts.sourceKind || 'audio',   // audio | drums | synth
    gain: opts.gain == null ? 1 : opts.gain,
    notes: opts.notes || null,
  };
  tr.regions.push(region);
  return region;
}

/* ============================================================
   ZAMAN / VURUŞ DÖNÜŞÜMLERİ
   ============================================================ */
function trackHeadW() {
  const v = getComputedStyle(document.documentElement).getPropertyValue('--track-head-w').trim();
  return parseInt(v, 10) || 280;
}
function beatToPx(beat) { return beat * state.pxPerBeat; }
function pxToBeat(px) { return px / state.pxPerBeat; }
function secToBeat(sec) { return sec * (state.bpm / 60); }
function beatToSec(beat) { return beat * (60 / state.bpm); }
function beatsPerBar() {
  const p = state.timeSig.split('/');
  const num = parseInt(p[0], 10) || 4;
  const den = parseInt(p[1], 10) || 4;
  return num * (4 / den);
}
function projectBeats() {
  // Projenin görünen uzunluğu: en az 32 bar, en uzun bölgeye göre uzar
  let maxBeat = beatsPerBar() * 32;
  state.tracks.forEach(t => t.regions.forEach(r => {
    maxBeat = Math.max(maxBeat, r.startBeat + r.lengthBeats);
  }));
  return Math.ceil(maxBeat / beatsPerBar()) * beatsPerBar();
}

function currentBeat() {
  if (!state.isPlaying || !AE.ctx) return state.playheadBeat;
  const elapsed = AE.ctx.currentTime - state.startCtxTime;
  return state.startBeat + secToBeat(elapsed);
}

/* ============================================================
   ÇİZİM: CETVEL + KANALLAR
   ============================================================ */
function renderRuler() {
  const ruler = $('ruler');
  if (!ruler) return;
  // Mevcut tick'leri temizle (loop region'ı koru)
  $$('.ruler-tick, .ruler-label', ruler).forEach(el => el.remove());

  const totalBeats = projectBeats();
  const bpb = beatsPerBar();
  const totalBars = Math.ceil(totalBeats / bpb);
  const w = beatToPx(totalBeats);
  ruler.style.width = w + 'px';

  // Bar başına major tick; 1/4'lük nota aralığında minor tick
  const minorEvery = state.pxPerBeat >= 60 ? 0.25 : state.pxPerBeat >= 26 ? 0.5 : 1;
  const frag = document.createDocumentFragment();

  for (let b = 0; b <= totalBeats + 0.0001; b += minorEvery) {
    const beat = Math.round(b * 1000) / 1000;
    if (minorEvery > 1 && Math.abs(beat - Math.round(beat)) > 0.001) continue;
    const isBar = Math.abs(beat % bpb) < 0.001;
    const isBeat = Math.abs(beat - Math.round(beat)) < 0.001;
    if (!isBar && !isBeat && minorEvery >= 0.5) continue;

    const tick = document.createElement('div');
    tick.className = 'ruler-tick' + (isBar ? ' major' : '');
    tick.style.left = beatToPx(beat) + 'px';
    frag.appendChild(tick);

    if (isBar) {
      const lbl = document.createElement('div');
      lbl.className = 'ruler-label';
      lbl.style.left = beatToPx(beat) + 'px';
      lbl.textContent = (Math.round(beat / bpb) + 1);
      frag.appendChild(lbl);
    }
  }
  ruler.insertBefore(frag, ruler.firstChild);

  // Loop bölgesini güncelle
  const lr = $('loopRegion');
  if (lr) {
    if (state.loopEnabled && state.loopEnd > state.loopStart) {
      lr.style.display = 'block';
      lr.style.left = beatToPx(state.loopStart) + 'px';
      lr.style.width = beatToPx(state.loopEnd - state.loopStart) + 'px';
    } else {
      lr.style.display = 'none';
    }
  }
}

function drawRegionWave(canvas, region, track) {
  const dpr = window.devicePixelRatio || 1;
  const cw = Math.max(1, Math.floor(canvas.clientWidth || region.lengthBeats * state.pxPerBeat));
  const ch = Math.max(1, Math.floor(canvas.clientHeight || 44));
  canvas.width = cw * dpr;
  canvas.height = ch * dpr;
  const g = canvas.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, cw, ch);

  const mid = ch / 2;
  g.fillStyle = 'rgba(255,255,255,.30)';

  const buf = region.buffer;
  if (buf && buf.length) {
    const data = buf.getChannelData(0);
    const step = Math.max(1, Math.floor(data.length / cw));
    for (let x = 0; x < cw; x++) {
      let peak = 0;
      const s = x * step;
      const e = Math.min(data.length, s + step);
      // Performans için alt örnekleme
      const inc = Math.max(1, Math.floor((e - s) / 120));
      for (let i = s; i < e; i += inc) {
        const v = data[i] < 0 ? -data[i] : data[i];
        if (v > peak) peak = v;
      }
      const h = Math.max(1, peak * (mid - 2));
      g.fillRect(x, mid - h, 1, h * 2);
    }
    return;
  }

  // Buffer yoksa: türüne göre temsili desen çiz
  if (region.sourceKind === 'drums' || (track && track.type === 'drums')) {
    g.fillStyle = 'rgba(255,255,255,.78)';
    const n = Math.max(4, Math.floor(region.lengthBeats * 4));
    for (let i = 0; i < n; i++) {
      const x = (i / n) * cw;
      const isAccent = i % 4 === 0;
      const h = isAccent ? mid * 0.85 : mid * 0.45;
      g.fillRect(x, mid - h / 2, Math.max(1, cw / n * 0.45), h);
    }
    return;
  }

  // Melodik içerik
  g.beginPath();
  const pts = Math.max(6, Math.floor(region.lengthBeats * 3));
  for (let i = 0; i <= pts; i++) {
    const x = (i / pts) * cw;
    const t = i / pts;
    const y = mid - Math.sin(t * Math.PI * 5) * mid * 0.42 * (1 - t * 0.45);
    if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
  }
  g.strokeStyle = 'rgba(255,255,255,.75)';
  g.lineWidth = 1.4;
  g.stroke();
}

function renderTracks() {
  const area = $('tracksArea');
  if (!area) return;

  // Playhead'i koru, gerisini sil
  const ph = $('playhead');
  $$('.track-row, .grid-line', area).forEach(el => el.remove());

  const totalBeats = projectBeats();
  const totalW = beatToPx(totalBeats);
  const headW = trackHeadW();
  const bpb = beatsPerBar();

  if (state.tracks.length === 0) {
    const emp = document.createElement('div');
    emp.className = 'd-flex flex-column align-items-center justify-content-center';
    emp.style.cssText = `padding:3rem 1rem;color:var(--tx-3);text-align:center;height:100%`;
    emp.innerHTML = `
      <i class="bi bi-music-note-beamed" style="font-size:2.6rem;opacity:.5"></i>
      <div style="font-weight:700;margin-top:.6rem;color:var(--tx-2)">Henüz kanal yok</div>
      <div style="font-size:.78rem;margin-top:.25rem">Başlamak için bir kanal ekleyin ya da hazır şablon seçin.</div>
      <div class="d-flex gap-2 flex-wrap justify-content-center" style="margin-top:1rem">
        <button class="ibtn primary" id="emptyAddVocal"><i class="bi bi-mic-fill"></i><span>Vokal Kanalı</span></button>
        <button class="ibtn" id="emptyAddInstrument"><i class="bi bi-music-note-beamed"></i><span>Enstrüman</span></button>
        <button class="ibtn" id="emptyAddDrums"><i class="bi bi-grid-3x3-gap-fill"></i><span>Davul</span></button>
        <button class="ibtn" id="emptyDemo"><i class="bi bi-stars"></i><span>Demo Proje</span></button>
      </div>`;
    area.appendChild(emp);
    // Boş durum butonları
    const bv = $('emptyAddVocal');
    if (bv) bv.onclick = () => addTrack({ type: 'vocal' });
    const bi2 = $('emptyAddInstrument');
    if (bi2) bi2.onclick = () => addTrack({ type: 'instrument' });
    const bd = $('emptyAddDrums');
    if (bd) bd.onclick = () => addTrack({ type: 'drums' });
    const bdem = $('emptyDemo');
    if (bdem) bdem.onclick = () => buildDemoProject();
    $('trackCountLabel').textContent = '0 KANAL';
    return;
  }

  $('trackCountLabel').textContent = state.tracks.length + ' KANAL';
  const frag = document.createDocumentFragment();

  state.tracks.forEach((tr, ti) => {
    const row = document.createElement('div');
    row.className = 'track-row' + (tr.id === state.selectedTrackId ? ' selected' : '');
    row.dataset.trackId = tr.id;

    // ---- Kanal başlığı ----
    const head = document.createElement('div');
    head.className = 'track-head';
    head.innerHTML = `
      <div class="th-top">
        <div class="th-color" style="background:${tr.color}"></div>
        <div class="th-meta">
          <input class="track-name-input" value="${esc(tr.name)}" maxlength="48" title="Kanal adı" data-rename>
        </div>
        <div class="th-btns">
          <button class="mini-btn m${tr.muted ? ' on' : ''}" title="Sessize al (Mute)" data-flag="muted">M</button>
          <button class="mini-btn s${tr.soloed ? ' on' : ''}" title="Solo" data-flag="soloed">S</button>
          <button class="mini-btn r${tr.armed ? ' armed' : ''}" title="Kayda hazırla" data-flag="armed"><i class="bi bi-circle-fill" style="font-size:.5rem"></i></button>
          <button class="mini-btn" title="Efektler" data-openfx><i class="bi bi-magic" style="font-size:.62rem"></i></button>
          <button class="mini-btn" title="Kanalı sil" data-del><i class="bi bi-trash3" style="font-size:.62rem"></i></button>
        </div>
      </div>
      <div class="th-sliders">
        <div class="th-slider">
          <label>SES <span>${Math.round(tr.volume * 100)}%</span></label>
          <input type="range" min="0" max="100" value="${Math.round(tr.volume * 100)}" data-vol>
        </div>
        <div class="th-slider">
          <label>PAN <span>${tr.pan === 0 ? 'C' : (tr.pan > 0 ? 'R' + Math.round(tr.pan * 100) : 'L' + Math.round(-tr.pan * 100))}</span></label>
          <input type="range" min="-100" max="100" value="${Math.round(tr.pan * 100)}" data-pan>
        </div>
      </div>`;
    row.appendChild(head);

    // ---- Kanal yolu ----
    const lane = document.createElement('div');
    lane.className = 'track-lane';
    lane.style.width = totalW + 'px';
    lane.dataset.trackId = tr.id;

    // Izgara çizgileri
    const gridFrag = document.createDocumentFragment();
    const gridEvery = state.pxPerBeat >= 46 ? 1 : bpb;
    for (let b = 0; b <= totalBeats + 0.001; b += gridEvery) {
      const isBar = Math.abs(b % bpb) < 0.001;
      const gl = document.createElement('div');
      gl.className = 'grid-line' + (isBar ? ' bar' : '');
      gl.style.left = beatToPx(b) + 'px';
      gridFrag.appendChild(gl);
    }
    lane.appendChild(gridFrag);

    // Bölgeler
    if (tr.regions.length === 0) {
      const hint = document.createElement('div');
      hint.className = 'lane-hint';
      hint.innerHTML = `<i class="bi bi-plus-circle"></i> Çift tıkla: kayıt · Loop sekmesinden sürükle-bırak yap`;
      lane.appendChild(hint);
    }

    tr.regions.forEach(rg => {
      const el = document.createElement('div');
      el.className = 'region';
      el.style.left = beatToPx(rg.startBeat) + 'px';
      el.style.width = Math.max(10, beatToPx(rg.lengthBeats)) + 'px';
      el.style.background = `linear-gradient(180deg, ${rg.color}44, ${rg.color}1f)`;
      el.style.borderColor = rg.color + 'cc';
      el.dataset.regionId = rg.id;
      el.dataset.trackId = tr.id;
      el.innerHTML = `
        <div class="region-head" style="color:#fff">
          <i class="bi ${tr.icon}" style="font-size:.62rem;opacity:.85"></i>
          <span class="rname">${esc(rg.name)}</span>
          <i class="bi bi-x-lg rtool" data-regdel title="Bölgeyi sil"></i>
        </div>
        <canvas></canvas>
        <div class="region-resize rl" data-regresize="left" title="Sola doğru boyutlandır"></div>
        <div class="region-resize rr" data-regresize="right" title="Sağa doğru boyutlandır"></div>`;
      lane.appendChild(el);
      const cv = el.querySelector('canvas');
      requestAnimationFrame(() => drawRegionWave(cv, rg, tr));
    });

    row.appendChild(lane);
    frag.appendChild(row);
  });

  area.appendChild(frag);
  positionPlayhead();
  updateInfoBar();
  refreshSplitSources();
}

function positionPlayhead() {
  const ph = $('playhead');
  if (!ph) return;
  const beat = state.isPlaying ? currentBeat() : state.playheadBeat;
  ph.style.left = (trackHeadW() + beatToPx(beat)) + 'px';
}

/* ============================================================
   TAŞIMA (RENDER) DÖNGÜSÜ
   ============================================================ */
let rafId = null;
let lastAnimTime = 0;
let lastRulerBeat = -1;

function animLoop(ts) {
  if (!state.isPlaying) { rafId = null; return; }

  const beat = currentBeat();
  state.playheadBeat = beat;
  positionPlayhead();

  // Zaman göstergesi
  const bpb = beatsPerBar();
  const bar = Math.floor(beat / bpb) + 1;
  const beatInBar = Math.floor(beat % bpb) + 1;
  const sixteenth = Math.floor((beat % 1) * 4) + 1;
  const td = $('timeDisplay');
  td.innerHTML = `${bar}.${beatInBar}.${sixteenth}<span style="opacity:.45"> · </span>${fmtClock(beatToSec(beat))}`;

  // Döngü sonu
  if (state.loopEnabled && state.loopEnd > state.loopStart && beat >= state.loopEnd) {
    seekToBeat(state.loopStart, true);
  }

  // Analiz çubukları
  updateMeters();

  rafId = requestAnimationFrame(animLoop);
}

const analyserBufL = new Float32Array(512);
const analyserBufR = new Float32Array(512);
let meterPeak = 0, meterRms = 0, meterDecay = 0;

function updateMeters() {
  if (!AE.ready) return;
  try {
    AE.analyserL.getFloatTimeDomainData(analyserBufL);
    AE.analyserR.getFloatTimeDomainData(analyserBufR);
    let peak = 0, sum = 0;
    for (let i = 0; i < analyserBufL.length; i++) {
      const l = analyserBufL[i], r = analyserBufR[i];
      const m = Math.max(Math.abs(l), Math.abs(r));
      if (m > peak) peak = m;
      sum += (l * l + r * r) / 2;
    }
    const rms = Math.sqrt(sum / analyserBufL.length);
    meterPeak = Math.max(peak, meterPeak * 0.88);
    meterRms = rms;

    const toPct = (v) => clamp(v * 135, 0, 100);
    const ml = $('meterL'), mr = $('meterR');
    if (ml) ml.style.width = toPct(meterPeak) + '%';
    if (mr) mr.style.width = toPct(Math.min(1, meterPeak * 0.97)) + '%';

    const db = (v) => v <= 0.00001 ? '-∞' : (20 * Math.log10(v)).toFixed(1);
    const pv = $('peakVal'), rv = $('rmsVal');
    if (pv) pv.textContent = db(meterPeak);
    if (rv) rv.textContent = db(meterRms);
  } catch (e) { /* analiz hatası yoksay */ }
}

function updateStatus(id, text) {
  const el = $(id);
  if (el) el.textContent = text;
}

function updateInfoBar() {
  const regions = state.tracks.reduce((n, t) => n + t.regions.length, 0);
  const maxBeat = state.tracks.reduce((m, t) =>
    t.regions.reduce((mm, r) => Math.max(mm, r.startBeat + r.lengthBeats), m), 0);
  const it = $('infoTracks'), ir = $('infoRegions'), idur = $('infoDuration'), ist = $('infoRecState');
  if (it) it.textContent = state.tracks.length;
  if (ir) ir.textContent = regions;
  if (idur) idur.textContent = fmtDur(beatToSec(maxBeat));
  if (ist) ist.textContent = state.isRecording ? 'Kaydediliyor' : 'Hazır';
  updateStatus('statTracks', state.tracks.length + ' kanal');
}

function markUnsaved() {
  state.saved = false;
  updateStatus('statSaved', 'Kaydedilmedi');
}
function markSaved() {
  state.saved = true;
  updateStatus('statSaved', 'Kaydedildi ' + new Date().toLocaleTimeString('tr-TR'));
}

/* ============================================================
   MİKSER
   ============================================================ */
function renderMixer() {
  const wrap = $('mixerStrips');
  if (!wrap) return;
  wrap.innerHTML = '';

  if (state.tracks.length === 0) {
    wrap.innerHTML = `<div style="color:var(--tx-3);font-size:.78rem;padding:1rem">Mikser için önce kanal ekleyin.</div>`;
    return;
  }

  state.tracks.forEach((tr, i) => {
    const s = document.createElement('div');
    s.className = 'mixer-strip';
    s.innerHTML = `
      <div class="ms-name" style="color:${tr.color}" title="${esc(tr.name)}">${esc(tr.name)}</div>
      <input type="range" class="ms-fader" min="0" max="100" value="${Math.round(tr.volume * 100)}"
             orient="vertical" data-mx-vol="${tr.id}" title="Ses seviyesi">
      <div class="ms-db">${Math.round(tr.volume * 100)}%</div>
      <div class="ms-meter"><i data-mx-meter="${tr.id}"></i></div>
      <div class="ms-row">
        <button class="mini-btn m${tr.muted ? ' on' : ''}" data-mx-flag="muted" data-tid="${tr.id}" title="Mute">M</button>
        <button class="mini-btn s${tr.soloed ? ' on' : ''}" data-mx-flag="soloed" data-tid="${tr.id}" title="Solo">S</button>
      </div>
      <input type="range" min="-100" max="100" value="${Math.round(tr.pan * 100)}" data-mx-pan="${tr.id}" title="Pan" style="width:100%">
    `;
    wrap.appendChild(s);
  });

  // Master şeridi
  const ms = document.createElement('div');
  ms.className = 'mixer-strip master';
  ms.innerHTML = `
    <div class="ms-name" style="color:#ffffff">MASTER</div>
    <input type="range" class="ms-fader" min="0" max="150" value="${Math.round(state.masterGain * 100)}"
           orient="vertical" id="mxMasterFader" title="Master ses seviyesi">
    <div class="ms-db">${Math.round(state.masterGain * 100)}%</div>
    <div class="ms-meter"><i id="mxMasterMeter"></i></div>
    <div class="ms-row">
      <button class="mini-btn" id="mxMasterMute" title="Master sessiz"><i class="bi bi-volume-mute-fill" style="font-size:.6rem"></i></button>
    </div>
    <div style="font-size:.55rem;color:var(--tx-3);text-align:center">${state.bpm} BPM</div>
  `;
  wrap.appendChild(ms);
}

/* ============================================================
   KANAL BAŞINA SES ZİNCİRİ (FX)
   ============================================================ */
const trackNodes = {};  // trackId -> { input, gain, panner, dry, wet... }

function buildTrackChain(tr) {
  if (trackNodes[tr.id]) return trackNodes[tr.id];
  const ctx = AE.ctx;

  const input = ctx.createGain();
  const eqLow = ctx.createBiquadFilter();
  eqLow.type = 'lowshelf'; eqLow.frequency.value = 220;
  const eqMid = ctx.createBiquadFilter();
  eqMid.type = 'peaking'; eqMid.frequency.value = 1600; eqMid.Q.value = 0.9;
  const eqHigh = ctx.createBiquadFilter();
  eqHigh.type = 'highshelf'; eqHigh.frequency.value = 5200;

  const comp = ctx.createDynamicsCompressor();
  comp.threshold.value = -20; comp.ratio.value = 4;
  comp.knee.value = 12; comp.attack.value = 0.004; comp.release.value = 0.22;

  const dry = ctx.createGain();
  const wetDelay = ctx.createGain();
  const delay = ctx.createDelay(2.0);
  const delayFb = ctx.createGain();
  const wetRev = ctx.createGain();
  const conv = ctx.createConvolver();
  conv.buffer = makeImpulse(2.0, 2.6);

  const panner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
  const gain = ctx.createGain();

  // Ana hat: input -> eq -> comp -> dry -> gain
  input.connect(eqLow); eqLow.connect(eqMid); eqMid.connect(eqHigh);
  eqHigh.connect(comp);
  comp.connect(dry); dry.connect(gain);

  // Delay kolu
  comp.connect(delay);
  delay.connect(delayFb); delayFb.connect(delay);
  delay.connect(wetDelay); wetDelay.connect(gain);

  // Reverb kolu
  comp.connect(conv); conv.connect(wetRev); wetRev.connect(gain);

  if (panner) { gain.connect(panner); panner.connect(AE.master); }
  else { gain.connect(AE.master); }

  trackNodes[tr.id] = {
    input, eqLow, eqMid, eqHigh, comp, dry, delay, delayFb, wetDelay, conv, wetRev, panner, gain
  };
  applyTrackFx(tr);
  applyTrackLevels(tr);
  return trackNodes[tr.id];
}

function makeImpulse(seconds, decay) {
  const ctx = AE.ctx;
  const rate = ctx.sampleRate;
  const len = Math.max(1, Math.floor(rate * seconds));
  const buf = ctx.createBuffer(2, len, rate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    for (let i = 0; i < len; i++) {
      d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
    }
  }
  return buf;
}

function applyTrackFx(tr) {
  const n = trackNodes[tr.id];
  if (!n) return;
  const fx = tr.fx;

  // EQ
  const eqOn = fx.eq.on ? 1 : 0;
  n.eqLow.gain.value = fx.eq.low * eqOn;
  n.eqMid.gain.value = fx.eq.mid * eqOn;
  n.eqHigh.gain.value = fx.eq.high * eqOn;

  // Kompresör
  if (fx.compressor.on) {
    n.comp.threshold.value = fx.compressor.threshold;
    n.comp.ratio.value = fx.compressor.ratio;
  } else {
    n.comp.threshold.value = 0;
    n.comp.ratio.value = 1;
  }

  // Delay
  n.wetDelay.gain.value = fx.delay.on ? (fx.delay.mix / 100) : 0;
  n.delay.delayTime.value = clamp(fx.delay.time, 0.02, 1.8);
  n.delayFb.gain.value = fx.delay.on ? clamp(fx.delay.feedback / 100, 0, 0.85) : 0;

  // Reverb
  n.wetRev.gain.value = fx.reverb.on ? (fx.reverb.mix / 100) * 0.9 : 0;
  n.conv.buffer = makeImpulse(
    clamp(0.4 + (fx.reverb.size / 100) * 3.6, 0.4, 4.0),
    clamp(1.0 + (fx.reverb.size / 100) * 3.0, 1.0, 4.0)
  );
}

function applyTrackLevels(tr) {
  const n = trackNodes[tr.id];
  if (!n) return;
  const anySolo = state.tracks.some(t => t.soloed);
  const audible = !tr.muted && (!anySolo || tr.soloed);
  n.gain.gain.value = audible ? tr.volume : 0;
  if (n.panner) n.panner.pan.value = clamp(tr.pan, -1, 1);
}

function refreshAllLevels() {
  state.tracks.forEach(applyTrackLevels);
}

/* ============================================================
   ÇALMA MOTORU — BÖLGE ZAMANLAMASI
   ============================================================ */
let activeSources = [];

function scheduleAll(fromBeat) {
  if (!AE.ready) return;
  const ctx = AE.ctx;
  const now = ctx.currentTime;
  activeSources.forEach(s => { try { s.stop(); } catch (e) {} });
  activeSources = [];

  state.tracks.forEach(tr => {
    const n = buildTrackChain(tr);
    tr.regions.forEach(rg => {
      if (rg.startBeat + rg.lengthBeats <= fromBeat) return;

      const when = now + Math.max(0, beatToSec(rg.startBeat - fromBeat));

      // Davul deseni bölgesi (buffer'dan bağımsız sentezlenir)
      if (rg.drumNotes && rg.drumNotes.length) {
        rg.drumNotes.forEach(dn => {
          const absBeat = rg.startBeat + dn.beat;
          if (absBeat < fromBeat) return;
          playDrumNow(tr, dn.drum, now + beatToSec(absBeat - fromBeat), rg.gain || 1);
        });
        return;
      }

      if (rg.buffer) {
        const src = ctx.createBufferSource();
        src.buffer = rg.buffer;
        const g = ctx.createGain();
        g.gain.value = rg.gain;

        // Kayıt bölgesi bir offset'ten başlıyorsa oradan çal
        let offset = 0;
        if (rg.startBeat < fromBeat) {
          offset = beatToSec(fromBeat - rg.startBeat);
          if (offset >= rg.buffer.duration) return;
        }

        // AutoPitch: kaydedilmiş ses (örn. vokal) çalınırken perde
        // düzeltme/vibrato uygula. Sinyali bozmadan hafif bir perde
        // modülasyonu ile "düzeltilmiş" hissi verir.
        let pitchLfo = null;
        if (tr.fx.autopitch.on) {
          pitchLfo = applyAutopitchDetune(ctx, src, tr, when, rg.buffer.duration - offset, rg);
        }

        src.connect(g); g.connect(n.input);
        try {
          src.start(when, offset);
        } catch (e) { return; }
        activeSources.push(src);
        if (pitchLfo) activeSources.push(pitchLfo);
      } else if (rg.notes && rg.notes.length) {
        // Nota tabanlı bölge: sentezleyici ile çal
        rg.notes.forEach(note => {
          const absBeat = rg.startBeat + note.beat;
          if (absBeat < fromBeat) return;
          const t0 = now + beatToSec(absBeat - fromBeat);
          const dur = beatToSec(note.dur || 0.5);
          playNoteNow(tr, note.note, t0, dur, (rg.gain == null ? 1 : rg.gain) * 0.9);
        });
      }
    });
  });
}

/* Tek nota sentezle ve kanal zincirine gönder. */
function playNoteNow(tr, midi, when, durSec, amp) {
  if (!AE.ready) return;
  const ctx = AE.ctx;
  const n = buildTrackChain(tr);

  const osc = ctx.createOscillator();
  const g = ctx.createGain();

  const wave = (tr.instrument === 'bass') ? 'sine'
    : (tr.instrument === 'synth') ? 'sawtooth'
    : (tr.instrument === 'guitar') ? 'sawtooth'
    : (tr.instrument === 'drums') ? 'square' : 'sine';
  osc.type = wave;
  osc.frequency.value = 440 * Math.pow(2, (midi - 69) / 12);

  // AutoPitch açıksa perde düzeltme + vibrato uygula.
  let pitchLfo = null;
  if (tr.fx.autopitch.on) {
    pitchLfo = applyAutopitchDetune(ctx, osc, tr, when, durSec);
  }

  const a = 0.008;
  const rel = Math.max(0.02, Math.min(0.25, durSec * 0.5));
  g.gain.setValueAtTime(0, when);
  g.gain.linearRampToValueAtTime(amp, when + a);
  g.gain.setValueAtTime(amp, Math.max(when + a, when + durSec - rel));
  g.gain.linearRampToValueAtTime(0, when + durSec + 0.02);

  osc.connect(g); g.connect(n.input);
  osc.start(when);
  osc.stop(when + durSec + 0.05);
  activeSources.push(osc);
  if (pitchLfo) activeSources.push(pitchLfo);
}

/*
 * AutoPitch — perde düzeltme motoru.
 *
 * amount (%) : hedefe çekilme oranı (düzeltme derinliği)
 * speed  (%) : düzeltme tepki hızı / vibrato frekansı
 *
 * Kaydedilmiş bir bölge (vokal/enstrüman) üzerinde gerçek perde tespiti
 * (otokorelasyon) yapılır, tespit edilen perde proje tonundaki (state.key)
 * en yakın notaya 'amount' oranında çekilir. Sentezleyici notaları zaten
 * doğru perdede çaldığından onlara sadece doğallık için hafif bir
 * 'speed' vibratosu eklenir.
 */
const NOTE_PC = { C:0,'B#':0,'C#':1,DB:1,D:2,'D#':3,EB:3,E:4,'FB':4,F:5,'E#':5,'F#':6,GB:6,G:7,'G#':8,AB:8,A:9,'A#':10,BB:10,B:11,'CB':11 };
const SCALE_STEPS_MAJOR = [0,2,4,5,7,9,11];
const SCALE_STEPS_MINOR = [0,2,3,5,7,8,10];

function studioKeyScalePCs(keyStr) {
  const k = String(keyStr || 'C').trim();
  const minor = /m$/i.test(k) && k.length > 1;
  const rootRaw = (minor ? k.slice(0, -1) : k).toUpperCase();
  const rootPc = (rootRaw in NOTE_PC) ? NOTE_PC[rootRaw] : 0;
  const steps = minor ? SCALE_STEPS_MINOR : SCALE_STEPS_MAJOR;
  return steps.map(s => (rootPc + s) % 12);
}

function nearestScaleMidi(midi, keyStr) {
  const scalePCs = studioKeyScalePCs(keyStr);
  const rounded = Math.round(midi);
  const pc = ((rounded % 12) + 12) % 12;
  let best = rounded, bestDist = Infinity;
  scalePCs.forEach(spc => {
    [spc - 12, spc, spc + 12].forEach(cand => {
      const d = Math.abs(cand - pc);
      if (d < bestDist) { bestDist = d; best = rounded - pc + cand; }
    });
  });
  return best;
}

/* Basit ama etkili otokorelasyon tabanlı perde (F0) tespiti.
   Buffer içindeki en yüksek enerjili (seslendirilmiş) pencereyi bulup
   o pencere üzerinde temel frekansı hesaplar. */
function detectPitchHz(buffer) {
  if (!buffer || !buffer.getChannelData) return null;
  const data = buffer.getChannelData(0);
  const sr = buffer.sampleRate;
  if (!data || !data.length) return null;

  const winSize = Math.min(data.length, Math.round(sr * 0.05)); // ~50ms
  if (winSize < 256) return null;
  const hop = Math.max(1, Math.round(sr * 0.02));

  let bestStart = 0, bestEnergy = -1;
  for (let start = 0; start + winSize <= data.length; start += hop) {
    let sum = 0;
    for (let i = start; i < start + winSize; i += 4) sum += data[i] * data[i];
    if (sum > bestEnergy) { bestEnergy = sum; bestStart = start; }
  }
  if (bestEnergy <= 0.0000001) return null; // sessizlik: tespit edilecek perde yok

  const win = data.subarray(bestStart, bestStart + winSize);
  const minFreq = 70, maxFreq = 1000;
  const maxLag = Math.min(win.length - 1, Math.floor(sr / minFreq));
  const minLag = Math.max(2, Math.floor(sr / maxFreq));

  let bestLag = -1, bestCorr = 0;
  for (let lag = minLag; lag <= maxLag; lag++) {
    let corr = 0;
    for (let i = 0; i < win.length - lag; i += 2) corr += win[i] * win[i + lag];
    if (corr > bestCorr) { bestCorr = corr; bestLag = lag; }
  }
  if (bestLag <= 0) return null;
  return sr / bestLag;
}

/* Bölgenin perde düzeltme miktarını (cent) tespit edip önbelleğe alır. */
function getRegionPitchCorrectionCents(rg) {
  if (!rg) return 0;
  if (rg._pitchCorrectionCents != null) return rg._pitchCorrectionCents;
  let cents = 0;
  try {
    const f0 = detectPitchHz(rg.buffer);
    if (f0 && f0 > 55 && f0 < 1200) {
      const midi = 69 + 12 * Math.log2(f0 / 440);
      const targetMidi = nearestScaleMidi(midi, (typeof state !== 'undefined' && state.key) ? state.key : 'C');
      cents = (targetMidi - midi) * 100;
    }
  } catch (e) { cents = 0; }
  rg._pitchCorrectionCents = cents;
  return cents;
}

function applyAutopitchDetune(ctx, node, tr, when, durSec, rg) {
  const ap = tr.fx.autopitch || {};
  const amount = clamp((ap.amount == null ? 65 : ap.amount) / 100, 0, 1);
  const speed  = clamp((ap.speed  == null ? 45 : ap.speed)  / 100, 0, 1);

  // Perde düzeltme: kayıtlı bölgede gerçek F0 tespiti + tona en yakın
  // notaya çekme. Sentez notalar zaten doğru perdede olduğundan 0 kalır.
  let baseDetune = 0;
  if (rg && rg.buffer) {
    baseDetune = clamp(getRegionPitchCorrectionCents(rg) * amount, -600, 600);
  }
  // Vibrato (titreşim): hız ile birlikte artan, miktarla ölçeklenen sapma
  const vibDepth = amount * (2 + speed * 10);   // cent
  const vibRate  = 4 + speed * 9;               // Hz

  // Perde düzeltme ofsetini uygula (geçerli perde her zaman duyulur)
  const detuneParam = node.detune;
  if (detuneParam && detuneParam.setValueAtTime) {
    detuneParam.setValueAtTime(baseDetune, when);
  }

  // Vibrato LFO — düzeltilmiş perdeyi hafifçe süsler
  const lfo = ctx.createOscillator();
  const lfoGain = ctx.createGain();
  lfo.type = 'sine';
  lfo.frequency.value = vibRate;
  lfoGain.gain.value = vibDepth;
  lfo.connect(lfoGain);
  lfoGain.connect(node.detune);

  // Yumuşak giriş (sesin başında vibrato hemen başlamasın)
  const startAt = when + 0.05;
  lfoGain.gain.setValueAtTime(0.0001, when);
  lfoGain.gain.linearRampToValueAtTime(vibDepth, startAt);
  lfo.start(when);
  lfo.stop(when + Math.max(0.1, durSec) + 0.1);
  return lfo;
}

/* Davul vuruşu sentezle. */
function playDrumNow(tr, type, when, amp) {
  if (!AE.ready) return;
  const ctx = AE.ctx;
  const n = buildTrackChain(tr);

  if (type === 'kick') {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.frequency.setValueAtTime(140, when);
    osc.frequency.exponentialRampToValueAtTime(45, when + 0.13);
    g.gain.setValueAtTime(amp * 1.15, when);
    g.gain.exponentialRampToValueAtTime(0.001, when + 0.34);
    osc.connect(g); g.connect(n.input);
    osc.start(when); osc.stop(when + 0.36);
    activeSources.push(osc);
    return;
  }

  // Gürültü temelli vuruşlar
  const len = type === 'hat_open' ? 0.34 : (type === 'clap' ? 0.22 : 0.20);
  const src = ctx.createBufferSource();
  src.buffer = noiseBuffer(len);

  const f = ctx.createBiquadFilter();
  if (type === 'snare' || type === 'clap') {
    f.type = 'bandpass'; f.frequency.value = 1900; f.Q.value = 0.75;
  } else if (type === 'hat_closed' || type === 'hat_open') {
    f.type = 'highpass'; f.frequency.value = 7800;
  } else {
    f.type = 'bandpass'; f.frequency.value = 420; f.Q.value = 1.1;
  }

  const g = ctx.createGain();
  const peak = (type === 'hat_closed' || type === 'hat_open') ? amp * 0.4 : amp * 0.8;
  g.gain.setValueAtTime(peak, when);
  g.gain.exponentialRampToValueAtTime(0.001, when + len);

  src.connect(f); f.connect(g); g.connect(n.input);
  src.start(when); src.stop(when + len + 0.02);
  activeSources.push(src);

  // Snare / clap için tonal bileşen
  if (type === 'snare' || type === 'clap') {
    const osc = ctx.createOscillator();
    const g2 = ctx.createGain();
    osc.frequency.value = type === 'snare' ? 190 : 240;
    g2.gain.setValueAtTime(amp * 0.42, when);
    g2.gain.exponentialRampToValueAtTime(0.001, when + len * 0.7);
    osc.connect(g2); g2.connect(n.input);
    osc.start(when); osc.stop(when + len);
    activeSources.push(osc);
  }
}

let noiseCache = {};
function noiseBuffer(sec) {
  const key = sec.toFixed(3);
  if (noiseCache[key]) return noiseCache[key];
  const rate = AE.ctx.sampleRate;
  const len = Math.max(1, Math.floor(rate * sec));
  const b = AE.ctx.createBuffer(1, len, rate);
  const d = b.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  noiseCache[key] = b;
  return b;
}

/* ============================================================
   TRANSPORT
   ============================================================ */
async function play() {
  await AE.init();
  if (!AE.ready) return;

  state.isPlaying = true;
  state.startBeat = state.playheadBeat;
  state.startCtxTime = AE.ctx.currentTime;

  scheduleAll(state.startBeat);
  startMetronome();

  $('btnPlay').innerHTML = '<i class="bi bi-pause-fill"></i>';
  $('timeDisplay').classList.add('rec');
  $('timeDisplay').classList.remove('rec');
  $('timeDisplay').classList.toggle('rec', false);
  updateStatus('statEngine', 'Çalınıyor');

  if (!rafId) rafId = requestAnimationFrame(animLoop);
}

function pause() {
  if (!state.isPlaying) return;
  const beat = currentBeat();
  state.isPlaying = false;
  state.playheadBeat = beat;

  activeSources.forEach(s => { try { s.stop(); } catch (e) {} });
  activeSources = [];
  stopMetronome();

  $('btnPlay').innerHTML = '<i class="bi bi-play-fill"></i>';
  positionPlayhead();
  updateStatus('statEngine', 'Duraklatıldı');
}

function stopAll() {
  state.isPlaying = false;
  activeSources.forEach(s => { try { s.stop(); } catch (e) {} });
  activeSources = [];
  stopMetronome();
  stopLoopPreview();
  state.playheadBeat = 0;
  $('btnPlay').innerHTML = '<i class="bi bi-play-fill"></i>';
  $('timeDisplay').innerHTML = `1.1.1<span style="opacity:.45"> · </span>00:00.0`;
  positionPlayhead();
  updateStatus('statEngine', 'Durduruldu');
}

function togglePlay() {
  if (state.isPlaying) pause(); else play();
}

function seekToBeat(beat, reschedule) {
  state.playheadBeat = Math.max(0, beat);
  if (state.isPlaying) {
    state.startBeat = state.playheadBeat;
    state.startCtxTime = AE.ctx.currentTime;
    if (reschedule !== false) scheduleAll(state.playheadBeat);
  }
  positionPlayhead();
}

/* ============================================================
   METRONOM
   ============================================================ */
let metronomeTimer = null;
let metroNext = 0;
let metroBeatCounter = 0;

function startMetronome() {
  if (!state.metronome || !AE.ready) return;
  stopMetronome();
  metroNext = AE.ctx.currentTime;
  metroBeatCounter = Math.floor(state.playheadBeat) % Math.max(1, Math.round(beatsPerBar()));

  const tick = () => {
    if (!state.isPlaying || !state.metronome) return;
    const now = AE.ctx.currentTime;
    const spb = 60 / state.bpm;
    while (metroNext < now + 0.15) {
      const bpb = Math.max(1, Math.round(beatsPerBar()));
      const accent = (metroBeatCounter % bpb) === 0;
      clickAt(metroNext, accent);
      metroNext += spb;
      metroBeatCounter++;
    }
    metronomeTimer = setTimeout(tick, 25);
  };
  tick();
}

function stopMetronome() {
  if (metronomeTimer) { clearTimeout(metronomeTimer); metronomeTimer = null; }
}

function clickAt(when, accent) {
  const ctx = AE.ctx;
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = 'square';
  osc.frequency.value = accent ? 1750 : 1150;
  g.gain.setValueAtTime(0.0001, when);
  g.gain.linearRampToValueAtTime(accent ? 0.22 : 0.13, when + 0.002);
  g.gain.exponentialRampToValueAtTime(0.0001, when + 0.05);
  osc.connect(g);
  g.connect(AE.master);
  osc.start(when); osc.stop(when + 0.06);
}

/* ============================================================
   MİKROFON KAYDI
   ============================================================ */
let micStream = null;
let mediaRecorder = null;
let recChunks = [];
let recTrackId = null;
let recStartBeat = 0;
let recTimerStart = 0;
let recMeterCtx = null;
let recMeterRaf = null;

async function ensureMic() {
  if (micStream && micStream.active) return micStream;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showToast('Tarayıcınız mikrofon erişimini desteklemiyor.', 'err');
    return null;
  }
  try {
    micStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false,
        channelCount: 1
      }
    });
    updateStatus('statMic', 'Mikrofon: bağlı');
    $('statMic').parentElement.querySelector('.bi').className = 'bi bi-mic-fill';
    return micStream;
  } catch (err) {
    console.warn('Mikrofon hatası:', err);
    let msg = 'Mikrofon izni verilmedi.';
    if (err && err.name === 'NotFoundError') msg = 'Mikrofon bulunamadı. Bir mikrofon bağlayın.';
    else if (err && err.name === 'NotReadableError') msg = 'Mikrofon başka bir uygulama tarafından kullanılıyor.';
    else if (err && (err.name === 'NotAllowedError' || err.name === 'SecurityError')) {
      msg = 'Mikrofon izni reddedildi. Tarayıcı adres çubuğundaki kilit simgesinden izin verebilirsiniz.';
    }
    showToast(msg + ' Loop kütüphanesi ve enstrümanları yine de kullanabilirsiniz.', 'err', 6000);
    updateStatus('statMic', 'Mikrofon: izin yok');
    $('statMic').parentElement.querySelector('.bi').className = 'bi bi-mic-mute-fill';
    return null;
  }
}

function pickRecorderMime() {
  const cands = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/ogg;codecs=opus',
    'audio/ogg',
    'audio/mp4'
  ];
  if (!window.MediaRecorder || !MediaRecorder.isTypeSupported) return '';
  for (const c of cands) {
    if (MediaRecorder.isTypeSupported(c)) return c;
  }
  return '';
}

async function startRecording() {
  if (state.isRecording) return;
  await AE.init();
  if (!AE.ready) return;

  let tr = state.tracks.find(t => t.armed);
  if (!tr) {
    // Kayda hazır kanal yoksa seçili kanalı hazırla, o da yoksa yeni aç
    tr = selectedTrack();
    if (!tr) { tr = addTrack({ type: 'vocal' }, true); renderTracks(); renderMixer(); }
    if (!tr) return;
    tr.armed = true;
    renderTracks();
  }

  const stream = await ensureMic();
  if (!stream) return;

  // Kayıt sırasında kanalı duyur (monitoring) - geri besleme riski nedeniyle kapalı tutulur
  recTrackId = tr.id;
  recChunks = [];

  const mime = pickRecorderMime();
  try {
    mediaRecorder = mime ? new MediaRecorder(stream, { mimeType: mime, audioBitsPerSecond: 128000 })
                         : new MediaRecorder(stream);
  } catch (e) {
    showToast('MediaRecorder başlatılamadı: ' + (e.message || e), 'err');
    return;
  }

  mediaRecorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) recChunks.push(e.data);
  };
  mediaRecorder.onerror = (e) => {
    console.error('MediaRecorder hatası:', e);
    showToast('Kayıt sırasında hata oluştu.', 'err');
  };
  mediaRecorder.onstop = () => finalizeRecording();

  // Kaydı çalmayla senkronize et
  if (!state.isPlaying) {
    await play();
  }
  recStartBeat = currentBeat();
  recTimerStart = performance.now();

  state.isRecording = true;
  recTrackId = tr.id;
  $('btnRec').classList.add('armed');
  $('timeDisplay').classList.add('rec');
  updateStatus('statEngine', 'KAYIT');
  updateInfoBar();
  updateStatus('statMic', 'Mikrofon: kaydediliyor');

  try { mediaRecorder.start(200); }
  catch (e) { showToast('Kayıt başlatılamadı: ' + (e.message || e), 'err'); state.isRecording = false; return; }

  showToast('🔴 Kayıt başladı! Bitirmek için kayıt butonuna tekrar basın.', 'ok', 3200);

  // Kayıt sırasında canlı seviye çubuğu (kanal metresi)
  startRecLiveMeter(tr.id, stream);
}

function startRecLiveMeter(trackId, stream) {
  try {
    if (recMeterCtx) { try { recMeterCtx.close(); } catch (e) {} }
    recMeterCtx = new (window.AudioContext || window.webkitAudioContext)();
    const src = recMeterCtx.createMediaStreamSource(stream);
    const an = recMeterCtx.createAnalyser();
    an.fftSize = 512;
    src.connect(an);
    const buf = new Float32Array(an.fftSize);

    const step = () => {
      if (!state.isRecording) { recMeterRaf = null; return; }
      an.getFloatTimeDomainData(buf);
      let peak = 0;
      for (let i = 0; i < buf.length; i++) { const v = Math.abs(buf[i]); if (v > peak) peak = v; }
      const el = document.querySelector(`[data-mx-meter="${trackId}"]`);
      if (el) el.style.width = clamp(peak * 130, 0, 100) + '%';
      recMeterRaf = requestAnimationFrame(step);
    };
    step();
  } catch (e) { /* canlı metre opsiyonel */ }
}

function stopRecording() {
  if (!state.isRecording) return;
  const endBeat = currentBeat();
  state.isRecording = false;
  $('btnRec').classList.remove('armed');
  $('timeDisplay').classList.remove('rec');

  stopRecLiveMeter();

  const duration = Math.max(0.25, endBeat - recStartBeat);
  if (mediaRecorder && mediaRecorder.state !== 'inactive') {
    mediaRecorder._endBeat = endBeat;
    mediaRecorder._startBeat = recStartBeat;
    mediaRecorder._lengthBeats = duration;
    try { mediaRecorder.stop(); } catch (e) {}
  }
  updateStatus('statMic', 'Mikrofon: bağlı');
  updateStatus('statEngine', state.isPlaying ? 'Çalınıyor' : 'Durduruldu');
  updateInfoBar();
}

function stopRecLiveMeter() {
  if (recMeterRaf) { cancelAnimationFrame(recMeterRaf); recMeterRaf = null; }
  if (recMeterCtx) { try { recMeterCtx.close(); } catch (e) {} recMeterCtx = null; }
}

async function finalizeRecording() {
  if (!recChunks.length || !recTrackId) { recChunks = []; return; }
  const mime = (mediaRecorder && mediaRecorder.mimeType) || 'audio/webm';
  const blob = new Blob(recChunks, { type: mime });
  recChunks = [];

  const tr = getTrack(recTrackId);
  const startBeat = (mediaRecorder && mediaRecorder._startBeat != null)
    ? mediaRecorder._startBeat : recStartBeat;
  let lengthBeats = (mediaRecorder && mediaRecorder._lengthBeats)
    ? mediaRecorder._lengthBeats : Math.max(1, currentBeat() - startBeat);

  // Kaydı decode edip gerçek süresini öğren
  let duration = 0, buffer = null;
  try {
    const ab = await blob.arrayBuffer();
    buffer = await AE.ctx.decodeAudioData(ab.slice(0));
    duration = buffer.duration;
    lengthBeats = Math.max(0.25, secToBeat(duration));
  } catch (e) {
    console.warn('Kayıt çözülemedi (tarayıcı formatı):', e);
    duration = beatToSec(lengthBeats);
  }

  if (tr) {
    const blobUrl = URL.createObjectURL(blob);
    const rg = addRegion(tr.id, {
      name: 'Kayıt ' + (tr.regions.length + 1),
      startBeat: Math.max(0, startBeat),
      lengthBeats,
      color: tr.color,
      blobUrl,
      buffer,
      sourceKind: 'audio'
    });
    if (!buffer && rg) rg.blobUrl = blobUrl;
    markUnsaved();
    renderTracks();
    renderMixer();
    showToast(`Kayıt eklendi: <b>${fmtDur(duration)}</b>`, 'ok', 2600);

    // Sunucuya yükle (oturum varsa)
    if (state.user) {
      uploadRecordedAsset(blob, duration, rg);
    }
  }
  recTrackId = null;
}

async function uploadRecordedAsset(blob, duration, region) {
  try {
    const fd = new FormData();
    const ext = (blob.type.includes('ogg')) ? 'ogg' : (blob.type.includes('mp4')) ? 'm4a' : 'webm';
    fd.append('audio', blob, 'studio_rec_' + Date.now() + '.' + ext);
    fd.append('duration', String(duration));
    if (state.projectId) fd.append('project_id', String(state.projectId));

    const res = await fetch('studio.php?action=upload_asset', { method: 'POST', body: fd });
    const data = await res.json();
    if (data && data.status === 'success') {
      if (region) region.assetId = data.asset.id;
      updateStatus('statSaved', 'Ses sunucuya yüklendi');
    } else if (data && data.message) {
      showToast('Ses sunucuya yüklenemedi: ' + data.message, 'info', 4200);
    }
  } catch (e) {
    console.warn('Ses yükleme hatası:', e);
  }
}

/* ============================================================
   PİYANO (SANAL KLAVYE)
   ============================================================ */
const NOTE_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const KEYMAP = {
  a:0, w:1, s:2, e:3, d:4, f:5, t:6, g:7, y:8, h:9, u:10, j:11, k:12,
  o:13, l:14, p:15, ';':16
};

function noteName(midi) {
  return NOTE_NAMES[((midi % 12) + 12) % 12] + (Math.floor(midi / 12) - 1);
}
function isBlackKey(midi) {
  const n = NOTE_NAMES[((midi % 12) + 12) % 12];
  return n.indexOf('#') > -1;
}

function buildPiano() {
  const host = $('pianoKeys');
  if (!host) return;
  host.innerHTML = '';
  const octave = parseInt($('octaveRange').value, 10) || 3;
  const startMidi = 12 * (octave + 1);      // C
  const whiteCount = 14;

  let whiteIdx = 0;
  for (let midi = startMidi; midi < startMidi + 24; midi++) {
    if (isBlackKey(midi)) {
      const b = document.createElement('div');
      b.className = 'pkey black';
      b.dataset.midi = midi;
      // Siyah tuşu beyaz tuşun sağ üstüne yerleştir
      const left = 34 * whiteIdx;   // beyaz tuş genişliği 34px
      b.style.left = left + 'px';
      host.appendChild(b);
    } else {
      const w = document.createElement('div');
      w.className = 'pkey';
      w.dataset.midi = midi;
      host.appendChild(w);
      whiteIdx++;
      if (whiteIdx >= whiteCount) break;
    }
  }

  host.querySelectorAll('.pkey').forEach(k => {
    k.addEventListener('mousedown', (e) => { e.preventDefault(); triggerPianoKey(k, true); });
    k.addEventListener('mouseup',   () => triggerPianoKey(k, false));
    k.addEventListener('mouseleave',() => triggerPianoKey(k, false));
    k.addEventListener('touchstart',(e) => { e.preventDefault(); triggerPianoKey(k, true); }, { passive: false });
    k.addEventListener('touchend',  (e) => { e.preventDefault(); triggerPianoKey(k, false); }, { passive: false });
  });
}

let pianoHeld = {};
let pianoScheduledStart = 0;

function triggerPianoKey(el, on) {
  const midi = parseInt(el.dataset.midi, 10);
  if (isNaN(midi)) return;
  if (on) {
    if (pianoHeld[midi]) return;
    pianoHeld[midi] = { start: performance.now() };
    el.classList.add('on');
    pianoAttack(midi);
  } else {
    el.classList.remove('on');
    const info = pianoHeld[midi];
    delete pianoHeld[midi];
    if (info) pianoRecordNote(midi, info.start, performance.now());
  }
}

function pianoWaveType() {
  const w = $('pianoWave') ? $('pianoWave').value : 'sine';
  return w;
}

function pianoAttack(midi) {
  // Kısa bir önizleme sesi (chord/normal kanal)
  if (!AE.ready) { AE.init().then(() => { if (AE.ready) pianoAttack(midi); }); return; }
  const ctx = AE.ctx;
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = pianoWaveType();
  osc.frequency.value = 440 * Math.pow(2, (midi - 69) / 12);
  const when = ctx.currentTime;
  g.gain.setValueAtTime(0.0001, when);
  g.gain.linearRampToValueAtTime(0.28, when + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, when + 0.9);
  osc.connect(g); g.connect(AE.master);
  osc.start(when); osc.stop(when + 1.0);
  activeSources.push(osc);
}

// Piyano kayıt defteri: çalınan notaları vuruş zamanına göre sakla
let pianoNotes = [];
function pianoRecordNote(midi, tStartMs, tEndMs) {
  // Vuruşa çevir (kayıt aktifse playhead'e göre, değilse serbest zaman)
  const durSec = Math.max(0.08, (tEndMs - tStartMs) / 1000);
  let beat;
  if (state.isPlaying) {
    beat = Math.max(0, currentBeat() - secToBeat(durSec));
  } else {
    beat = pianoNotes.length ? (pianoNotes[pianoNotes.length - 1].beat + pianoNotes[pianoNotes.length - 1].dur) : 0;
  }
  beat = snapBeat(beat);
  pianoNotes.push({ beat, midi, note: midi, dur: Math.max(0.25, secToBeat(durSec)) });
  if (pianoNotes.length > 2000) pianoNotes = pianoNotes.slice(-2000);
}

function snapBeat(beat) {
  const s = state.snap;
  if (!s || s <= 0) return Math.max(0, beat);
  return Math.max(0, Math.round(beat / s) * s);
}

/* ============================================================
   DAVUL MAKİNESİ
   ============================================================ */
const DRUM_ROWS = [
  { id: 'kick',       label: 'Kick',        color: '#ffffff' },
  { id: 'snare',      label: 'Snare',       color: '#ffffff' },
  { id: 'hat_closed', label: 'Hi-Hat Kap.', color: '#ffffff' },
  { id: 'hat_open',   label: 'Hi-Hat Açık', color: '#ffffff' },
  { id: 'clap',       label: 'Clap',        color: '#ffffff' },
  { id: 'tom',        label: 'Tom',         color: '#ffffff' },
  { id: 'ride',       label: 'Ride',        color: '#ffffff' }
];
const DM_STEPS = 16;

function initDrumPattern(preset) {
  const empty = () =>DRUM_ROWS.map(() => new Array(DM_STEPS).fill(0));
  state.drumPattern = empty();

  const set = (rowId, steps) => {
    const i = DRUM_ROWS.findIndex(r => r.id === rowId);
    if (i < 0) return;
    steps.forEach(s => { if (s >= 0 && s < DM_STEPS) state.drumPattern[i][s] = 1; });
  };

  switch (preset) {
    case 'boom_bap':
      set('kick', [0, 6, 10]);
      set('snare', [4, 12]);
      set('hat_closed', [0,2,4,6,8,10,12,14]);
      break;
    case 'trap':
      set('kick', [0, 3, 8, 11]);
      set('snare', [4, 12]);
      set('hat_closed', [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]);
      set('hat_open', [7, 15]);
      break;
    case 'four_floor':
      set('kick', [0, 4, 8, 12]);
      set('clap', [4, 12]);
      set('hat_closed', [2, 6, 10, 14]);
      set('hat_open', [6, 14]);
      break;
    case 'rock':
      set('kick', [0, 8, 10]);
      set('snare', [4, 12]);
      set('hat_closed', [0,2,4,6,8,10,12,14]);
      set('tom', [14]);
      break;
    case 'perc':
      set('hat_closed', [0,2,3,5,6,8,9,11,12,14,15]);
      set('ride', [0,4,8,12]);
      set('kick', [0, 8]);
      break;
    case 'empty':
    default:
      break;
  }
  renderDrumGrid();
}

function renderDrumGrid() {
  const host = $('drumSeq');
  if (!host) return;
  if (!state.drumPattern.length) initDrumPattern('boom_bap');

  host.innerHTML = '';
  DRUM_ROWS.forEach((row, ri) => {
    const r = document.createElement('div');
    r.className = 'dm-row';
    const lbl = document.createElement('div');
    lbl.className = 'dm-lbl';
    lbl.textContent = row.label;
    r.appendChild(lbl);

    for (let s = 0; s < DM_STEPS; s++) {
      const step = document.createElement('div');
      step.className = 'dm-step' + (state.drumPattern[ri][s] ? ' on' : '') + (s % 4 === 0 ? ' beat' : '');
      step.style.setProperty('--sc', row.color);
      step.dataset.row = ri;
      step.dataset.step = s;
      r.appendChild(step);
    }
    host.appendChild(r);
  });
}

function toggleDrumStep(rowIdx, stepIdx) {
  if (!state.drumPattern[rowIdx]) return;
  const v = state.drumPattern[rowIdx][stepIdx] ? 0 : 1;
  state.drumPattern[rowIdx][stepIdx] = v;
  const el = document.querySelector(`.dm-step[data-row="${rowIdx}"][data-step="${stepIdx}"]`);
  if (el) el.classList.toggle('on', !!v);
  markUnsaved();
  if (v) previewDrum(rowIdx);
}

function previewDrum(rowIdx) {
  if (!AE.ready) { AE.init().then(() => { if (AE.ready) previewDrum(rowIdx); }); return; }
  const row = DRUM_ROWS[rowIdx];
  if (!row) return;
  // Geçici bir davul kanal zinciri kullan
  let tr = state.tracks.find(t => t.type === 'drums');
  if (!tr) tr = { id: '__preview_drum', type: 'drums', instrument: 'drums',
                  volume: .9, pan: 0, muted: false, soloed: false, fx: {autopitch:{on:0},reverb:{on:0},delay:{on:0},eq:{on:0,low:0,mid:0,high:0},compressor:{on:0,threshold:0,ratio:1}} };
  if (tr.id === '__preview_drum') {
    // Geçici zincir
    if (!trackNodes['__preview_drum']) {
      const g = AE.ctx.createGain();
      g.gain.value = 0.9;
      g.connect(AE.master);
      trackNodes['__preview_drum'] = { input: g, gain: g, eqLow:g,eqMid:g,eqHigh:g,comp:g,dry:g,delay:g,delayFb:g,wetDelay:g,conv:g,wetRev:g,panner:null };
    }
  }
  playDrumNow(tr, row.id, AE.ctx.currentTime + 0.02, 0.9);
}

/* Davul desenini seçili kanala bölge olarak yaz (2 bar döngü) */
function writeDrumsToTrack() {
  let tr = selectedTrack();
  if (!tr) { tr = addTrack({ type: 'drums' }, true); renderTracks(); renderMixer(); }
  if (!tr) return;
  const notes = [];
  const stepBeats = 0.25;   // 16'lık nota
  const reps = 4;           // 4 kez tekrarla (2 bar -> 8 vuruş * 4)

  for (let rep = 0; rep < reps; rep++) {
    DRUM_ROWS.forEach((row, ri) => {
      const arr = state.drumPattern[ri] || [];
      arr.forEach((v, s) => {
        if (!v) return;
        notes.push({
          beat: (rep * DM_STEPS + s) * stepBeats,
          dur: stepBeats * 0.9,
          drum: row.id
        });
      });
    });
  }
  if (!notes.length) { showToast('Davul deseni boş — önce adımları işaretleyin.', 'info'); return; }

  tr.regions.push({
    id: newId('rgn'),
    name: 'Davul Deseni',
    startBeat: snapBeat(state.playheadBeat),
    lengthBeats: DM_STEPS * stepBeats * reps,
    color: tr.color,
    blobUrl: null,
    buffer: null,
    sourceKind: 'drums',
    gain: 1,
    drumNotes: notes
  });
  markUnsaved();
  renderTracks();
  updateInfoBar();
  showToast('Davul deseni kanala yazıldı.', 'ok');
}

/* ============================================================
   LOOP KÜTÜPHANESİ
   ============================================================ */
async function loadLoops() {
  try {
    const res = await fetch('studio.php?action=get_loops');
    const data = await res.json();
    if (data && data.status === 'success') {
      state.loops = data.loops || [];
      renderLoops();
    } else {
      $('loopsGrid').innerHTML = `<div class="loading-wrap"><i class="bi bi-exclamation-triangle text-warning" style="font-size:1.6rem"></i><span>Loop kütüphanesi yüklenemedi.</span></div>`;
    }
  } catch (e) {
    console.error(e);
    const g = $('loopsGrid');
    if (g) g.innerHTML = `<div class="loading-wrap"><i class="bi bi-wifi-off text-warning" style="font-size:1.6rem"></i><span>Bağlantı hatası.</span></div>`;
  }
}

function renderLoops() {
  const g = $('loopsGrid');
  if (!g) return;
  const q = ($('loopSearch') ? $('loopSearch').value : '').trim().toLowerCase();
  const cat = state.activeLoopCat;

  let list = state.loops;
  if (cat !== 'all') list = list.filter(l => l.category === cat);
  if (q) list = list.filter(l => l.name.toLowerCase().includes(q) || l.category.toLowerCase().includes(q));

  if (!list.length) {
    g.innerHTML = `<div class="loading-wrap"><i class="bi bi-search" style="font-size:1.6rem"></i><span>Sonuç bulunamadı.</span></div>`;
    return;
  }

  g.innerHTML = list.map(l => `
    <div class="loop-card" data-loop-id="${l.id}" style="--lc:${l.color}">
      <button class="lc-play" data-loop-play="${l.id}" title="Dinle"><i class="bi bi-play-fill"></i></button>
      <div class="lc-info">
        <div class="lc-name">${esc(l.name)}</div>
        <div class="lc-meta">${esc(l.category)} · ${l.bpm} BPM · ${l.bars} bar</div>
      </div>
      <button class="lc-add" data-loop-add="${l.id}" title="Kanala ekle"><i class="bi bi-plus-lg"></i></button>
    </div>
  `).join('');
}

/* Loop önizleme (tek başına dinle) */
async function previewLoop(loopId) {
  await AE.init();
  if (!AE.ready) return;
  const meta = state.loops.find(l => l.id === loopId);
  if (!meta) return;

  // Aynı loop'a basıldıysa durdur
  if (state.playingLoopId === loopId) { stopLoopPreview(); return; }
  stopLoopPreview();

  try {
    const buf = await getLoopBuffer(loopId);
    if (!buf) return;
    const ctx = AE.ctx;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const g = ctx.createGain();
    g.gain.value = 0.85;
    src.connect(g); g.connect(AE.master);
    src.start();
    src.onended = () => {
      if (state.playingLoopId === loopId) { state.playingLoopId = null; renderLoops(); }
    };
    state.playingLoopId = loopId;
    previewLoopSrc = src;
    renderLoops();
    const card = document.querySelector(`.loop-card[data-loop-id="${loopId}"]`);
    if (card) card.classList.add('playing');
  } catch (e) {
    showToast('Loop dinlenemedi: ' + (e.message || e), 'err');
  }
}

let previewLoopSrc = null;
function stopLoopPreview() {
  if (previewLoopSrc) { try { previewLoopSrc.stop(); } catch (e) {} previewLoopSrc = null; }
  state.playingLoopId = null;
  $$('.loop-card.playing').forEach(c => c.classList.remove('playing'));
}

/* Loop buffer önbelleği */
const loopBufferCache = {};
async function getLoopBuffer(loopId) {
  if (loopBufferCache[loopId]) return loopBufferCache[loopId];
  const meta = state.loops.find(l => l.id === loopId);
  if (!meta) return null;
  const res = await fetch(meta.url);
  if (!res.ok) throw new Error('Loop indirilemedi (' + res.status + ')');
  const ab = await res.arrayBuffer();
  const buf = await AE.ctx.decodeAudioData(ab);
  loopBufferCache[loopId] = buf;
  return buf;
}

/* Loop'u seçili kanala bölge olarak ekle */
async function addLoopToTrack(loopId) {
  await AE.init();
  if (!AE.ready) return;
  const meta = state.loops.find(l => l.id === loopId);
  if (!meta) return;

  let tr = selectedTrack();
  if (!tr) {
    // Loop türüne uygun bir kanal aç
    const t = meta.instrument === 'drums' ? 'drums'
      : meta.instrument === 'bass' ? 'bass'
      : meta.instrument === 'guitar' ? 'guitar'
      : 'instrument';
    tr = addTrack({ type: t, name: meta.name }, true);
    if (!tr) return;
    renderTracks(); renderMixer();
  }

  try {
    const buf = await getLoopBuffer(loopId);
    if (!buf) return;

    // Loop'u mevcut playhead'e hizala
    const startBeat = snapBeat(state.playheadBeat);
    const lengthBeats = Math.max(0.25, secToBeat(buf.duration));

    addRegion(tr.id, {
      name: meta.name,
      startBeat,
      lengthBeats,
      color: meta.color,
      buffer: buf,
      sourceKind: 'audio',
      gain: 0.95
    });
    markUnsaved();
    renderTracks();
    updateInfoBar();
    showToast(`<b>${esc(meta.name)}</b> → <b>${esc(tr.name)}</b> kanalına eklendi.`, 'ok');
  } catch (e) {
    showToast('Loop eklenemedi: ' + (e.message || e), 'err');
  }
}

/* ============================================================
   EFEKT ARAYÜZÜ
   ============================================================ */
function renderFxPane() {
  const g = $('fxGrid');
  if (!g) return;
  const tr = selectedTrack();

  if (!tr) {
    g.innerHTML = `<div class="loading-wrap"><i class="bi bi-sliders" style="font-size:1.6rem"></i><span>Efekt uygulamak için bir kanal seçin.</span></div>`;
    return;
  }
  g.innerHTML = fxCardsHTML(tr);
  bindFxControls(tr, g);
}

function fxCardsHTML(tr) {
  const f = tr.fx;
  const sw = (k, on) => `
    <label class="switch">
      <input type="checkbox" data-fxk="${k}" ${on ? 'checked' : ''}>
      <span></span>
    </label>`;

  return `
  <div class="fx-card">
    <div class="fx-card-head">
      <div class="fx-icon"><i class="bi bi-mic-fill"></i></div>
      <div class="fx-title"><b>AutoPitch</b><small>Vokal perde düzeltme</small></div>
      ${sw('autopitch', f.autopitch.on)}
    </div>
    <div class="knob-row">
      <div class="knob">
        <label>Miktar <span data-fxval="autopitch.amount">${f.autopitch.amount}%</span></label>
        <input type="range" data-fxr="autopitch.amount" min="0" max="100" value="${f.autopitch.amount}">
      </div>
      <div class="knob">
        <label>Hiz <span data-fxval="autopitch.speed">${f.autopitch.speed}%</span></label>
        <input type="range" data-fxr="autopitch.speed" min="0" max="100" value="${f.autopitch.speed}">
      </div>
    </div>
  </div>

  <div class="fx-card">
    <div class="fx-card-head">
      <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-water"></i></div>
      <div class="fx-title"><b>Reverb</b><small>Oda / salon yankısı</small></div>
      ${sw('reverb', f.reverb.on)}
    </div>
    <div class="knob-row">
      <div class="knob">
        <label>Karışım <span data-fxval="reverb.mix">${f.reverb.mix}%</span></label>
        <input type="range" data-fxr="reverb.mix" min="0" max="100" value="${f.reverb.mix}">
      </div>
      <div class="knob">
        <label>Oda Boyutu <span data-fxval="reverb.size">${f.reverb.size}%</span></label>
        <input type="range" data-fxr="reverb.size" min="0" max="100" value="${f.reverb.size}">
      </div>
    </div>
  </div>

  <div class="fx-card">
    <div class="fx-card-head">
      <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-hourglass-split"></i></div>
      <div class="fx-title"><b>Delay</b><small>Gecikme / echo</small></div>
      ${sw('delay', f.delay.on)}
    </div>
    <div class="knob-row">
      <div class="knob">
        <label>Karışım <span data-fxval="delay.mix">${f.delay.mix}%</span></label>
        <input type="range" data-fxr="delay.mix" min="0" max="100" value="${f.delay.mix}">
      </div>
      <div class="knob">
        <label>Geri Besleme <span data-fxval="delay.feedback">${f.delay.feedback}%</span></label>
        <input type="range" data-fxr="delay.feedback" min="0" max="85" value="${f.delay.feedback}">
      </div>
      <div class="knob">
        <label>Süre <span data-fxval="delay.time">${f.delay.time.toFixed(2)}s</span></label>
        <input type="range" data-fxr="delay.time" min="5" max="180" value="${Math.round(f.delay.time * 100)}">
      </div>
    </div>
  </div>

  <div class="fx-card">
    <div class="fx-card-head">
      <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-sliders2"></i></div>
      <div class="fx-title"><b>3 Bantlı Ekolayzer</b><small>Bas / Orta / Tiz</small></div>
      ${sw('eq', f.eq.on)}
    </div>
    <div class="knob-row">
      <div class="knob">
        <label>Bas <span data-fxval="eq.low">${f.eq.low > 0 ? '+' : ''}${f.eq.low} dB</span></label>
        <input type="range" data-fxr="eq.low" min="-15" max="15" value="${f.eq.low}">
      </div>
      <div class="knob">
        <label>Orta <span data-fxval="eq.mid">${f.eq.mid > 0 ? '+' : ''}${f.eq.mid} dB</span></label>
        <input type="range" data-fxr="eq.mid" min="-15" max="15" value="${f.eq.mid}">
      </div>
      <div class="knob">
        <label>Tiz <span data-fxval="eq.high">${f.eq.high > 0 ? '+' : ''}${f.eq.high} dB</span></label>
        <input type="range" data-fxr="eq.high" min="-15" max="15" value="${f.eq.high}">
      </div>
    </div>
  </div>

  <div class="fx-card">
    <div class="fx-card-head">
      <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-activity"></i></div>
      <div class="fx-title"><b>Kompresör</b><small>Dinamik aralık kontrolü</small></div>
      ${sw('compressor', f.compressor.on)}
    </div>
    <div class="knob-row">
      <div class="knob">
        <label>Eşik <span data-fxval="compressor.threshold">${f.compressor.threshold} dB</span></label>
        <input type="range" data-fxr="compressor.threshold" min="-60" max="0" value="${f.compressor.threshold}">
      </div>
      <div class="knob">
        <label>Oran <span data-fxval="compressor.ratio">${f.compressor.ratio}:1</span></label>
        <input type="range" data-fxr="compressor.ratio" min="1" max="20" value="${f.compressor.ratio}">
      </div>
    </div>
  </div>

  <div class="fx-card">
    <div class="fx-card-head">
      <div class="fx-icon" style="background:rgba(255,255,255,.16);color:#ffffff"><i class="bi bi-brush"></i></div>
      <div class="fx-title"><b>Kanal İşlemleri</b><small>${esc(tr.name)} (${esc(tr.typeLabel)})</small></div>
    </div>
    <div class="d-flex flex-wrap gap-2">
      <button class="ibtn" data-fxact="reset"><i class="bi bi-arrow-counterclockwise"></i><span>Sıfırla</span></button>
      <button class="ibtn" data-fxact="norm"><i class="bi bi-magic"></i><span>Normalize</span></button>
      <button class="ibtn" data-fxact="dup"><i class="bi bi-files"></i><span>Kanalı Kopyala</span></button>
      <button class="ibtn danger" data-fxact="clearregions"><i class="bi bi-eraser"></i><span>Bölgeleri Sil</span></button>
    </div>
  </div>`;
}

function bindFxControls(tr, root) {
  $$('[data-fxk]', root).forEach(cb => {
    cb.addEventListener('change', () => {
      const k = cb.dataset.fxk;
      tr.fx[k].on = cb.checked;
      buildTrackChain(tr);
      applyTrackFx(tr);
      markUnsaved();
      showToast(`${cb.checked ? 'Açıldı' : 'Kapatıldı'}: <b>${k}</b>`, 'info', 1800);
    });
  });

  $$('[data-fxr]', root).forEach(r => {
    r.addEventListener('input', () => {
      const path = r.dataset.fxr;
      const parts = path.split('.');
      let val = parseFloat(r.value);
      if (path === 'delay.time') {
        val = val / 100;
      }
      // Değeri tr.fx içine yaz
      if (tr.fx[parts[0]] && parts[1] in tr.fx[parts[0]]) {
        tr.fx[parts[0]][parts[1]] = val;
      }
      // Etiketi güncelle
      const lab = root.querySelector(`[data-fxval="${path}"]`);
      if (lab) {
        if (path === 'delay.time') lab.textContent = val.toFixed(2) + 's';
        else if (path.indexOf('eq.') === 0) lab.textContent = (val > 0 ? '+' : '') + val + ' dB';
        else if (path === 'compressor.threshold') lab.textContent = val + ' dB';
        else if (path === 'compressor.ratio') lab.textContent = val + ':1';
        else lab.textContent = val + '%';
      }
      buildTrackChain(tr);
      applyTrackFx(tr);
      markUnsaved();
    });
  });

  $$('[data-fxact]', root).forEach(b => {
    b.addEventListener('click', () => {
      const a = b.dataset.fxact;
      if (a === 'reset') {
        tr.fx = {
          autopitch: { on:false, amount:65, speed:45, key:'auto' },
          reverb:    { on:false, mix:22, size:45 },
          delay:     { on:false, mix:20, time:0.32, feedback:30 },
          eq:        { on:false, low:0, mid:0, high:0 },
          compressor:{ on:false, threshold:-20, ratio:4 }
        };
        buildTrackChain(tr); applyTrackFx(tr);
        renderFxPane(); markUnsaved();
        showToast('Efektler sıfırlandı.', 'info');
      } else if (a === 'norm') {
        // Bölgeleri normalize et (buffer peak'ine göre gain ayarla)
        let n = 0;
        tr.regions.forEach(rg => {
          if (!rg.buffer) return;
          const d = rg.buffer.getChannelData(0);
          let peak = 0;
          for (let i = 0; i < d.length; i += 40) { const v = Math.abs(d[i]); if (v > peak) peak = v; }
          if (peak > 0.0001) { rg.gain = clamp(1 / peak * 0.9, 0.1, 6); n++; }
        });
        renderTracks(); markUnsaved();
        showToast(n ? `${n} bölge normalize edildi.` : 'Normalize edilecek ses bölgesi yok.', n ? 'ok' : 'info');
      } else if (a === 'dup') {
        const copy = JSON.parse(JSON.stringify({
          name: tr.name + ' (Kopya)', type: tr.type, instrument: tr.instrument,
          color: tr.color, volume: tr.volume, pan: tr.pan, fx: tr.fx
        }));
        const nt = addTrack(copy, true);
        if (nt) {
          // Bölgeleri kopyala (buffer referansı paylaşılır)
          tr.regions.forEach(rg => nt.regions.push(Object.assign({}, rg, { id: newId('rgn') })));
          renderTracks(); renderMixer(); markUnsaved();
          showToast('Kanal kopyalandı.', 'ok');
        }
      } else if (a === 'clearregions') {
        if (!tr.regions.length) { showToast('Bu kanalda bölge yok.', 'info'); return; }
        if (!confirm(`"${tr.name}" kanalındaki ${tr.regions.length} bölgeyi silmek istediğinize emin misiniz?`)) return;
        tr.regions.forEach(r => { if (r.blobUrl) URL.revokeObjectURL(r.blobUrl); });
        tr.regions = [];
        renderTracks(); markUnsaved();
        showToast('Bölgeler silindi.', 'ok');
      }
    });
  });
}

/* ============================================================
   MASTERING
   ============================================================ */
const MASTER_PRESETS = {
  none:     { gain: 1.00, low: 0,   mid: 0,   high: 0,  comp: 0,   width: 1.00 },
  balanced: { gain: 1.05, low: 1.5, mid: 0,   high: 1.5, comp: 6,  width: 1.05 },
  loud:     { gain: 1.25, low: 2.5, mid: -1,  high: 2.5, comp: 14, width: 1.10 },
  warm:     { gain: 1.05, low: 3.5, mid: -1.5,high: -1,   comp: 5,  width: 1.00 },
  bright:   { gain: 1.05, low: -1,  mid: 1,   high: 4,    comp: 5,  width: 1.10 },
  bass:     { gain: 1.10, low: 5,   mid: -1,  high: 0,    comp: 8,  width: 1.00 },
  night:    { gain: 1.15, low: 1,   mid: 0,   high: -1.5, comp: 18, width: 0.95 }
};

let masterEqLow = null, masterEqMid = null, masterEqHigh = null, masterComp = null;

function ensureMasterChain() {
  if (!AE.ready) return;
  if (masterEqLow) return;
  const ctx = AE.ctx;
  masterEqLow = ctx.createBiquadFilter();
  masterEqLow.type = 'lowshelf'; masterEqLow.frequency.value = 180;
  masterEqMid = ctx.createBiquadFilter();
  masterEqMid.type = 'peaking'; masterEqMid.frequency.value = 1800; masterEqMid.Q.value = 0.9;
  masterEqHigh = ctx.createBiquadFilter();
  masterEqHigh.type = 'highshelf'; masterEqHigh.frequency.value = 6200;
  masterComp = ctx.createDynamicsCompressor();
  masterComp.knee.value = 6;
  masterComp.attack.value = 0.006;
  masterComp.release.value = 0.18;

  // Kanal çıkışlarını master EQ üzerinden geçir
  AE.master.disconnect();
  AE.master.connect(masterEqLow);
  masterEqLow.connect(masterEqMid);
  masterEqMid.connect(masterEqHigh);
  masterEqHigh.connect(masterComp);
  masterComp.connect(AE.splitter);
}

function applyMasterPreset(name) {
  const p = MASTER_PRESETS[name] || MASTER_PRESETS.none;
  state.masterPreset = name;
  ensureMasterChain();
  if (!AE.ready) return;
  if (masterEqLow) {
    masterEqLow.gain.value = p.low;
    masterEqMid.gain.value = p.mid;
    masterEqHigh.gain.value = p.high;
  }
  if (masterComp) {
    masterComp.threshold.value = -6 - p.comp;
    masterComp.ratio.value = p.comp > 0 ? (1 + p.comp / 3) : 1;
  }
  state.masterWidth = p.width;
  state.masterGain = p.gain * 0.85;

  const gEl = $('masterGain');
  if (gEl) gEl.value = Math.round(state.masterGain * 100);
  const wEl = $('masterWidth');
  if (wEl) wEl.value = Math.round(p.width * 100);
  const l1 = $('masterGainLbl'); if (l1) l1.textContent = Math.round(state.masterGain * 100) + '%';
  const l2 = $('masterWidthLbl'); if (l2) l2.textContent = Math.round(p.width * 100) + '%';
  const l3 = $('masterPresetLbl'); if (l3) l3.textContent = name.toUpperCase();
  if (AE.masterGain) AE.masterGain.gain.value = state.masterGain;
  markUnsaved();
}

/* ============================================================
   KAYIT / YÜKLEME (SUNUCU)
   ============================================================ */
function serializeProject() {
  // Blob/buffer nesneleri JSON'a girmez; sadece meta veri saklanır.
  return {
    version: 2,
    title: state.title,
    bpm: state.bpm,
    timeSig: state.timeSig,
    key: state.key,
    masterGain: state.masterGain,
    masterPreset: state.masterPreset,
    pxPerBeat: state.pxPerBeat,
    loopEnabled: state.loopEnabled,
    loopStart: state.loopStart,
    loopEnd: state.loopEnd,
    metronome: state.metronome,
    drumPattern: state.drumPattern,
    tracks: state.tracks.map(t => ({
      id: t.id, name: t.name, type: t.type, instrument: t.instrument, color: t.color,
      volume: t.volume, pan: t.pan, muted: t.muted, soloed: t.soloed, fx: t.fx,
      regions: t.regions.map(r => ({
        id: r.id, name: r.name, startBeat: r.startBeat, lengthBeats: r.lengthBeats,
        color: r.color, sourceKind: r.sourceKind, gain: r.gain,
        assetId: r.assetId || null,
        notes: r.notes || null,
        drumNotes: r.drumNotes || null
      }))
    }))
  };
}

async function saveProject(silent) {
  if (!state.user) {
    showToast('Projeyi kaydetmek için giriş yapmalısınız. Mixdown indirmeyi kullanabilirsiniz.', 'info', 5000);
    return false;
  }
  try {
    const payload = {
      id: state.projectId,
      title: state.title,
      bpm: state.bpm,
      time_sig: state.timeSig,
      key: state.key,
      master_gain: state.masterGain,
      master_preset: state.masterPreset,
      track_count: state.tracks.length,
      project_data: serializeProject()
    };
    const res = await fetch('studio.php?action=save_project', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data && data.status === 'success') {
      state.projectId = data.id;
      markSaved();
      if (!silent) showToast('Proje kaydedildi.', 'ok');
      return true;
    }
    showToast((data && data.message) || 'Proje kaydedilemedi.', 'err');
    return false;
  } catch (e) {
    showToast('Kaydetme hatası: ' + (e.message || e), 'err');
    return false;
  }
}

async function openProjectsModal() {
  const list = $('projectsList');
  list.innerHTML = `<div class="loading-wrap"><div class="spinner-border spinner-border-sm text-danger"></div><span>Yükleniyor...</span></div>`;
  new bootstrap.Modal($('projectsModal')).show();

  if (!state.user) {
    list.innerHTML = `<div class="panel-box" style="background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.25)">
      <div style="font-size:.8rem;color:var(--tx-2)">
        <i class="bi bi-info-circle text-warning"></i>
        Projelerinizi kaydetmek ve tekrar açmak için platforma giriş yapmanız gerekir.
        <br><br>Giriş yapmadan da stüdyoyu kullanabilir, <b>Mixdown</b> ile çalışmanızı WAV olarak indirebilirsiniz.
      </div></div>`;
    return;
  }

  try {
    const res = await fetch('studio.php?action=list_projects');
    const data = await res.json();
    const projects = (data && data.projects) || [];
    if (!projects.length) {
      list.innerHTML = `<div class="loading-wrap"><i class="bi bi-folder2" style="font-size:1.6rem"></i><span>Henüz kayıtlı projeniz yok.</span></div>`;
      return;
    }
    list.innerHTML = projects.map(p => `
      <div class="proj-item" data-pid="${p.id}">
        <i class="bi bi-music-note-beamed" style="font-size:1.2rem;color:var(--accent)"></i>
        <div class="pi-info">
          <b>${esc(p.title)}</b>
          <small>${p.bpm} BPM · ${p.time_sig} · ${p.track_count} kanal · ${esc(p.updated_at || '')}</small>
        </div>
        <button class="ibtn primary" data-popen="${p.id}"><i class="bi bi-box-arrow-in-down"></i><span>Aç</span></button>
        <button class="ibtn danger" data-pdel="${p.id}"><i class="bi bi-trash3"></i></button>
      </div>`).join('');
  } catch (e) {
    list.innerHTML = `<div class="loading-wrap"><i class="bi bi-wifi-off text-warning" style="font-size:1.6rem"></i><span>Bağlantı hatası.</span></div>`;
  }
}

async function deleteProject(pid) {
  if (!state.user) { showToast('Proje silmek için giriş yapmalısınız.', 'info'); return; }
  if (!confirm('Bu projeyi silmek istediğinize emin misiniz? Bu işlem geri alınamaz.')) return;
  try {
    const res = await fetch('studio.php?action=delete_project', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: pid })
    });
    const data = await res.json();
    if (data && data.status === 'success') {
      // Açık proje silindiyse yeni projeye geç
      if (String(state.projectId) === String(pid)) {
        state.projectId = null;
      }
      showToast('Proje silindi.', 'ok');
      openProjectsModal();
    } else {
      showToast((data && data.message) || 'Proje silinemedi.', 'err');
    }
  } catch (e) {
    showToast('Silme hatası: ' + (e.message || e), 'err');
  }
}

async function loadProject(pid) {
  try {
    const res = await fetch('studio.php?action=load_project&id=' + encodeURIComponent(pid));
    const data = await res.json();
    if (!data || data.status !== 'success') {
      showToast((data && data.message) || 'Proje yüklenemedi.', 'err');
      return;
    }
    const p = data.project;
    const pd = p.project_data || {};

    // Eski durumu temizle
    stopAll();
    state.tracks.forEach(t => t.regions.forEach(r => { if (r.blobUrl) URL.revokeObjectURL(r.blobUrl); }));
    Object.keys(trackNodes).forEach(k => { delete trackNodes[k]; });

    state.projectId = p.id;
    state.title = p.title || 'Yeni Proje';
    state.bpm = p.bpm || 120;
    state.timeSig = p.time_sig || '4/4';
    state.key = pd.key || p.musical_key || 'C';
    state.masterGain = p.master_gain != null ? p.master_gain : 0.85;
    state.masterPreset = p.master_preset || 'none';
    state.pxPerBeat = pd.pxPerBeat || 48;
    state.tracks = [];

    const assets = {};
    (p.assets || []).forEach(a => { assets[a.id] = a; });

    // Ses varlıklarını buffer'a çevir
    const assetBuffers = {};
    for (const aid in assets) {
      try {
        const r = await fetch(assets[aid].url);
        const ab = await r.arrayBuffer();
        await AE.init();
        assetBuffers[aid] = await AE.ctx.decodeAudioData(ab);
      } catch (e) { console.warn('Varlık çözülemedi', aid, e); }
    }

    (pd.tracks || []).forEach(t => {
      const nt = makeTrack({
        type: t.type, name: t.name, instrument: t.instrument, color: t.color
      });
      nt.id = t.id;
      nt.volume = t.volume != null ? t.volume : 0.85;
      nt.pan = t.pan != null ? t.pan : 0;
      nt.muted = !!t.muted;
      nt.soloed = !!t.soloed;
      nt.fx = t.fx || nt.fx;
      (t.regions || []).forEach(r => {
        nt.regions.push({
          id: r.id || newId('rgn'),
          name: r.name || 'Bölge',
          startBeat: r.startBeat || 0,
          lengthBeats: r.lengthBeats || 4,
          color: r.color || nt.color,
          blobUrl: null,
          buffer: (r.assetId && assetBuffers[r.assetId]) ? assetBuffers[r.assetId] : null,
          assetId: r.assetId || null,
          sourceKind: r.sourceKind || 'audio',
          gain: r.gain != null ? r.gain : 1,
          notes: r.notes || null,
          drumNotes: r.drumNotes || null
        });
      });
      state.tracks.push(nt);
    });

    state.selectedTrackId = state.tracks[0] ? state.tracks[0].id : null;
    if (pd.drumPattern && pd.drumPattern.length) state.drumPattern = pd.drumPattern;
    else initDrumPattern('boom_bap');
    state.loopEnabled = !!pd.loopEnabled;
    state.loopStart = pd.loopStart || 0;
    state.loopEnd = pd.loopEnd || 0;
    state.metronome = !!pd.metronome;

    syncTransportUI();
    renderTracks();
    renderMixer();
    renderDrumGrid();
    renderRuler();
    updateInfoBar();
    ensureMasterChain();
    applyMasterPreset(state.masterPreset);
    markSaved();

    const m = bootstrap.Modal.getInstance($('projectsModal'));
    if (m) m.hide();
    showToast(`Proje açıldı: <b>${esc(state.title)}</b>`, 'ok');
  } catch (e) {
    showToast('Proje açma hatası: ' + (e.message || e), 'err');
  }
}

function newProject() {
  if (!confirm('Yeni proje başlatmak istiyor musunuz? Kaydedilmemiş değişiklikler kaybolur.')) return;
  stopAll();
  state.tracks.forEach(t => t.regions.forEach(r => { if (r.blobUrl) URL.revokeObjectURL(r.blobUrl); }));
  Object.keys(trackNodes).forEach(k => { delete trackNodes[k]; });
  state.projectId = null;
  state.title = 'Yeni Proje';
  state.tracks = [];
  state.selectedTrackId = null;
  state.playheadBeat = 0;
  state.loopEnabled = false;
  initDrumPattern('boom_bap');
  $('projectTitle').value = state.title;
  renderTracks(); renderMixer(); renderRuler(); updateInfoBar(); renderFxPane();
  markSaved();
  const m = bootstrap.Modal.getInstance($('projectsModal'));
  if (m) m.hide();
  showToast('Yeni proje başlatıldı.', 'ok');
}

/* ============================================================
   MIXDOWN / DIŞA AKTARMA (OFFLINE RENDER)
   ============================================================ */
async function doExport() {
  const title = ($('exportTitle').value || state.title || 'Kuduko Stüdyo Kaydı').trim();
  const secs = clampInt($('exportDuration'), 1, 600, 30);

  const btn = $('doExportBtn');
  const oldHtml = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Karıştırılıyor...';

  try {
    const rendered = await renderOffline(secs);
    if (!rendered) throw new Error('Karıştırma başarısız oldu.');

    const blob = encodeWav(rendered.buffers, rendered.sampleRate);
    const fname = (title.replace(/[^\w\-\s.ÇĞİÖŞÜçğıöşü]/g, '_') || 'mixdown') + '.wav';

    // İndir
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = fname;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);

    showToast('Mixdown indirildi: <b>' + esc(fname) + '</b>', 'ok', 4200);

    // Kütüphaneye ekle
    if ($('exportAddLibrary').checked && state.user) {
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Kütüphaneye ekleniyor...';
      const fd = new FormData();
      fd.append('mixdown', blob, fname);
      fd.append('title', title);
      fd.append('duration', String(Math.round(secs)));
      fd.append('genre', 'Stüdyo');
      const res = await fetch('studio.php?action=upload_mixdown', { method: 'POST', body: fd });
      const data = await res.json();
      if (data && data.status === 'success') {
        showToast('Mixdown müzik kütüphanenize eklendi! 🎵', 'ok', 4600);
      } else {
        showToast((data && data.message) || 'Kütüphaneye eklenemedi.', 'info', 4200);
      }
    }

    bootstrap.Modal.getInstance($('exportModal')).hide();
  } catch (e) {
    console.error(e);
    showToast('Dışa aktarma hatası: ' + (e.message || e), 'err', 5000);
  }

  btn.disabled = false;
  btn.innerHTML = oldHtml;
}

/** OfflineAudioContext ile gerçek zamanlıdan hızlı karıştırma. */
async function renderOffline(seconds) {
  const rate = 44100;
  const frames = Math.ceil(seconds * rate);
  const OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  if (!OAC) { showToast('Tarayıcınız çevrimdışı karıştırmayı desteklemiyor.', 'err'); return null; }

  const off = new OAC(1, frames, rate);

  // Master zinciri (offline)
  const masterGain = off.createGain();
  masterGain.gain.value = state.masterGain;

  const mEqLow = off.createBiquadFilter(); mEqLow.type = 'lowshelf'; mEqLow.frequency.value = 180;
  const mEqMid = off.createBiquadFilter(); mEqMid.type = 'peaking'; mEqMid.frequency.value = 1800; mEqMid.Q.value = 0.9;
  const mEqHigh = off.createBiquadFilter(); mEqHigh.type = 'highshelf'; mEqHigh.frequency.value = 6200;
  const mComp = off.createDynamicsCompressor(); mComp.knee.value = 6; mComp.attack.value = 0.006; mComp.release.value = 0.18;

  const preset = MASTER_PRESETS[state.masterPreset] || MASTER_PRESETS.none;
  mEqLow.gain.value = preset.low;
  mEqMid.gain.value = preset.mid;
  mEqHigh.gain.value = preset.high;
  mComp.threshold.value = -6 - preset.comp;
  mComp.ratio.value = preset.comp > 0 ? (1 + preset.comp / 3) : 1;

  const limiter = off.createDynamicsCompressor();
  limiter.threshold.value = -1.5; limiter.knee.value = 0; limiter.ratio.value = 20;
  limiter.attack.value = 0.002; limiter.release.value = 0.12;

  masterGain.connect(mEqLow); mEqLow.connect(mEqMid); mEqMid.connect(mEqHigh);
  mEqHigh.connect(mComp); mComp.connect(limiter); limiter.connect(off.destination);

  const anySolo = state.tracks.some(t => t.soloed);
  const spb = 60 / state.bpm;

  // Kanal bazlı gain/panner/efekt düğümleri
  state.tracks.forEach(tr => {
    const audible = !tr.muted && (!anySolo || tr.soloed);
    if (!audible) return;

    const tInput = off.createGain();
    const tEqL = off.createBiquadFilter(); tEqL.type = 'lowshelf'; tEqL.frequency.value = 220;
    const tEqM = off.createBiquadFilter(); tEqM.type = 'peaking'; tEqM.frequency.value = 1600; tEqM.Q.value = 0.9;
    const tEqH = off.createBiquadFilter(); tEqH.type = 'highshelf'; tEqH.frequency.value = 5200;
    const tComp = off.createDynamicsCompressor();
    const tDry = off.createGain();
    const tPan = off.createStereoPanner ? off.createStereoPanner() : null;
    const tGain = off.createGain();
    tGain.gain.value = tr.volume;

    const eqOn = tr.fx.eq.on ? 1 : 0;
    tEqL.gain.value = tr.fx.eq.low * eqOn;
    tEqM.gain.value = tr.fx.eq.mid * eqOn;
    tEqH.gain.value = tr.fx.eq.high * eqOn;

    if (tr.fx.compressor.on) {
      tComp.threshold.value = tr.fx.compressor.threshold;
      tComp.ratio.value = tr.fx.compressor.ratio;
    } else { tComp.threshold.value = 0; tComp.ratio.value = 1; }

    tInput.connect(tEqL); tEqL.connect(tEqM); tEqM.connect(tEqH); tEqH.connect(tComp);
    tComp.connect(tDry); tDry.connect(tGain);

    // Delay
    if (tr.fx.delay.on) {
      const dly = off.createDelay(2.0);
      const fb = off.createGain();
      const wet = off.createGain();
      dly.delayTime.value = clamp(tr.fx.delay.time, 0.02, 1.8);
      fb.gain.value = clamp(tr.fx.delay.feedback / 100, 0, 0.85);
      wet.gain.value = tr.fx.delay.mix / 100;
      tComp.connect(dly); dly.connect(fb); fb.connect(dly); dly.connect(wet); wet.connect(tGain);
    }
    // Reverb
    if (tr.fx.reverb.on) {
      const conv = off.createConvolver();
      conv.buffer = makeOfflineImpulse(off, clamp(0.4 + (tr.fx.reverb.size/100)*3.6, .4, 4), 2.2);
      const wet = off.createGain();
      wet.gain.value = (tr.fx.reverb.mix / 100) * 0.9;
      tComp.connect(conv); conv.connect(wet); wet.connect(tGain);
    }
    if (tPan) {
      tPan.pan.value = clamp(tr.pan, -1, 1);
      tGain.connect(tPan); tPan.connect(masterGain);
    } else { tGain.connect(masterGain); }

    // Bölgeleri planla
    tr.regions.forEach(rg => {
      const t0 = rg.startBeat * spb;
      if (t0 >= seconds) return;

      if (rg.buffer) {
        const src = off.createBufferSource();
        src.buffer = rg.buffer;
        const g = off.createGain(); g.gain.value = rg.gain;
        const dur = Math.min(rg.buffer.duration, seconds - t0);
        // AutoPitch: mixdown/dışa aktarmada da canlı çalmayla aynı perde
        // düzeltmesi uygulanır (önceden burada eksikti).
        if (tr.fx.autopitch.on) {
          applyAutopitchDetune(off, src, tr, t0, dur, rg);
        }
        src.connect(g); g.connect(tInput);
        if (dur > 0.01) {
          try { src.start(t0, 0, dur); } catch (e) {}
        }
      } else if (rg.drumNotes && rg.drumNotes.length) {
        rg.drumNotes.forEach(dn => {
          const at = (rg.startBeat + dn.beat) * spb;
          if (at >= seconds) return;
          synthDrumOffline(off, tInput, dn.drum, at, rg.gain || 1);
        });
      } else if (rg.notes && rg.notes.length) {
        rg.notes.forEach(nt => {
          const at = (rg.startBeat + nt.beat) * spb;
          if (at >= seconds) return;
          synthNoteOffline(off, tInput, tr, nt.note, at, Math.min(nt.dur * spb, seconds - at), (rg.gain || 1) * 0.9);
        });
      }
    });
  });

  const renderedBuffer = await off.startRendering();
  const ch0 = Array.from(renderedBuffer.getChannelData(0));
  return { buffers: [ch0], sampleRate: rate };
}

function makeOfflineImpulse(ctx, seconds, decay) {
  const rate = ctx.sampleRate;
  const len = Math.max(1, Math.floor(rate * seconds));
  const buf = ctx.createBuffer(2, len, rate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
  }
  return buf;
}

function synthNoteOffline(off, dest, tr, midi, at, dur, amp) {
  if (dur <= 0) return;
  const osc = off.createOscillator();
  const g = off.createGain();
  osc.type = (tr.instrument === 'bass') ? 'sine'
    : (tr.instrument === 'synth') ? 'sawtooth'
    : (tr.instrument === 'guitar') ? 'sawtooth' : 'sine';
  osc.frequency.value = 440 * Math.pow(2, (midi - 69) / 12);
  if (tr && tr.fx && tr.fx.autopitch && tr.fx.autopitch.on) {
    applyAutopitchDetune(off, osc, tr, at, dur, null);
  }
  const rel = Math.max(0.02, Math.min(0.25, dur * 0.5));
  g.gain.setValueAtTime(0, at);
  g.gain.linearRampToValueAtTime(amp, at + 0.008);
  g.gain.setValueAtTime(amp, Math.max(at + 0.008, at + dur - rel));
  g.gain.linearRampToValueAtTime(0, at + dur + 0.02);
  osc.connect(g); g.connect(dest);
  osc.start(at); osc.stop(at + dur + 0.05);
}

function synthDrumOffline(off, dest, type, at, amp) {
  if (type === 'kick') {
    const osc = off.createOscillator();
    const g = off.createGain();
    osc.frequency.setValueAtTime(140, at);
    osc.frequency.exponentialRampToValueAtTime(45, at + 0.13);
    g.gain.setValueAtTime(amp * 1.1, at);
    g.gain.exponentialRampToValueAtTime(0.001, at + 0.34);
    osc.connect(g); g.connect(dest);
    osc.start(at); osc.stop(at + 0.36);
    return;
  }
  const len = type === 'hat_open' ? 0.34 : (type === 'clap' ? 0.22 : 0.20);
  const rate = off.sampleRate;
  const nlen = Math.max(1, Math.floor(rate * len));
  const nbuf = off.createBuffer(1, nlen, rate);
  const nd = nbuf.getChannelData(0);
  for (let i = 0; i < nlen; i++) nd[i] = Math.random() * 2 - 1;
  const src = off.createBufferSource(); src.buffer = nbuf;
  const f = off.createBiquadFilter();
  if (type === 'snare' || type === 'clap') { f.type = 'bandpass'; f.frequency.value = 1900; }
  else if (type === 'hat_closed' || type === 'hat_open') { f.type = 'highpass'; f.frequency.value = 7800; }
  else { f.type = 'bandpass'; f.frequency.value = 420; }
  const g = off.createGain();
  const peak = (type === 'hat_closed' || type === 'hat_open') ? amp * 0.4 : amp * 0.8;
  g.gain.setValueAtTime(peak, at);
  g.gain.exponentialRampToValueAtTime(0.001, at + len);
  src.connect(f); f.connect(g); g.connect(dest);
  src.start(at); src.stop(at + len + 0.02);
}

/** Float örnekleri 16-bit PCM WAV olarak paketle. */
function encodeWav(channels, sampleRate) {
  const numCh = channels.length;
  const len = channels[0].length;
  const bytesPerSample = 2;
  const blockAlign = numCh * bytesPerSample;
  const dataSize = len * blockAlign;
  const buf = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buf);

  const ws = (off, s) => { for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i)); };
  ws(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  ws(8, 'WAVE');
  ws(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numCh, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  ws(36, 'data');
  view.setUint32(40, dataSize, true);

  let off = 44;
  for (let i = 0; i < len; i++) {
    for (let c = 0; c < numCh; c++) {
      let s = channels[c][i];
      s = s < -1 ? -1 : s > 1 ? 1 : s;
      view.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
      off += 2;
    }
  }
  return new Blob([buf], { type: 'audio/wav' });
}

/* ============================================================
   PİYANO NOTALARINI KANALA YAZ
   ============================================================ */
function writePianoToTrack() {
  if (!pianoNotes.length) {
    showToast('Önce piyanoda bir şeyler çalın (notalar kaydedilmeli).', 'info');
    return;
  }
  let tr = selectedTrack();
  if (!tr) { tr = addTrack({ type: 'keys' }, true); renderTracks(); renderMixer(); }
  if (!tr) return;

  const maxBeat = pianoNotes.reduce((m, n) => Math.max(m, n.beat + n.dur), 0);
  tr.regions.push({
    id: newId('rgn'),
    name: 'Piyano (' + pianoNotes.length + ' nota)',
    startBeat: snapBeat(state.playheadBeat),
    lengthBeats: Math.max(2, Math.ceil(maxBeat)),
    color: tr.color,
    blobUrl: null,
    buffer: null,
    sourceKind: 'synth',
    gain: 0.95,
    notes: pianoNotes.map(n => ({ beat: n.beat, dur: n.dur, note: n.note }))
  });
  markUnsaved();
  renderTracks();
  updateInfoBar();
  showToast(pianoNotes.length + ' nota kanala yazıldı: <b>' + esc(tr.name) + '</b>', 'ok');
}

function clearPianoNotes() {
  if (!pianoNotes.length) { showToast('Temizlenecek nota yok.', 'info'); return; }
  pianoNotes = [];
  showToast('Piyano notaları temizlendi.', 'info');
}

/* ============================================================
   TRANSPORT UI SENKRONU
   ============================================================ */
function syncTransportUI() {
  $('bpmInput').value = state.bpm;
  $('timeSig').value = state.timeSig;
  $('keySelect').value = state.key;
  $('snapSelect').value = String(state.snap);
  $('projectTitle').value = state.title;
  $('btnMetronome').classList.toggle('on', state.metronome);
  $('btnLoop').classList.toggle('on', state.loopEnabled);
  $('masterGain').value = Math.round(state.masterGain * 100);
  $('masterWidth').value = Math.round(state.masterWidth * 100);
  $('masterGainLbl').textContent = Math.round(state.masterGain * 100) + '%';
  $('masterWidthLbl').textContent = Math.round(state.masterWidth * 100) + '%';
  $('masterPreset').value = state.masterPreset;
  $('masterPresetLbl').textContent = state.masterPreset.toUpperCase();
  $('dmPattern').value = 'boom_bap';
}

/* ============================================================
   OLAY BAĞLAMA (EVENT WIRING)
   ============================================================ */
function setTool(tool) {
  $$('.rail-btn[data-tool]').forEach(b => b.classList.toggle('active', b.dataset.tool === tool));
  document.body.dataset.tool = tool;
}

function openDock(tab) {
  const dock = $('bottomDock');
  dock.classList.remove('collapsed');
  $('dockToggle').innerHTML = '<i class="bi bi-chevron-down"></i>';
  $$('.dock-tab[data-dock]').forEach(b => b.classList.toggle('active', b.dataset.dock === tab));
  $$('.dock-pane').forEach(p => p.classList.toggle('active', p.id === 'pane-' + tab));
  if (tab === 'fx') renderFxPane();
  if (tab === 'mixer') renderMixer();
  if (tab === 'split') refreshSplitSources();
  if (tab === 'loops' && !state.loops.length) loadLoops();
}

function wireEvents() {

  /* --- Transport --- */
  $('btnPlay').addEventListener('click', togglePlay);
  $('btnStop').addEventListener('click', () => {
    if (state.isRecording) stopRecording();
    stopAll();
  });
  $('btnRewind').addEventListener('click', () => seekToBeat(0));
  $('btnRec').addEventListener('click', () => {
    if (state.isRecording) stopRecording(); else startRecording();
  });
  $('btnMetronome').addEventListener('click', () => {
    state.metronome = !state.metronome;
    $('btnMetronome').classList.toggle('on', state.metronome);
    if (state.metronome && state.isPlaying) startMetronome(); else stopMetronome();
    showToast('Metronom ' + (state.metronome ? 'açık' : 'kapalı'), 'info', 1600);
    markUnsaved();
  });
  $('btnLoop').addEventListener('click', () => {
    state.loopEnabled = !state.loopEnabled;
    $('btnLoop').classList.toggle('on', state.loopEnabled);
    if (state.loopEnabled && state.loopEnd <= state.loopStart) {
      // Varsayılan: 4 bar
      state.loopStart = 0;
      state.loopEnd = beatsPerBar() * 4;
    }
    renderRuler();
    showToast('Döngü ' + (state.loopEnabled ? 'açık' : 'kapalı'), 'info', 1600);
    markUnsaved();
  });

  /* --- Proje parametreleri --- */
  $('bpmInput').addEventListener('change', () => {
    state.bpm = clampInt($('bpmInput'), 30, 300, 120);
    if (state.isPlaying) { seekToBeat(currentBeat()); }
    updateInfoBar(); markUnsaved();
    showToast('Tempo: <b>' + state.bpm + ' BPM</b>', 'info', 1500);
  });
  $('timeSig').addEventListener('change', () => {
    state.timeSig = $('timeSig').value;
    renderRuler(); renderTracks(); markUnsaved();
  });
  $('keySelect').addEventListener('change', () => {
    state.key = $('keySelect').value; markUnsaved();
    showToast('Ton: <b>' + state.key + '</b>', 'info', 1500);
  });
  $('snapSelect').addEventListener('change', () => {
    state.snap = parseFloat($('snapSelect').value); markUnsaved();
  });
  $('projectTitle').addEventListener('input', () => {
    state.title = $('projectTitle').value || 'Yeni Proje';
    document.title = state.title + ' — Kuduko Ses Kayıt Stüdyosu';
    markUnsaved();
  });

  /* --- Üst eylemler --- */
  $('btnProjects').addEventListener('click', openProjectsModal);
  $('btnSave').addEventListener('click', () => saveProject(false));
  $('btnHelp').addEventListener('click', () => new bootstrap.Modal($('helpModal')).show());
  $('btnBack').addEventListener('click', () => {
    if (!state.saved && !confirm('Kaydedilmemiş değişiklikler var. Yine de çıkmak istiyor musunuz?')) return;
    window.open('./', '_self');
  });
  $('btnExport').addEventListener('click', () => {
    $('exportTitle').value = state.title;
    // Önerilen süre: en uzun bölgeye göre
    const maxBeat = state.tracks.reduce((m, t) => t.regions.reduce((mm, r) => Math.max(mm, r.startBeat + r.lengthBeats), m), 0);
    $('exportDuration').value = maxBeat > 0 ? Math.min(600, Math.max(5, Math.ceil(beatToSec(maxBeat)) + 1)) : 30;
    $('doExportBtn').disabled = false;
    $('doExportBtn').innerHTML = '<i class="bi bi-play-fill"></i> Mixdown Başlat';
    new bootstrap.Modal($('exportModal')).show();
  });
  $('doExportBtn').addEventListener('click', doExport);

  /* --- Zoom --- */
  $('zoomIn').addEventListener('click', () => { setZoom(state.pxPerBeat * 1.35); });
  $('zoomOut').addEventListener('click', () => { setZoom(state.pxPerBeat / 1.35); });
  $('railZoomFit').addEventListener('click', fitZoom);

  /* --- Araçlar --- */
  $$('.rail-btn[data-tool]').forEach(b => {
    b.addEventListener('click', () => setTool(b.dataset.tool));
  });
  $('railAddTrack').addEventListener('click', showAddTrackMenu);
  $('railLoops').addEventListener('click', () => openDock('loops'));
  $('railInstr').addEventListener('click', () => openDock('instruments'));
  $('railMixer').addEventListener('click', () => openDock('mixer'));
  $('railFx').addEventListener('click', () => openDock('fx'));
  $('railSplit').addEventListener('click', () => openDock('split'));
  $('railMaster').addEventListener('click', () => openDock('master'));
  $('railImport').addEventListener('click', () => $('importAudioInput').click());

  /* --- Alt panel sekmeleri --- */
  $$('.dock-tab[data-dock]').forEach(b => {
    b.addEventListener('click', () => openDock(b.dataset.dock));
  });
  $('dockToggle').addEventListener('click', () => {
    const dock = $('bottomDock');
    const collapsed = dock.classList.toggle('collapsed');
    $('dockToggle').innerHTML = collapsed ? '<i class="bi bi-chevron-up"></i>' : '<i class="bi bi-chevron-down"></i>';
  });

  /* --- Kanallar alanı: olay delegasyonu --- */
  $('tracksArea').addEventListener('click', onTracksAreaClick);
  $('tracksArea').addEventListener('input', onTracksAreaInput);
  $('tracksArea').addEventListener('dblclick', onTracksAreaDblClick);
  $('tracksArea').addEventListener('mousedown', onRegionMouseDown);
  $('tracksArea').addEventListener('contextmenu', onTracksAreaContext);

  /* --- Mikser delegasyonu --- */
  $('mixerStrips').addEventListener('input', onMixerInput);
  $('mixerStrips').addEventListener('click', onMixerClick);

  /* --- Cetvel: tıklayarak konum --- */
  $('ruler').addEventListener('click', (e) => {
    const rect = $('ruler').getBoundingClientRect();
    const px = e.clientX - rect.left + $('tlScroll').scrollLeft;
    seekToBeat(snapBeat(pxToBeat(px)));
  });

  /* --- Cetvel: kaydırarak loop seçimi (Alt basılı) --- */
  $('ruler').addEventListener('mousedown', (e) => {
    if (!e.altKey && !e.shiftKey) return;
    e.preventDefault();
    const scroll = $('tlScroll');
    const r0 = $('ruler').getBoundingClientRect();
    const startBeat = snapBeat(pxToBeat(e.clientX - r0.left + scroll.scrollLeft));
    const move = (ev) => {
      const b = snapBeat(pxToBeat(ev.clientX - r0.left + scroll.scrollLeft));
      state.loopStart = Math.min(startBeat, b);
      state.loopEnd = Math.max(startBeat, b);
      state.loopEnabled = true;
      $('btnLoop').classList.add('on');
      renderRuler();
    };
    const up = () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
      if (state.loopEnd - state.loopStart < 0.25) { state.loopEnabled = false; $('btnLoop').classList.remove('on'); }
      renderRuler(); markUnsaved();
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
  });

  /* --- Loop kütüphanesi --- */
  $('loopsGrid').addEventListener('click', (e) => {
    const playBtn = e.target.closest('[data-loop-play]');
    if (playBtn) { e.stopPropagation(); previewLoop(playBtn.dataset.loopPlay); return; }
    const addBtn = e.target.closest('[data-loop-add]');
    if (addBtn) { e.stopPropagation(); addLoopToTrack(addBtn.dataset.loopAdd); return; }
    const card = e.target.closest('.loop-card');
    if (card) previewLoop(card.dataset.loopId);
  });
  $$('.chip[data-loopcat]').forEach(c => {
    c.addEventListener('click', () => {
      state.activeLoopCat = c.dataset.loopcat;
      $$('.chip[data-loopcat]').forEach(x => x.classList.toggle('active', x === c));
      renderLoops();
    });
  });
  $('loopSearch').addEventListener('input', renderLoops);

  /* --- Piyano --- */
  $('octaveRange').addEventListener('input', () => {
    $('octaveLbl').textContent = 'C' + $('octaveRange').value;
    buildPiano();
  });
  $('pianoWave').addEventListener('change', () => {
    const map = { sine: 'SİNÜS', triangle: 'ÜÇGEN', square: 'KARE', saw: 'TESTERE' };
    $('pianoWaveLbl').textContent = map[$('pianoWave').value] || 'SİNÜS';
  });
  $('pianoToTrack').addEventListener('click', writePianoToTrack);
  $('pianoClear').addEventListener('click', clearPianoNotes);

  /* --- Davul makinesi --- */
  $('drumSeq').addEventListener('click', (e) => {
    const st = e.target.closest('.dm-step');
    if (!st) return;
    toggleDrumStep(parseInt(st.dataset.row, 10), parseInt(st.dataset.step, 10));
  });
  $('dmPattern').addEventListener('change', () => {
    initDrumPattern($('dmPattern').value);
    markUnsaved();
    const map = { boom_bap:'BOOM BAP', trap:'TRAP', four_floor:'FOUR ON THE FLOOR', rock:'ROCK', perc:'PERCUSSION', empty:'BOŞ' };
    $('dmPatternLbl').textContent = map[$('dmPattern').value] || 'BOOM BAP';
  });
  $('dmClear').addEventListener('click', () => { initDrumPattern('empty'); $('dmPattern').value = 'empty'; $('dmPatternLbl').textContent = 'BOŞ'; markUnsaved(); });
  $('dmRandom').addEventListener('click', () => {
    const presets = ['boom_bap', 'trap', 'four_floor', 'rock', 'perc'];
    const p = presets[Math.floor(Math.random() * presets.length)];
    $('dmPattern').value = p;
    initDrumPattern(p);
    const map = { boom_bap:'BOOM BAP', trap:'TRAP', four_floor:'FOUR ON THE FLOOR', rock:'ROCK', perc:'PERCUSSION' };
    $('dmPatternLbl').textContent = map[p];
    markUnsaved();
    showToast('Rastgele desen: <b>' + map[p] + '</b>', 'info');
  });
  $('dmToTrack').addEventListener('click', writeDrumsToTrack);

  /* --- Mastering --- */
  $('masterPreset').addEventListener('change', () => {
    applyMasterPreset($('masterPreset').value);
    showToast('Mastering ayarı: <b>' + $('masterPresetLbl').textContent + '</b>', 'ok', 2000);
  });
  $('masterGain').addEventListener('input', () => {
    state.masterGain = parseInt($('masterGain').value, 10) / 100;
    $('masterGainLbl').textContent = $('masterGain').value + '%';
    if (AE.masterGain) AE.masterGain.gain.value = state.masterGain;
    markUnsaved();
  });
  $('masterWidth').addEventListener('input', () => {
    state.masterWidth = parseInt($('masterWidth').value, 10) / 100;
    $('masterWidthLbl').textContent = $('masterWidth').value + '%';
    markUnsaved();
  });

  /* --- Projeler modalı --- */
  $('projectsList').addEventListener('click', (e) => {
    const open = e.target.closest('[data-popen]');
    if (open) { loadProject(open.dataset.popen); return; }
    const del = e.target.closest('[data-pdel]');
    if (del) { deleteProject(del.dataset.pdel); return; }
  });
  $('newProjectBtn').addEventListener('click', newProject);

  /* --- Dosya içe aktarma --- */
  $('importAudioInput').addEventListener('change', onImportFiles);

  /* --- Sürükle-bırak --- */
  const tracksArea = $('tracksArea');
  tracksArea.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
  tracksArea.addEventListener('drop', (e) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length) {
      handleImportedFiles(e.dataTransfer.files);
    }
  });

  /* --- Klavye kısayolları --- */
  document.addEventListener('keydown', onGlobalKeyDown);
  document.addEventListener('keyup', onGlobalKeyUp);

  /* --- Pencere olayları --- */
  window.addEventListener('beforeunload', (e) => {
    if (!state.saved && state.tracks.length) {
      e.preventDefault();
      e.returnValue = '';
      return '';
    }
  });
  window.addEventListener('resize', debounce(() => { renderTracks(); renderRuler(); }, 180));

  /* --- Kaydırma sırasında cetveli hizala --- */
  const sc = $('tlScroll');
  sc.addEventListener('scroll', () => {
    const ruler = $('ruler');
    if (ruler) ruler.style.transform = '';
  });

  /* --- Ses ayırıcı (vokal / enstrüman) --- */
  $('splitVocal').addEventListener('input', () => {
    $('splitVocalLbl').textContent = $('splitVocal').value + '%';
  });
  $('splitInst').addEventListener('input', () => {
    $('splitInstLbl').textContent = $('splitInst').value + '%';
  });
  $('splitQuality').addEventListener('change', () => {
    const map = { fast: 'HIZLI', balanced: 'DENGELİ', best: 'YÜKSEK KALİTE' };
    $('splitQualityLbl').textContent = map[$('splitQuality').value] || 'DENGELİ';
  });
  $('splitSource').addEventListener('change', () => {
    const m = splitSourceMeta($('splitSource').value);
    $('splitSrcLbl').textContent = m ? m.label.toUpperCase() : 'SEÇİLMEDİ';
  });
  $('splitRunBtn').addEventListener('click', runSeparation);
  $('splitPreviewVocal').addEventListener('click', () => previewStem('vocal'));
  $('splitPreviewInst').addEventListener('click', () => previewStem('inst'));
  $('splitStopBtn').addEventListener('click', () => { stopStemPreview(); showToast('Dinleme durduruldu.', 'info', 1500); });
}

function debounce(fn, ms) {
  let t;
  return function () { clearTimeout(t); t = setTimeout(() => fn.apply(this, arguments), ms); };
}

/* ============================================================
   ZOOM
   ============================================================ */
function setZoom(px) {
  state.pxPerBeat = clamp(px, 8, 320);
  renderRuler();
  renderTracks();
  positionPlayhead();
}

function fitZoom() {
  const totalBeats = projectBeats();
  const scroll = $('tlScroll');
  if (!scroll) return;
  const avail = scroll.clientWidth - trackHeadW() - 30;
  if (avail <= 0 || totalBeats <= 0) return;
  setZoom(clamp(avail / totalBeats, 8, 320));
  showToast('Görünüm sığdırıldı.', 'info', 1500);
}

/* ============================================================
   KANAL EKLEME MENÜSÜ
   ============================================================ */
function showAddTrackMenu() {
  // Basit seçim modalı (bootstrap olmadan, hızlı)
  const existing = $('addTrackSheet');
  if (existing) existing.remove();

  const sheet = document.createElement('div');
  sheet.id = 'addTrackSheet';
  sheet.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:1080;display:flex;align-items:center;justify-content:center;padding:1rem;backdrop-filter:blur(6px)';
  sheet.innerHTML = `
    <div style="background:#0a0a0a;border:1px solid var(--line-2);border-radius:18px;padding:1.2rem;max-width:520px;width:100%;box-shadow:var(--shadow)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.9rem">
        <b style="font-size:.95rem"><i class="bi bi-plus-circle text-danger me-2"></i>Yeni Kanal Ekle</b>
        <button class="mini-btn" data-close style="width:28px;height:26px"><i class="bi bi-x-lg"></i></button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:.5rem">
        ${TRACK_TYPES.map(t => `
          <button class="ibtn" data-newtrack="${t.id}" style="height:52px;justify-content:flex-start;gap:.5rem;padding:0 .7rem;border-color:${t.color}44">
            <i class="bi ${t.icon}" style="color:${t.color};font-size:1.1rem"></i>
            <span style="text-align:left;line-height:1.2">${t.label}</span>
          </button>`).join('')}
      </div>
    </div>`;

  sheet.addEventListener('click', (e) => {
    if (e.target === sheet || e.target.closest('[data-close]')) { sheet.remove(); return; }
    const b = e.target.closest('[data-newtrack]');
    if (b) {
      const type = b.dataset.newtrack;
      sheet.remove();
      addTrack({ type });
      // Yeni kanalı görünür yap
      setTimeout(() => {
        const sc = $('tlScroll');
        if (sc) sc.scrollTop = sc.scrollHeight;
      }, 60);
    }
  });

  document.body.appendChild(sheet);
}

/* ============================================================
   KANAL ALANI OLAYLARI
   ============================================================ */
function onTracksAreaClick(e) {
  const row = e.target.closest('.track-row');
  if (row) {
    const tid = row.dataset.trackId;
    if (state.selectedTrackId !== tid) {
      state.selectedTrackId = tid;
      $$('.track-row').forEach(r => r.classList.toggle('selected', r.dataset.trackId === tid));
      renderMixer();
      // FX paneli açıksa yenile
      if ($('pane-fx').classList.contains('active')) renderFxPane();
    }
  }

  // Bölge silme
  const regDel = e.target.closest('[data-regdel]');
  if (regDel) {
    e.stopPropagation();
    const el = regDel.closest('.region');
    deleteRegion(el.dataset.trackId, el.dataset.regionId);
    return;
  }

  const flagBtn = e.target.closest('[data-flag]');
  if (flagBtn) {
    e.stopPropagation();
    const tr = getTrack(row ? row.dataset.trackId : null);
    if (!tr) return;
    const f = flagBtn.dataset.flag;
    if (f === 'armed') {
      // Sadece bir kanal aynı anda kayda hazır olabilir
      state.tracks.forEach(t => { t.armed = false; });
      tr.armed = true;
      showToast(`<b>${esc(tr.name)}</b> kayda hazır. Kayıt butonuna basın.`, 'info', 2600);
      ensureMic();
    } else {
      tr[f] = !tr[f];
      if (f === 'soloed') refreshAllLevels();
      else applyTrackLevels(tr);
    }
    renderTracks(); renderMixer(); markUnsaved();
    return;
  }

  const openFx = e.target.closest('[data-openfx]');
  if (openFx) {
    e.stopPropagation();
    state.selectedTrackId = row.dataset.trackId;
    $$('.track-row').forEach(r => r.classList.toggle('selected', r.dataset.trackId === state.selectedTrackId));
    openDock('fx');
    $('fxModalTrackName').textContent = getTrack(state.selectedTrackId).name;
    return;
  }

  const delBtn = e.target.closest('[data-del]');
  if (delBtn) {
    e.stopPropagation();
    const tr = getTrack(row.dataset.trackId);
    if (tr && confirm(`"${tr.name}" kanalını silmek istediğinize emin misiniz?`)) removeTrack(tr.id);
    return;
  }
}

function onTracksAreaInput(e) {
  const row = e.target.closest('.track-row');
  if (!row) return;
  const tr = getTrack(row.dataset.trackId);
  if (!tr) return;

  if (e.target.matches('[data-vol]')) {
    tr.volume = parseInt(e.target.value, 10) / 100;
    const lab = e.target.closest('.th-slider').querySelector('label span');
    if (lab) lab.textContent = e.target.value + '%';
    applyTrackLevels(tr);
    markUnsaved();
  } else if (e.target.matches('[data-pan]')) {
    tr.pan = parseInt(e.target.value, 10) / 100;
    const lab = e.target.closest('.th-slider').querySelector('label span');
    const v = parseInt(e.target.value, 10);
    if (lab) lab.textContent = v === 0 ? 'C' : (v > 0 ? 'R' + v : 'L' + Math.abs(v));
    applyTrackLevels(tr);
    markUnsaved();
  } else if (e.target.matches('[data-rename]')) {
    tr.name = e.target.value.slice(0, 48) || tr.typeLabel;
    renderMixer();
    markUnsaved();
  }
}

function onTracksAreaDblClick(e) {
  const lane = e.target.closest('.track-lane');
  if (!lane) return;
  const tr = getTrack(lane.dataset.trackId);
  if (!tr) return;

  // Boş alana çift tıklama: hazırla + kaydı başlat
  const rect = lane.getBoundingClientRect();
  const px = e.clientX - rect.left;
  seekToBeat(snapBeat(pxToBeat(px)));
  state.selectedTrackId = tr.id;
  state.tracks.forEach(t => { t.armed = false; });
  tr.armed = true;
  renderTracks();
  if (!state.isRecording) startRecording();
}

function onTracksAreaContext(e) {
  const region = e.target.closest('.region');
  if (!region) return;
  e.preventDefault();
  const tr = getTrack(region.dataset.trackId);
  if (!tr) return;
  const rg = tr.regions.find(r => r.id === region.dataset.regionId);
  if (!rg) return;

  const menu = document.createElement('div');
  menu.style.cssText = `position:fixed;left:${e.clientX}px;top:${e.clientY}px;background:var(--panel-2);border:1px solid var(--line-2);border-radius:10px;padding:.3rem;z-index:1090;min-width:190px;box-shadow:var(--shadow)`;
  menu.innerHTML = `
    <button class="context-item" data-ract="rename" style="display:flex;gap:.5rem;align-items:center;width:100%;padding:.45rem .6rem;border:none;background:transparent;color:var(--tx);font-size:.78rem;border-radius:7px;cursor:pointer;text-align:left"><i class="bi bi-pencil"></i> Yeniden Adlandır</button>
    <button class="context-item" data-ract="dup" style="display:flex;gap:.5rem;align-items:center;width:100%;padding:.45rem .6rem;border:none;background:transparent;color:var(--tx);font-size:.78rem;border-radius:7px;cursor:pointer;text-align:left"><i class="bi bi-files"></i> Çoğalt</button>
    <button class="context-item" data-ract="toStart" style="display:flex;gap:.5rem;align-items:center;width:100%;padding:.45rem .6rem;border:none;background:transparent;color:var(--tx);font-size:.78rem;border-radius:7px;cursor:pointer;text-align:left"><i class="bi bi-align-start"></i> Oynatıcıya Taşı</button>
    <hr style="border-color:var(--line);margin:.25rem 0">
    <button class="context-item" data-ract="del" style="display:flex;gap:.5rem;align-items:center;width:100%;padding:.45rem .6rem;border:none;background:transparent;color:#ffffff;font-size:.78rem;border-radius:7px;cursor:pointer;text-align:left"><i class="bi bi-trash3"></i> Bölgeyi Sil</button>`;

  menu.addEventListener('mouseover', ev => {
    const b = ev.target.closest('.context-item');
    if (b) b.style.background = 'rgba(148,163,184,.16)';
  });
  menu.addEventListener('mouseout', ev => {
    const b = ev.target.closest('.context-item');
    if (b) b.style.background = 'transparent';
  });
  menu.addEventListener('click', (ev) => {
    const b = ev.target.closest('[data-ract]');
    if (!b) return;
    const act = b.dataset.ract;
    menu.remove();
    if (act === 'del') deleteRegion(tr.id, rg.id);
    else if (act === 'dup') {
      const copy = Object.assign({}, rg, { id: newId('rgn'), startBeat: rg.startBeat + rg.lengthBeats, name: rg.name + ' (Kopya)' });
      tr.regions.push(copy);
      renderTracks(); markUnsaved();
      showToast('Bölge çoğaltıldı.', 'ok', 1800);
    } else if (act === 'toStart') {
      rg.startBeat = snapBeat(state.playheadBeat);
      renderTracks(); markUnsaved();
    } else if (act === 'rename') {
      const nn = prompt('Yeni bölge adı:', rg.name);
      if (nn != null && nn.trim()) { rg.name = nn.trim().slice(0, 60); renderTracks(); markUnsaved(); }
    }
  });

  document.body.appendChild(menu);
  setTimeout(() => {
    const close = (ev) => {
      if (!menu.contains(ev.target)) { menu.remove(); document.removeEventListener('mousedown', close); }
    };
    document.addEventListener('mousedown', close);
  }, 10);
}

function deleteRegion(trackId, regionId) {
  const tr = getTrack(trackId);
  if (!tr) return;
  const i = tr.regions.findIndex(r => r.id === regionId);
  if (i < 0) return;
  if (tr.regions[i].blobUrl) URL.revokeObjectURL(tr.regions[i].blobUrl);
  tr.regions.splice(i, 1);
  renderTracks(); updateInfoBar(); markUnsaved();
  if (state.isPlaying) scheduleAll(currentBeat());
}

/* --- Bölge sürükleme --- */
function onRegionMouseDown(e) {
  const region = e.target.closest('.region');
  if (!region) return;
  if (e.target.closest('[data-regdel]')) return;
  if (e.button !== 0) return;

  const tool = document.body.dataset.tool || 'pointer';
  const tr = getTrack(region.dataset.trackId);
  if (!tr) return;
  const rg = tr.regions.find(r => r.id === region.dataset.regionId);
  if (!rg) return;

  // Seçim araçlarından bağımsız: kenar tutamaçları resize başlatır
  const resizeEl = e.target.closest('[data-regresize]');

  // Bölme aracı
  if (!resizeEl && tool === 'cut') {
    e.preventDefault();
    const lane = region.closest('.track-lane');
    const lr = lane.getBoundingClientRect();
    const cutBeat = snapBeat(pxToBeat(e.clientX - lr.left));
    splitRegion(tr, rg, cutBeat);
    return;
  }

  // Silme aracı
  if (!resizeEl && tool === 'erase') {
    e.preventDefault();
    deleteRegion(tr.id, rg.id);
    return;
  }

  e.preventDefault();

  state.selectedTrackId = tr.id;
  $$('.track-row').forEach(r => r.classList.toggle('selected', r.dataset.trackId === tr.id));

  if (resizeEl) {
    beginRegionResize(e, region, tr, rg, resizeEl.dataset.regresize);
  } else {
    beginRegionMove(e, region, tr, rg);
  }
}

/* --- Bölge taşıma (yatay + dikey kanal değiştirme) --- */
function beginRegionMove(e, region, tr, rg) {
  region.classList.add('dragging');
  const startX = e.clientX;
  const origStart = rg.startBeat;
  let currentTrack = tr;
  let hoverRow = null;

  const clearHover = () => {
    if (hoverRow) { hoverRow.classList.remove('drop-target'); hoverRow = null; }
  };

  const move = (ev) => {
    const dx = ev.clientX - startX;
    rg.startBeat = Math.max(0, snapBeat(origStart + pxToBeat(dx)));
    region.style.left = beatToPx(rg.startBeat) + 'px';

    // Dikey sürükleme: hedef kanalı bul
    const target = trackAtPoint(ev.clientX, ev.clientY);
    if (target && target.tr.id !== currentTrack.id) {
      if (!hoverRow || hoverRow.dataset.trackId !== target.tr.id) {
        clearHover();
        hoverRow = target.row;
        hoverRow.classList.add('drop-target');
      }
    } else {
      clearHover();
    }
  };

  const up = (ev) => {
    document.removeEventListener('mousemove', move);
    document.removeEventListener('mouseup', up);
    region.classList.remove('dragging');
    clearHover();

    // Kanal değiştir (bırakılan kanala taşı)
    const target = trackAtPoint(ev.clientX, ev.clientY);
    if (target && target.tr.id !== currentTrack.id) {
      moveRegionToTrack(currentTrack, target.tr, rg);
    } else {
      renderTracks();
    }
    markUnsaved();
    if (state.isPlaying) scheduleAll(currentBeat());
  };

  document.addEventListener('mousemove', move);
  document.addEventListener('mouseup', up);
}

/* --- Bölge kenardan boyutlandırma --- */
function beginRegionResize(e, region, tr, rg, side) {
  region.classList.add('resizing');
  const startX = e.clientX;
  const origStart = rg.startBeat;
  const origLen = rg.lengthBeats;

  const move = (ev) => {
    const dxBeats = pxToBeat(ev.clientX - startX);
    if (side === 'right') {
      const newLen = Math.max(0.25, snapBeatLength(origLen + dxBeats));
      rg.lengthBeats = newLen;
      region.style.width = Math.max(10, beatToPx(newLen)) + 'px';
    } else {
      const right = origStart + origLen;
      let newStart = snapBeat(origStart + dxBeats);
      newStart = clamp(newStart, 0, right - 0.25);
      rg.startBeat = newStart;
      rg.lengthBeats = right - newStart;
      region.style.left = beatToPx(rg.startBeat) + 'px';
      region.style.width = Math.max(10, beatToPx(rg.lengthBeats)) + 'px';
    }
    const cv = region.querySelector('canvas');
    if (cv) drawRegionWave(cv, rg, tr);
  };

  const up = () => {
    document.removeEventListener('mousemove', move);
    document.removeEventListener('mouseup', up);
    region.classList.remove('resizing');
    renderTracks();
    updateInfoBar();
    markUnsaved();
    if (state.isPlaying) scheduleAll(currentBeat());
  };

  document.addEventListener('mousemove', move);
  document.addEventListener('mouseup', up);
}

/* Ekran noktasındaki kanalı bul (dikey sürükleme hedefi). */
function trackAtPoint(clientX, clientY) {
  const rows = $$('.track-row');
  for (const row of rows) {
    const r = row.getBoundingClientRect();
    if (clientY >= r.top && clientY <= r.bottom) {
      const tr = getTrack(row.dataset.trackId);
      if (tr) return { tr, row };
    }
  }
  return null;
}

/* Bölgeyi başka bir kanala taşı. */
function moveRegionToTrack(fromTr, toTr, rg) {
  const i = fromTr.regions.findIndex(r => r.id === rg.id);
  if (i < 0) return;
  fromTr.regions.splice(i, 1);
  // Hedef kanalın rengine uyum sağla
  rg.color = toTr.color;
  toTr.regions.push(rg);
  if (state.selectedTrackId === fromTr.id) state.selectedTrackId = toTr.id;
  renderTracks();
  renderMixer();
  updateInfoBar();
  showToast(`Bölge <b>${esc(toTr.name)}</b> kanalına taşındı.`, 'ok', 2000);
}

/* Uzunluğu ızgaraya yuvarla (en az bir adım). */
function snapBeatLength(len) {
  const s = state.snap;
  if (!s || s <= 0) return Math.max(0.25, len);
  return Math.max(s, Math.round(len / s) * s);
}

function splitRegion(tr, rg, atBeat) {
  if (atBeat <= rg.startBeat + 0.05 || atBeat >= rg.startBeat + rg.lengthBeats - 0.05) {
    showToast('Bölme noktası bölgenin içinde olmalı.', 'info', 2200);
    return;
  }
  const leftLen = atBeat - rg.startBeat;
  const rightLen = rg.lengthBeats - leftLen;

  const right = {
    id: newId('rgn'),
    name: rg.name + ' (2)',
    startBeat: atBeat,
    lengthBeats: rightLen,
    color: rg.color,
    blobUrl: null,
    buffer: rg.buffer,
    assetId: rg.assetId || null,
    sourceKind: rg.sourceKind,
    gain: rg.gain,
    notes: rg.notes || null,
    drumNotes: rg.drumNotes || null,
    _offsetSec: null
  };

  // Ses bölgesini gerçekten ikiye böl (yeni buffer oluştur)
  if (rg.buffer) {
    const spb = 60 / state.bpm;
    const offSec = leftLen * spb;
    const rightDurSec = rightLen * spb;
    const sr = rg.buffer.sampleRate;
    const startSample = Math.floor(offSec * sr);
    const lenSamples = Math.min(Math.floor(rightDurSec * sr), rg.buffer.length - startSample);

    if (lenSamples > 32) {
      const nb = AE.ctx.createBuffer(rg.buffer.numberOfChannels, lenSamples, sr);
      for (let c = 0; c < rg.buffer.numberOfChannels; c++) {
        const src = rg.buffer.getChannelData(c);
        const dst = nb.getChannelData(c);
        for (let i = 0; i < lenSamples; i++) dst[i] = src[startSample + i];
      }
      right.buffer = nb;
      right._pitchCorrectionCents = null;

      // Sol tarafı da kısalt
      const leftSamples = Math.max(32, startSample);
      const lb = AE.ctx.createBuffer(rg.buffer.numberOfChannels, leftSamples, sr);
      for (let c = 0; c < rg.buffer.numberOfChannels; c++) {
        const src = rg.buffer.getChannelData(c);
        const dst = lb.getChannelData(c);
        for (let i = 0; i < leftSamples; i++) dst[i] = src[i];
      }
      rg.buffer = lb;
      rg._pitchCorrectionCents = null;
    }
  }

  // Nota/davul bölgeleri için nota listelerini paylaştır
  if (rg.notes) {
    right.notes = rg.notes.filter(n => n.beat >= leftLen).map(n => Object.assign({}, n, { beat: n.beat - leftLen }));
    rg.notes = rg.notes.filter(n => n.beat < leftLen);
  }
  if (rg.drumNotes) {
    right.drumNotes = rg.drumNotes.filter(n => n.beat >= leftLen).map(n => Object.assign({}, n, { beat: n.beat - leftLen }));
    rg.drumNotes = rg.drumNotes.filter(n => n.beat < leftLen);
  }

  rg.lengthBeats = leftLen;
  tr.regions.push(right);
  renderTracks(); markUnsaved();
  showToast('Bölge ikiye ayrıldı.', 'ok', 1800);
}

/* ============================================================
   MİKSER OLAYLARI
   ============================================================ */
function onMixerInput(e) {
  const vol = e.target.closest('[data-mx-vol]');
  if (vol) {
    const tr = getTrack(vol.dataset.mxVol);
    if (!tr) return;
    tr.volume = parseInt(vol.value, 10) / 100;
    const db = vol.parentElement.querySelector('.ms-db');
    if (db) db.textContent = vol.value + '%';
    applyTrackLevels(tr);
    // Kanal başlığındaki slider'ı da güncelle
    const hs = document.querySelector(`.track-row[data-track-id="${tr.id}"] [data-vol]`);
    if (hs) { hs.value = vol.value; const l = hs.closest('.th-slider').querySelector('label span'); if (l) l.textContent = vol.value + '%'; }
    markUnsaved();
    return;
  }
  const pan = e.target.closest('[data-mx-pan]');
  if (pan) {
    const tr = getTrack(pan.dataset.mxPan);
    if (!tr) return;
    tr.pan = parseInt(pan.value, 10) / 100;
    applyTrackLevels(tr);
    markUnsaved();
    return;
  }
  if (e.target.id === 'mxMasterFader') {
    state.masterGain = parseInt(e.target.value, 10) / 100;
    const db = e.target.parentElement.querySelector('.ms-db');
    if (db) db.textContent = e.target.value + '%';
    if (AE.masterGain) AE.masterGain.gain.value = state.masterGain;
    $('masterGain').value = e.target.value;
    $('masterGainLbl').textContent = e.target.value + '%';
    markUnsaved();
  }
}

function onMixerClick(e) {
  const flag = e.target.closest('[data-mx-flag]');
  if (flag) {
    const tr = getTrack(flag.dataset.tid);
    if (!tr) return;
    tr[flag.dataset.mxFlag] = !tr[flag.dataset.mxFlag];
    if (flag.dataset.mxFlag === 'soloed') refreshAllLevels();
    else applyTrackLevels(tr);
    renderTracks(); renderMixer(); markUnsaved();
    return;
  }
  if (e.target.closest('#mxMasterMute')) {
    const cur = state.masterGain > 0;
    if (cur) {
      state._prevMaster = state.masterGain;
      state.masterGain = 0;
    } else {
      state.masterGain = state._prevMaster || 0.85;
    }
    if (AE.masterGain) AE.masterGain.gain.value = state.masterGain;
    $('mxMasterFader').value = Math.round(state.masterGain * 100);
    $('masterGain').value = Math.round(state.masterGain * 100);
    $('masterGainLbl').textContent = Math.round(state.masterGain * 100) + '%';
  }
}

/* ============================================================
   DOSYA İÇE AKTARMA
   ============================================================ */
function onImportFiles(e) {
  handleImportedFiles(e.target.files);
  e.target.value = '';
}

async function handleImportedFiles(fileList) {
  const files = Array.from(fileList || []).filter(f => f.type.startsWith('audio/') || /\.(mp3|wav|m4a|ogg|flac)$/i.test(f.name));
  if (!files.length) { showToast('Desteklenen ses dosyası bulunamadı.', 'err'); return; }
  await AE.init();
  if (!AE.ready) return;

  let added = 0;
  for (const f of files) {
    try {
      const ab = await f.arrayBuffer();
      const buf = await AE.ctx.decodeAudioData(ab.slice(0));
      let tr = selectedTrack();
      if (!tr) { tr = addTrack({ type: 'audio', name: 'Ses Dosyası' }, true); renderTracks(); renderMixer(); }
      addRegion(tr.id, {
        name: f.name.replace(/\.[^.]+$/, '').slice(0, 40),
        startBeat: snapBeat(state.playheadBeat),
        lengthBeats: Math.max(0.25, secToBeat(buf.duration)),
        color: tr.color,
        buffer: buf,
        sourceKind: 'audio',
        gain: 0.95
      });
      added++;
      // Sunucuya yükle (oturum varsa)
      if (state.user) uploadRecordedAsset(f, buf.duration, null);
    } catch (err) {
      console.warn('Çözülemedi:', f.name, err);
      showToast(`<b>${esc(f.name)}</b> çözülemedi (tarayıcı bu formatı desteklemiyor).`, 'err', 4500);
    }
  }
  if (added) {
    markUnsaved(); renderTracks(); updateInfoBar();
    showToast(added + ' ses dosyası içe aktarıldı.', 'ok');
  }
}

/* ============================================================
   KLAVYE KISAYOLLARI
   ============================================================ */
let pianoKeysDown = {};

function onGlobalKeyDown(e) {
  const tag = (e.target.tagName || '').toLowerCase();
  const typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;

  // Ctrl/Cmd kombinasyonları
  if (e.ctrlKey || e.metaKey) {
    const k = e.key.toLowerCase();
    if (k === 's') { e.preventDefault(); saveProject(false); return; }
    if (k === 'n' && e.shiftKey) { e.preventDefault(); showAddTrackMenu(); return; }
    if (k === '=' || k === '+') { e.preventDefault(); setZoom(state.pxPerBeat * 1.35); return; }
    if (k === '-') { e.preventDefault(); setZoom(state.pxPerBeat / 1.35); return; }
    return;
  }

  if (typing) return;

  const key = e.key.toLowerCase();

  if (key === ' ') { e.preventDefault(); togglePlay(); return; }
  if (key === 'r') {
    e.preventDefault();
    if (e.shiftKey) {
      // Shift+R: seçili kanalı kayda hazırla
      const tr = selectedTrack();
      if (tr) {
        state.tracks.forEach(t => { t.armed = false; });
        tr.armed = true;
        renderTracks();
        showToast(`<b>${esc(tr.name)}</b> kayda hazır.`, 'info', 2200);
        ensureMic();
      }
    } else {
      if (state.isRecording) stopRecording(); else startRecording();
    }
    return;
  }
  if (key === 'm') { $('btnMetronome').click(); return; }
  if (key === 'l') { $('btnLoop').click(); return; }
  if (key === 'home') { e.preventDefault(); seekToBeat(0); return; }
  if (key === 'delete' || key === 'backspace') {
    const tr = selectedTrack();
    if (tr && tr.regions.length) {
      // Son bölgeyi sil (playhead'den önce başlayan en yakın)
      const beat = currentBeat();
      let best = null;
      tr.regions.forEach(r => {
        if (r.startBeat <= beat && (!best || r.startBeat > best.startBeat)) best = r;
      });
      if (best) { e.preventDefault(); deleteRegion(tr.id, best.id); }
    }
    return;
  }

  // Piyano klavyesi
  if (KEYMAP[key] != null && !pianoKeysDown[key]) {
    pianoKeysDown[key] = true;
    const oct = parseInt($('octaveRange').value, 10) || 3;
    const midi = 12 * (oct + 1) + KEYMAP[key];
    pianoAttack(midi);
    // Görsel geri bildirim
    const el = document.querySelector(`#pianoKeys .pkey[data-midi="${midi}"]`);
    if (el) el.classList.add('on');
    pianoKeyDownAt[key] = { midi, t: performance.now() };
  }
}

let pianoKeyDownAt = {};

function onGlobalKeyUp(e) {
  const key = e.key.toLowerCase();
  if (KEYMAP[key] != null && pianoKeysDown[key]) {
    pianoKeysDown[key] = false;
    const info = pianoKeyDownAt[key];
    if (info) {
      pianoRecordNote(info.midi, info.t, performance.now());
      const el = document.querySelector(`#pianoKeys .pkey[data-midi="${info.midi}"]`);
      if (el) el.classList.remove('on');
      delete pianoKeyDownAt[key];
    }
  }
}

/* ============================================================
   SES AYIRICI — VOKAL / ENSTRÜMAN (STEM SEPARATION)
   ------------------------------------------------------------
   Tarayıcı içinde çalışan bir kaynak-ayırma motoru:
   • Kaynak seçilir (kanal bölgesi ya da içe aktarılan ses).
   • Stereo ise Merkez (Mid = L+R) ve Yan (Side = L-R) katmanları
     hesaplanır; merkez kanal genellikle vokali taşır.
   • Spektral zarf farkı ve bant ayrımı ile vokal/müzik maskeleri
     üretilir; maskeler yumuşatılarak (smoothing) tıkırtı önlenir.
   • Sonuç: “Vokal” ve “Enstrümantal” adlı iki yeni kanal.
   ============================================================ */

let stemSeparationResult = null;   // { vocal: AudioBuffer, inst: AudioBuffer, srcLabel }
let stemPreviewSrcs = [];

/* Kaynak seçim listesini güncelle: seçili kanal + ses bölgeleri. */
function refreshSplitSources() {
  const sel = $('splitSource');
  if (!sel) return;
  const prev = sel.value;
  const opts = [];

  // Seçili kanalın ses bölgeleri
  const tr = selectedTrack();
  if (tr) {
    tr.regions.forEach((rg, i) => {
      if (rg.buffer) {
        opts.push({
          value: 'region:' + tr.id + ':' + rg.id,
          label: tr.name + ' — ' + (rg.name || ('Bölge ' + (i + 1))),
          region: rg, track: tr
        });
      }
    });
  }
  // Diğer kanalların ses bölgeleri de listelenir
  state.tracks.forEach(t => {
    if (tr && t.id === tr.id) return;
    t.regions.forEach((rg, i) => {
      if (rg.buffer) {
        opts.push({
          value: 'region:' + t.id + ':' + rg.id,
          label: t.name + ' — ' + (rg.name || ('Bölge ' + (i + 1))),
          region: rg, track: t
        });
      }
    });
  });

  sel.innerHTML = '<option value="">Seçili kanal / kayıt yok</option>' +
    opts.map(o => `<option value="${esc(o.value)}">${esc(o.label)}</option>`).join('');

  if (prev && opts.some(o => o.value === prev)) sel.value = prev;
  const cur = splitSourceMeta(sel.value);
  $('splitSrcLbl').textContent = cur ? cur.label.toUpperCase() : 'SEÇİLMEDİ';
}

/* Kaynak değerinden bölge/kanal meta verisini çöz. */
function splitSourceMeta(value) {
  if (!value || value.indexOf('region:') !== 0) return null;
  const parts = value.split(':');
  const tr = getTrack(parts[1]);
  if (!tr) return null;
  const rg = tr.regions.find(r => r.id === parts[2]);
  if (!rg || !rg.buffer) return null;
  return { label: tr.name + ' — ' + rg.name, region: rg, track: tr };
}

/* İlerleme çubuğunu güncelle. */
function setSplitProgress(pct, stage) {
  const p = clamp(Math.round(pct), 0, 100);
  const bar = $('splitBar');
  if (bar) bar.style.width = p + '%';
  const pctEl = $('splitPct');
  if (pctEl) pctEl.textContent = p + '%';
  if (stage) { const s = $('splitStage'); if (s) s.textContent = stage; }
}

/* Bir sonraki kareyi bekle (UI donmasın). */
function nextFrame() {
  return new Promise(res => requestAnimationFrame(() => setTimeout(res, 0)));
}

/*
 * Merkez/Yan tabanlı vokal ayırma.
 *
 * vocalAmt : merkez kanalın vokal sayılma oranı (0..1)
 * instAmt  : enstrümantal katmanda merkezin bastırılma oranı (0..1)
 * quality  : 'fast' | 'balanced' | 'best' (yumuşatma çekirdeği uzunluğu)
 *
 * Dönen: { vocal: AudioBuffer, inst: AudioBuffer }
 */
async function separateStems(buffer, vocalAmt, instAmt, quality) {
  const ctx = AE.ctx;
  const sr = buffer.sampleRate;
  const nch = buffer.numberOfChannels;
  const len = buffer.length;
  const ch0 = buffer.getChannelData(0);
  const ch1 = nch > 1 ? buffer.getChannelData(1) : ch0;

  // Stereo ise merkez (mid) ve yan (side) bileşenleri
  const isStereo = nch > 1;
  const mid = new Float32Array(len);
  const side = new Float32Array(len);
  for (let i = 0; i < len; i++) {
    const l = ch0[i], r = ch1[i];
    mid[i] = (l + r) * 0.5;
    side[i] = (l - r) * 0.5;
  }

  const vocal = ctx.createBuffer(nch, len, sr);
  const inst = ctx.createBuffer(nch, len, sr);
  const vL = vocal.getChannelData(0);
  const vR = nch > 1 ? vocal.getChannelData(1) : vL;
  const iL = inst.getChannelData(0);
  const iR = nch > 1 ? inst.getChannelData(1) : iL;

  // Yumuşatma penceresi: merkez baskınlığını (smoothMask) örnek örnek değil,
  // pencere ortalaması olarak izle. Maske pencere dolmadan 0'da kalırsa
  // sesin başında vokal tamamen kaybolur; bu yüzden pencere ilk örnekle
  // tohumlanır.
  const smoothN = quality === 'best' ? 2048 : quality === 'fast' ? 256 : 1024;
  const invSmooth = 1 / smoothN;

  // Vokal bandı: 250 Hz (HP) - 4 kHz (LP) — konuşma/seslendirme bölgesi.
  // Gerçek bir 2. derece biquad high-pass kullanılır: basit `x[n]-x[n-1]`
  // fark operatörü 440 Hz civarındaki vokali neredeyse tamamen söndürür.
  const hpQ = Math.SQRT1_2;                       // Butterworth
  const w0 = 2 * Math.PI * 250 / sr;
  const cosW0 = Math.cos(w0), sinW0 = Math.sin(w0);
  const alphaHP = sinW0 / (2 * hpQ);
  const b0 = (1 + cosW0) / 2, b1 = -(1 + cosW0), b2 = (1 + cosW0) / 2;
  const a0 = 1 + alphaHP, a1 = -2 * cosW0, a2 = 1 - alphaHP;
  const nb0 = b0 / a0, nb1 = b1 / a0, nb2 = b2 / a0;
  const na1 = a1 / a0, na2 = a2 / a0;
  // LP (4 kHz) — 1. derece yeterli, tiz gürültüyü atar.
  const alphaHigh = clamp(1 - Math.exp(-2 * Math.PI * 4000 / sr), 0, 1);

  let hpX1 = 0, hpX2 = 0, hpY1 = 0, hpY2 = 0;   // HP biquad durumu
  let lpPrev = 0;      // alçak geçiren (tizi at) durumu
  let maskAcc = 0;     // yumuşatma biriktiricisi
  let maskCount = 0;
  let smoothMask = 0.5;   // ilk pencere için nötr tohum (0 olursa vokal susar)

  const chunk = 8192;
  for (let start = 0; start < len; start += chunk) {
    const end = Math.min(len, start + chunk);
    for (let i = start; i < end; i++) {
      const m = mid[i];
      const s = side[i];

      // --- Merkez baskınlığı: vokal genelde merkezde (mid), enstrüman yanda (side). ---
      const energyM = m * m;
      const energyS = s * s + 1e-9;
      let ratio = energyM / (energyM + energyS * 2.2);
      if (!isStereo) ratio = 0.5;           // mono: belirsiz, nötr maske

      // Pencere ortalaması (tıkırtısız, baştan tohumlu)
      maskAcc += ratio;
      maskCount++;
      if (maskCount >= smoothN) {
        smoothMask = maskAcc * invSmooth;
        maskAcc = 0; maskCount = 0;
      }

      // --- Vokal sinyali: 250 Hz HP -> 4 kHz LP, merkez (mid) kanal üzerinden. ---
      const x = m;
      const hpOut = nb0 * x + nb1 * hpX1 + nb2 * hpX2 - na1 * hpY1 - na2 * hpY2;
      hpX2 = hpX1; hpX1 = x; hpY2 = hpY1; hpY1 = hpOut;
      lpPrev += alphaHigh * (hpOut - lpPrev);
      const band = lpPrev;

      // Vokal maskesi: merkez baskınlığı × hassasiyet
      const vMask = clamp(smoothMask * (0.4 + vocalAmt), 0, 1);
      const vv = band * vMask;

      // --- Enstrümantal: orijinal stereo'dan vokal katkısını ÇIKAR. ---
      // Bastırma oranı smoothMask ile ölçeklenir ki yan (enstrümantal)
      // içerik korunsun.
      const suppress = clamp(smoothMask * instAmt, 0, 0.96);
      const il = ch0[i] - vv * suppress;
      const ir = ch1[i] - vv * suppress;

      vL[i] = vv;
      if (nch > 1) vR[i] = vv;
      iL[i] = il;
      if (nch > 1) iR[i] = ir;
    }
    setSplitProgress((end / len) * 92, 'Sinyaller ayrıştırılıyor...');
    await nextFrame();
  }

  setSplitProgress(96, 'Seviyeler normalize ediliyor...');
  await nextFrame();

  // Basit tepe normalizasyonu (kırpılmayı önle)
  normalizeBuffer(vocal, 0.92);
  normalizeBuffer(inst, 0.92);

  return { vocal, inst };
}

/* Buffer'ı tepe değerine göre normalize et. */
function normalizeBuffer(buffer, target) {
  let peak = 0;
  for (let c = 0; c < buffer.numberOfChannels; c++) {
    const d = buffer.getChannelData(c);
    for (let i = 0; i < d.length; i += 4) {
      const v = d[i] < 0 ? -d[i] : d[i];
      if (v > peak) peak = v;
    }
  }
  if (peak < 0.0001 || peak <= target) return;
  const g = target / peak;
  for (let c = 0; c < buffer.numberOfChannels; c++) {
    const d = buffer.getChannelData(c);
    for (let i = 0; i < d.length; i++) d[i] *= g;
  }
}

/* Ayırmayı çalıştır ve sonuçları iki yeni kanala yaz. */
async function runSeparation() {
  const meta = splitSourceMeta($('splitSource').value);
  if (!meta) {
    showToast('Önce ayırılacak bir kayıt/ses seçin. İçe aktarın ya da bir bölge seçin.', 'err', 4200);
    return;
  }
  await AE.init();
  if (!AE.ready) return;

  const btn = $('splitRunBtn');
  const oldHtml = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> <span>Ayırılıyor...</span>';
  setSplitProgress(1, 'Hazırlanıyor...');

  try {
    const vocalAmt = parseInt($('splitVocal').value, 10) / 100;
    const instAmt = parseInt($('splitInst').value, 10) / 100;
    const quality = $('splitQuality').value;

    const buf = meta.region.buffer;
    setSplitProgress(4, 'Kaynak çözümleniyor...');
    await nextFrame();

    const stems = await separateStems(buf, vocalAmt, instAmt, quality);
    stemSeparationResult = { vocal: stems.vocal, inst: stems.inst, srcLabel: meta.label };

    setSplitProgress(97, 'Kanallar oluşturuluyor...');
    await nextFrame();

    // İki yeni kanal oluştur
    const srcTrack = meta.track;
    const startBeat = snapBeat(meta.region.startBeat);
    const lengthBeats = Math.max(0.25, secToBeat(stems.vocal.duration));

    const vTrack = addTrack({
      type: 'vocal', name: 'Vokal — ' + (srcTrack.name || 'Kayıt'), color: '#ffffff'
    }, true);
    const iTrack = addTrack({
      type: 'audio', name: 'Enstrümantal — ' + (srcTrack.name || 'Kayıt'), color: '#ffffff'
    }, true);

    if (vTrack) {
      vTrack.regions.push({
        id: newId('rgn'), name: 'Vokal', startBeat, lengthBeats, color: vTrack.color,
        blobUrl: null, buffer: stems.vocal, sourceKind: 'audio', gain: 1.0, notes: null, drumNotes: null
      });
      vTrack.fx.reverb.on = true; vTrack.fx.reverb.mix = 12;
    }
    if (iTrack) {
      iTrack.regions.push({
        id: newId('rgn'), name: 'Enstrümantal', startBeat, lengthBeats, color: iTrack.color,
        blobUrl: null, buffer: stems.inst, sourceKind: 'audio', gain: 1.0, notes: null, drumNotes: null
      });
    }

    setSplitProgress(100, 'Tamamlandı');
    renderTracks();
    renderMixer();
    renderRuler();
    updateInfoBar();
    markUnsaved();
    refreshSplitSources();

    showToast('✅ Ses ayrıldı: <b>Vokal</b> ve <b>Enstrümantal</b> kanalları oluşturuldu.', 'ok', 5200);
    openDock('mixer');
  } catch (e) {
    console.error('Ayırma hatası:', e);
    setSplitProgress(0, 'Hata: ' + (e.message || e));
    showToast('Ayırma başarısız: ' + (e.message || e), 'err', 5200);
  }

  btn.disabled = false;
  btn.innerHTML = oldHtml;
}

/* Ayrılmış katmanı önizle (vokal veya enstrümantal). */
async function previewStem(which) {
  await AE.init();
  if (!AE.ready) return;

  if (!stemSeparationResult) {
    showToast('Önce ayırma işlemini çalıştırın.', 'info', 3200);
    return;
  }
  stopStemPreview();

  const buf = which === 'vocal' ? stemSeparationResult.vocal : stemSeparationResult.inst;
  if (!buf) return;

  const ctx = AE.ctx;
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const g = ctx.createGain();
  g.gain.value = 0.9;
  src.connect(g); g.connect(AE.master);
  src.start();
  src.onended = () => { stemPreviewSrcs = stemPreviewSrcs.filter(s => s !== src); };
  stemPreviewSrcs.push(src);
  activeSources.push(src);

  showToast((which === 'vocal' ? '🎤 Vokal' : '🎵 Enstrümantal') + ' katmanı dinleniyor...', 'info', 2400);
}

function stopStemPreview() {
  stemPreviewSrcs.forEach(s => { try { s.stop(); } catch (e) {} });
  stemPreviewSrcs = [];
}

/* ============================================================
   DEMO PROJE (İLK AÇILIŞ / BOŞ DURUM)
   ============================================================ */
function buildDemoProject() {
  // 4 kanallı örnek proje
  const drums = addTrack({ type: 'drums', name: 'Davul' }, true);
  const bass = addTrack({ type: 'bass', name: 'Bas' }, true);
  const keys = addTrack({ type: 'keys', name: 'Piyano' }, true);
  const pad = addTrack({ type: 'keys', name: 'Synth Pad' }, true);
  if (!drums || !bass || !keys || !pad) return;

  // Davul deseni
  const empty = () => DRUM_ROWS.map(() => new Array(DM_STEPS).fill(0));
  const pattern = empty();
  const setRow = (id, steps) => { const i = DRUM_ROWS.findIndex(r => r.id === id); if (i >= 0) steps.forEach(s => pattern[i][s] = 1); };
  setRow('kick', [0, 6, 10]);
  setRow('snare', [4, 12]);
  setRow('hat_closed', [0,2,4,6,8,10,12,14]);
  state.drumPattern = pattern;

  const step = 0.25;
  const drumNotes = [];
  for (let rep = 0; rep < 8; rep++) {
    DRUM_ROWS.forEach((row, ri) => pattern[ri].forEach((v, s) => {
      if (v) drumNotes.push({ beat: (rep * DM_STEPS + s) * step, dur: step * 0.9, drum: row.id });
    }));
  }
  drums.regions.push({ id: newId('rgn'), name: 'Davul Deseni', startBeat: 0,
    lengthBeats: DM_STEPS * step * 8, color: drums.color, blobUrl: null, buffer: null,
    sourceKind: 'drums', gain: 1, notes: null, drumNotes });

  // Bas hattı (C - A - F - G, 2 bar her biri)
  const bassRoots = [36, 33, 29, 31];  // C2, A1, F1, G1
  const bassNotes = [];
  bassRoots.forEach((root, bar) => {
    for (let i = 0; i < 8; i++) {
      const b = bar * 8 + i;
      if (i % 2 === 0) bassNotes.push({ beat: b, dur: 1.4, note: root });
    }
  });
  bass.regions.push({ id: newId('rgn'), name: 'Bas Hattı', startBeat: 0, lengthBeats: 32,
    color: bass.color, blobUrl: null, buffer: null, sourceKind: 'synth', gain: 0.9, notes: bassNotes, drumNotes: null });

  // Piyano akorlar
  const chordSets = [[60,64,67],[57,60,64],[53,57,60],[55,59,62]];
  const keyNotes = [];
  chordSets.forEach((ch, bar) => {
    [0, 4].forEach(off => ch.forEach(n => keyNotes.push({ beat: bar * 8 + off, dur: 3.6, note: n })));
  });
  keys.regions.push({ id: newId('rgn'), name: 'Piyano Akorları', startBeat: 0, lengthBeats: 32,
    color: keys.color, blobUrl: null, buffer: null, sourceKind: 'synth', gain: 0.7, notes: keyNotes, drumNotes: null });

  // Pad
  const padNotes = [];
  chordSets.forEach((ch, bar) => {
    [72,74,76,79].forEach((n, i) => padNotes.push({ beat: bar * 8, dur: 7.6, note: n - (i % 2) }));
  });
  pad.regions.push({ id: newId('rgn'), name: 'Pad', startBeat: 0, lengthBeats: 32,
    color: pad.color, blobUrl: null, buffer: null, sourceKind: 'synth', gain: 0.42, notes: padNotes, drumNotes: null });

  // Efektleri tatlı varsayılanlara ayarla
  pad.fx.reverb.on = true; pad.fx.reverb.mix = 42; pad.fx.reverb.size = 65;
  keys.fx.reverb.on = true; keys.fx.reverb.mix = 20;
  bass.fx.compressor.on = true;

  state.selectedTrackId = keys.id;
  state.title = 'Demo Proje';
  $('projectTitle').value = state.title;
  state.loopStart = 0; state.loopEnd = 32;
  state.loopEnabled = false;

  renderTracks(); renderMixer(); renderRuler(); renderDrumGrid(); updateInfoBar();
  markUnsaved();
  showToast('🎵 Demo proje yüklendi! <b>Space</b> ile çalabilirsiniz.', 'ok', 5200);
}

/* ============================================================
   BAŞLATMA
   ============================================================ */
async function init() {
  // Temel çizimler
  initDrumPattern('boom_bap');
  buildPiano();
  renderRuler();
  renderTracks();
  renderMixer();
  syncTransportUI();
  wireEvents();
  updateInfoBar();

  // Oturum
  try {
    const res = await fetch('studio.php?action=session');
    const data = await res.json();
    if (data && data.status === 'loggedin' && data.user) {
      state.user = data.user;
      $('userChipName').textContent = data.user.artist || 'Kullanıcı';
      $('userChipPic').src = 'index.php?action=get_profile_picture&id=' + data.user.id + '&v=' + Date.now();
      showToast('Hoş geldin, <b>' + esc(data.user.artist) + '</b>! Projelerinizi kaydedebilirsiniz.', 'ok', 4000);
    } else {
      $('userChipName').textContent = 'Misafir (kayıt kapalı)';
    }
  } catch (e) {
    $('userChipName').textContent = 'Misafir';
  }

  // Loop kütüphanesini arka planda hazırla
  loadLoops();

  // Projeyi URL'den yükleme desteği: studio.php?project=ID
  const params = new URLSearchParams(location.search);
  const pid = params.get('project');
  if (pid && state.user) {
    await AE.init();
    loadProject(pid);
  }

  // Ses motorunu ilk kullanıcı etkileşiminde uyandır
  const wake = () => {
    AE.init().then(() => { ensureMasterChain(); applyMasterPreset(state.masterPreset); });
    document.removeEventListener('pointerdown', wake);
    document.removeEventListener('keydown', wake);
  };
  document.addEventListener('pointerdown', wake);
  document.addEventListener('keydown', wake);

  document.title = state.title + ' — Kuduko Ses Kayıt Stüdyosu';
  console.log('%c🎙️ Kuduko Ses Kayıt Stüdyosu hazır', 'color:#ffffff;font-weight:bold;font-size:13px');

  // Teşhis: script kapsamı ile window kapsamı ayrıdır ('use strict' + IIFE benzeri
  // top-level kapsam). init() yalnızca tarayıcı içinden çağrılabilsin diye
  // gerekli API'ler window'a açılır.
  const probe = document.getElementById('studioStateProbe');
  if (probe) probe.textContent = 'init-ok:' + state.tracks.length + ':' + typeof window.init;
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
</script>

</body>
</html>