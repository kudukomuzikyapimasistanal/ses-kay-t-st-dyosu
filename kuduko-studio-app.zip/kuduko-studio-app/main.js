const { app, BrowserWindow, Menu, session, dialog } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const net = require('net');
const http = require('http');

let phpProc = null;
let mainWin = null;

const isPackaged = app.isPackaged;
const resBase = isPackaged ? process.resourcesPath : __dirname;
const phpDir = path.join(resBase, 'php');
const phpExe = path.join(phpDir, 'php.exe');
const appDir = path.join(resBase, 'app');

function freePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.listen(0, '127.0.0.1', () => {
      const { port } = srv.address();
      srv.close(() => resolve(port));
    });
    srv.on('error', reject);
  });
}

function waitForServer(port, tries = 60) {
  return new Promise((resolve, reject) => {
    const attempt = (n) => {
      const req = http.get({ host: '127.0.0.1', port, path: '/index.php?action=get_profile_picture', timeout: 1000 }, (res) => {
        res.resume();
        resolve();
      });
      req.on('error', () => {
        if (n <= 0) return reject(new Error('PHP sunucusu başlatılamadı.'));
        setTimeout(() => attempt(n - 1), 250);
      });
      req.on('timeout', () => req.destroy());
    };
    attempt(tries);
  });
}

async function startPhp() {
  const fs = require('fs');
  if (!fs.existsSync(phpExe)) {
    throw new Error('php.exe bulunamadı:\n' + phpExe + '\n\n"npm run setup" komutunu çalıştırın.');
  }
  const dataDir = path.join(app.getPath('userData'), 'data');
  fs.mkdirSync(dataDir, { recursive: true });
  const sessDir = path.join(dataDir, 'sessions');
  fs.mkdirSync(sessDir, { recursive: true });

  const port = await freePort();
  const args = [
    '-n', // sistem php.ini'sini yok say
    '-d', 'extension_dir=' + path.join(phpDir, 'ext'),
    '-d', 'extension=pdo_sqlite',
    '-d', 'extension=sqlite3',
    '-d', 'extension=mbstring',
    '-d', 'extension=fileinfo',
    '-d', 'upload_max_filesize=128M',
    '-d', 'post_max_size=140M',
    '-d', 'memory_limit=768M',
    '-d', 'max_execution_time=300',
    '-d', 'date.timezone=Europe/Istanbul',
    '-d', 'session.save_path=' + sessDir,
    '-S', '127.0.0.1:' + port,
    '-t', appDir
  ];

  phpProc = spawn(phpExe, args, {
    cwd: appDir,
    windowsHide: true,
    env: { ...process.env, STUDIO_DATA_DIR: dataDir }
  });
  phpProc.stderr.on('data', (d) => console.log('[php]', d.toString().trim()));
  phpProc.on('exit', (code) => console.log('php çıktı:', code));

  await waitForServer(port);
  return port;
}

async function createWindow() {
  let port;
  try {
    port = await startPhp();
  } catch (e) {
    dialog.showErrorBox('Kuduko Ses Stüdyosu', String(e.message || e));
    app.quit();
    return;
  }

  // Mikrofon izni (kayıt için gerekli)
  const allowed = new Set(['media', 'audioCapture', 'microphone', 'clipboard-sanitized-write', 'fullscreen']);
  session.defaultSession.setPermissionRequestHandler((wc, permission, cb) => cb(allowed.has(permission)));
  session.defaultSession.setPermissionCheckHandler((wc, permission) => allowed.has(permission));

  mainWin = new BrowserWindow({
    width: 1500,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#000000',
    title: 'Kuduko Ses Kayıt Stüdyosu',
    autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, backgroundThrottling: false }
  });
  Menu.setApplicationMenu(null);
  mainWin.loadURL('http://127.0.0.1:' + port + '/studio.php');
  mainWin.on('closed', () => { mainWin = null; });
}

function stopPhp() {
  if (phpProc && !phpProc.killed) {
    try { phpProc.kill(); } catch (e) {}
  }
  phpProc = null;
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => { if (mainWin) { if (mainWin.isMinimized()) mainWin.restore(); mainWin.focus(); } });
  app.whenReady().then(createWindow);
  app.on('window-all-closed', () => { stopPhp(); app.quit(); });
  app.on('before-quit', stopPhp);
}
